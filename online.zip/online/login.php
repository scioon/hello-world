<html>
<head>
<style>

.myButton {
	background-color:#ffc000;
	-moz-border-radius:28px;
	-webkit-border-radius:28px;
	border-radius:23px;
	border:1px solid #18ab29;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:13px;
	padding:12px 21px;
	text-decoration:none;
	text-shadow:0px 1px 0px #2f6627;
}
.myButton:hover {
	background-color:#ffc000;
}
.myButton:active {
	position:relative;
	top:1px;
}

        
</style>
</head>

<center><div id="container">

<br/>
<h2>Jobseeker Login</h2>
<?php
session_start();
if(isset($_POST['bttLogin']))
{
	require 'connect.php';
	$username = $_POST['username'];
	$password = $_POST['password'];
	$result = mysqli_query($con, 'select * from users where username = "'.$username.'" and password = "'.$password.'" ');
	if(mysqli_num_rows($result) == 1)
	{
		$_SESSION['username']=$username;
		header('Location:welcome.php');
	}
	else
	{
		echo "accounts invalid";
	}
	if(isset($_GET['logout']))
	{
		session_unregister('username');
	}
}
?>
<form method="post" action="login.php?action=login">
<table cellpadding="2" cellspacing="2" >
<tr>
<td >Username:</td><td><input type="text" name="username">
</td>
</tr>
<tr>
<td>Password:</td><td><input type="password" name="password">
</td>
</tr>
<tr>

<td><input type="submit" name="bttLogin" value="Login" class="myButton"></td>



<td>If you are not Registered User please Register <a href="register.php"  target="_blank">Register</a>
 <!-- <a href="adminlogin.php" class="myButton" target="_blank">adminlogin</a> -->
</td>
</tr>
</table>
</div>
<br/>


</body>
</html>