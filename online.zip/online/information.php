<?php include "header.php" ?>
	
	<div id="banner-area" class="banner-area" style="background-image:url(images/inform.jpg)">
		<div class="banner-text">
     		<div class="container">
	        	<div class="row">
	        		<div class="col-xs-12">
	        			<div class="banner-heading">
	        				<h1 class="border-title border-left">Information</h1>
	        				<ol class="breadcrumb">
	        					<li>Home</li>
	        					<!-- <li>Projects</li> -->
	        					<li><a href="#">Information</a></li>
	        				</ol>
	        			</div>
	        		</div><!-- Col end -->
	        	</div><!-- Row end -->
       	</div><!-- Container end -->
    	</div><!-- Banner text end -->
	</div><!-- Banner area end --> 

	<section id="main-container" class="main-container">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div id="page-slider" class="owl-carousel owl-theme page-slider page-slider-small">
						<!-- <div class="item">
							<img src="images/projects/project1.jpg" alt="" />
						</div> -->

						<!-- <div class="item">
							<img src="images/projects/project2.jpg" alt="" />
						</div>
					</div> --><!-- Page slider end -->

					<h2 class="project-title"  style="text-align:center;">Information Technology</h2>
				</div><!-- Slider col end -->

			</div><!-- Row end -->

			<div class="gap-20"></div>

			<div class="row">
				<div class="col-sm-3">
					<ul class="project-info unstyled">
						<li>
							<div class="project-info-label">Education</div>
							<!-- <div class="project-info-content">Pransbay Powers Authority</div> -->
						</li>
						<li>
							<div class="project-info-label">Finance</div>
							<!-- <div class="project-info-content">Dlarke Pelli Incorp</div> -->
						</li>
						<li>
							<div class="project-info-label">Information Technology</div>
							<!-- <div class="project-info-content">McLean, VA</div> -->
						</li>
						<li>
							<div class="project-info-label">Realestate</div>
							<!-- <div class="project-info-content">65,000 SF</div> -->
						</li>
						<li>
							<div class="project-info-label">Hospitality</div>
							<!-- <div class="project-info-content">2014</div> -->
						</li>
						<li>
							<!-- <div class="project-info-label">Categories</div> -->
							<!-- <div class="project-info-content">Commercial, Interiors</div> -->
						</li>
						<li>
							<div class="project-link">
								<!-- <a class="btn btn-primary" target="_blank" href="#">View Project</a> -->
							</div>
						</li>
					</ul>

				</div><!-- Content Col end -->

				<div class="col-sm-9">
					<div class="content-inner-page">
			
						<p style="font-family:Bookman Old Style;text-align:justify;">Information Technology (IT) is a pivotal part of the Indian economy and has played a defining role in establishing our economic prowess on the global map. The sector includes software solutions, hardware, IT services, engineering and R&D services and ITES (IT-enabled services). In the ITES segment, India has emerged as one of the most preferred destinations for companies looking to offshore their IT and back-office functions due to cost arbitrage, availability of skilled manpower and a favourable business environment.

Indian IT companies, especially the top firms such as TCS, Infosys and Wipro, have been competing against top global firms such as IBM, Accenture and EDS for large mandates. India continues to remain a hub for cost effective technology operations. Nasscom has maintained its growth projection of 16-18 per cent for the sector in this fiscal. The sector is projected to bring in revenues of US$ 68-70 billion during this fiscal. The IT industry in India is continuously generating millions of direct jobs over the years. The industry currently has around 2 million employees.</p>
						<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis semper lacus scelerisque, aliquam leo quis, porttitor leo. Fusce lectus ex, pretium efficitur suscipit sed, faucibus vel elit Integer adipiscing erat eget risus sollicitudin pellentesque et non erat. Proin suscipit convallis facilisis. Fusce lectus ex, pretium efficitur suscipit sed, faucibus vel elit. Sed eu vestibulum leo. Phasellus at quam id elit hendrerit semper feugiat id nunc ultrices ultrices sapien.</p>
						<ul class="list-arrow">
							<li>Street Level Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>One and Two Apartment ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>Street Level Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>A countried and green ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>A Five Storied Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
						</ul>
 -->


					</div><!-- Content inner end -->
				</div><!-- Content Col end -->


			</div><!-- Row end -->
		</div><!-- Conatiner end -->
	</section><!-- Main container end -->

	<?php include "footer.php" ?>