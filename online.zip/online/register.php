
<head>
<!-- <title>PHP insertion</title> -->
<link href="css/insert.css" rel="stylesheet">


</head>

<body>
<div class="maindiv">
<!--HTML Form -->
<center><div class="form_div">
<div class="title">
<h2>Jobseeker Registration</h2>
</div>
<form action="insert.php" method="post" enctype="multipart/form-data" name="form1">
<!-- Method can be set as POST for hiding values in URL-->
<h2>Form</h2>
<label>Jobseeker Id:</label>
<input class="input" name="id" type="text" value="" required>
<label>Jobseeker Name:</label>
<input class="input" name="name" type="text" value="" required>
<label>Address:</label>
<textarea cols="25" name="address" rows="5"></textarea>
<label>City:</label>
<input class="input" name="city" type="text" value="" required>
<label>Email:</label>
<input class="input" name="email" type="text" value="" required>
 
<label>Mobile:</label>
<input class="input" name="mobile" type="text" value="" required>
<label>Qualification:</label>
<input class="input" name="qualification" type="text" value="" required>
<label>Gender:</label>
<input class="input" name="gender" type="text" value="" required>
<label>Birthdate:</label>
<input type="date" name="birthdate" id="birthdate"><br/><br/>


<!-- <label>Resume:</label>
<input type="file" name="resume" id="SubmitBtn" value="Upload Resume">
<br/>
<br/> -->
<label>Status:</label>
<input class="input" name="status" type="text" value="" required>
<label>Username:</label>
<input class="input" name="username" type="text" value="" required>
<label>Password:</label>

<input class="input" name="password" type="text" value="" required>
<label>Question:</label>

<input class="input" name="question" type="text" value="" required>
<label>Answer:</label>

<input class="input" name="answer" type="text" value="" required>
<input class="submit" name="submit" type="submit" value="Insert" required>
</form>
</div>
</div>
</form>
</body>
