	<section class="subscribe no-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-12 col-xs-12">
					<div class="subscribe-call-to-acton">
						<h3>Can We Help?</h3>
						<h4>+(91)-40-64644501</h4>
					</div>
				</div><!-- Col end -->

				<div class="col-md-8 col-sm-12 col-xs-12">
					<div class="ts-newsletter">
						<div class="newsletter-introtext">
							<h4>Newsletter Sign-up</h4>
							<p>Latest updates and news</p>
						</div>

						<div class="newsletter-form">
							<form action="#" method="post">
								<div class="form-group">
									<input type="email" name="email" id="newsletter-form-email" class="form-control form-control-lg" placeholder="Your Email Here" autocomplete="off">
									<button class="btn btn-primary">Subscribe</button>
								</div>
							</form>
						</div>
					</div><!-- Newsletter end -->
				</div><!-- Col end -->

			</div><!-- Content row end -->
		</div><!--/ Container end -->
	</section><!--/ News end -->



	<footer id="footer" class="footer bg-overlay">
		<div class="footer-top">
			<div class="container">
				<div class="row">

					<div class="col-md-4">
						<div class="action-box">
							<span class="action-box-icon">
								<i class="fa fa-map-marker"></i>
							</span>
							<div class="action-box-content">
								<h3>Where We Are</h3>
								<p class="action-box-text">Plot No 10-5-438/e Sri Rama Bhavanamu 3rd Floor.Road No 4 .</p>
								<p><a href="#"><i class="fa fa-caret-right"> </i> Find More</a></p>
							</div>
						</div><!-- Action box 1 end -->
					</div><!-- Col end -->

					<div class="col-md-4">
						<div class="action-box">
							<span class="action-box-icon"><i class="fa fa-map-marker"></i>
							</span>
							<div class="action-box-content">
								<h3>Address</h3>
								<p class="action-box-text">MVG Consulting, West Marredpally, Hyderabad - 500026.</p>
								<p><a href="#"><i class="fa fa-caret-right"> </i> Learn More</a></p>
							</div>
						</div><!-- Action box 2 end -->
					</div><!-- Col end -->

					<div class="col-md-4">
						<div class="action-box">
							<span class="action-box-icon">
								<i class="fa fa-comments"></i>
							</span>
							<div class="action-box-content">
								<h3>Contact Us</h3>
								<p class="action-box-text">Mail us: info@mvg.com <br /> Call us:  +(91)-40-64644501</p>
								<p><a href="#"><i class="fa fa-caret-right"> </i> Learn More</a></p>
							</div>
						</div><!-- Action box 3 end -->
					</div><!-- Col end -->

				</div><!-- Content row end -->
			</div><!--/ Container end -->
		</div><!-- Footer top end -->

		<div class="footer-main">
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-sm-12 footer-widget footer-about">
						<h3 class="widget-title">About Us</h3>
						<img class="footer-logo" src="images/footer-logo1.png" alt="" />
						<p style="font-family:Bookman Old Style;text-align:justify;">To provide HR Solutions of International standards through value added services.To establish our company amongst the FIRST TWO LARGEST players in all departments.</p>
						<div class="footer-social">
							<ul>
								<li><a href="#"><i class="fa fa-rss"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div><!-- Footer social end -->
					</div><!-- Col end -->

					<div class="col-md-3 col-sm-12 footer-widget">
						<h3 class="widget-title">Working Hours</h3>
						<div class="working-hours" style="font-family:Bookman Old Style;">
							We work 7 days a week, every day excluding major holidays. Contact us if you have an emergency, with our Hotline and Contact form.
							<br><br> Monday - Friday: <span class="text-right">10:00 - 16:00 </span>
							<br> Saturday: <span class="text-right">12:00 - 15:00</span> 
							<br> Sunday: <span class="text-right">09:00 - 12:00</span>
						</div>
					</div><!-- Col end -->

					<div class="col-md-3 col-sm-12 footer-widget">
						<h3 class="widget-title">Services</h3>
						<ul class="list-arrow">
							<li><a href="#">Training</a></li>
							<li><a href="#">Recruiting</a></li>
							<li><a href="#">Placements</a></li>
							<!-- <li><a href="#">Design and Build</a></li>
							<li><a href="#">Self-Perform Construction</a></li> -->
						</ul>
					</div><!-- Col end -->

					<div class="col-md-3 col-sm-12 footer-widget">
						<h3 class="widget-title">Instagram Widget</h3>
						<div class="instagram-widget">
							<a href="#"><img class="img-responsive" src="images/gallery/gallery1.jpg" alt="" /></a>
							<a href="#"><img class="img-responsive" src="images/gallery/gallery2.jpg" alt="" /></a>
							<a href="#"><img class="img-responsive" src="images/gallery/gallery3.jpg" alt="" /></a>
							<a href="#"><img class="img-responsive" src="images/gallery/gallery4.jpg" alt="" /></a>
							<a href="#"><img class="img-responsive" src="images/gallery/gallery5.jpg" alt="" /></a>
							<a href="#"><img class="img-responsive" src="images/gallery/gallery6.jpg" alt="" /></a>
						</div>
					</div><!-- Col end -->

				</div><!-- Row end -->
			</div><!-- Container end -->
		</div><!-- Footer main end -->

		<div class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-6">
						<div class="copyright-info">
							<span>Copyright &#169 2016 MVG consulting. All Rights Reserved.</span><p>Website design by <a class="one" href="http://www.aniinfosoft.com" style="color:black;" target="_blank"><b>ANIINFOSOFT INC</b></a></p>
						</div>
					</div>

					<div class="col-xs-12 col-sm-6">
						<div class="footer-menu">
							<ul class="nav unstyled">
								<li><a href="#">Home</a></li>
								<li><a href="#">About Us</a></li>
								<li><a href="#">How We Work</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Contact Us</a></li>
							</ul>
						</div>
					</div>
				</div><!-- Row end -->

				<div id="back-to-top" data-spy="affix" data-offset-top="10" class="back-to-top affix">
					<button class="btn btn-primary" title="Back to Top">
						<i class="fa fa-angle-double-up"></i>
					</button>
				</div>

			</div><!-- Container end -->
		</div><!-- Copyright end -->

	</footer><!-- Footer end -->


	<!-- Javascript Files
	================================================== -->

	<!-- initialize jQuery Library -->
	<script type="text/javascript" src="js/jquery.js"></script>
	<!-- Bootstrap jQuery -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!-- Owl Carousel -->
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<!-- Counter -->
	<script type="text/javascript" src="js/jquery.counterup.min.js"></script>
	<!-- Waypoints -->
	<script type="text/javascript" src="js/waypoints.min.js"></script>
	<!-- Color box -->
	<script type="text/javascript" src="js/jquery.colorbox.js"></script>
	<!-- Smoothscroll -->
	<script type="text/javascript" src="js/smoothscroll.js"></script>
	<!-- Isotope -->
	<script type="text/javascript" src="js/isotope.js"></script>
	<script type="text/javascript" src="js/ini.isotope.js"></script>

	<!-- Template custom -->
	<script type="text/javascript" src="js/custom.js"></script>
	
	</div><!-- Body inner end -->
</body>
</html>