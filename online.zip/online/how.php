
	
<?php include "header.php"?>
	<div id="banner-area" class="banner-area" style="background-image:url(images/how.jpg)">
		<div class="banner-text">
     		<div class="container">
	        	<div class="row">
	        		<div class="col-xs-12">
	        			<div class="banner-heading">
	        				<!-- <h1 class="border-title border-left">Elements</h1> -->
	        				<!-- <ol class="breadcrumb">
	        					<li>Home</li>
	        					<!-- <li>Features</li> -->
	        					<!-- <li><a href="#">How We Work</a></li> -->
	        				</ol> -->
	        			</div>
	        		</div><!-- Col end -->
	        	</div><!-- Row end -->
       	</div><!-- Container end -->
    	</div><!-- Banner text end -->
	</div><!-- Banner area end --> 

	<section id="main-container" class="main-container">
		<div class="container">

			<div class="row">
				<div class="col-md-6">
					<h3 class="border-title border-left" style="font-family:Bookman Old Style;">Our Recruitment Process</h3>

					<div class="panel-group" id="accordion">
	              	<div class="panel panel-default">
		                <div class="panel-heading">
			                <h4 class="panel-title"> 
			                	<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" style="font-family:Bookman Old Style;">Requirement Analysis</a> 
			                </h4>
		                </div>
		                <div id="collapseOne" class="panel-collapse collapse in">
		                  <div class="panel-body">
		                    <p style="font-family:Bookman Old Style;">Evaluation of the position with respect to the skills, competencies, responsibilities, key deliverables and other details is done followed by a discussion with the client on the same.</p>
		                  </div>
		                </div>
	              	</div><!--/ Panel 1 end-->

	              	<div class="panel panel-default">
		                <div class="panel-heading">
			                <h4 class="panel-title">
			                	<a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapseTwo"> Sourcing and Assessment</a>
			            	</h4>
		                </div>
		                <div id="collapseTwo" class="panel-collapse collapse">
		                  <div class="panel-body">
		                   <p style="font-family:Bookman Old Style;text-align:justify;">Identification of the suitable candidates searched from various sources like the databases, advertising or networking.</p>
		                  </div>
		                </div>
	              	</div><!--/ Panel 2 end-->
            	</div><!--/ Accordion end -->
            	<!-- <p>This is the example of Accordion Default. For classic Accordion use class <strong>panel-group panel-classic</strong></p> -->
            </div><!--/ Col end -->

            <div class="col-md-6">
					<h3 class="border-title border-left" style="font-family:Bookman Old Style;">Process</h3>

					<div class="featured-tab">
						<ul class="nav nav-tabs">
						  	<li class="active">
						  		<a class="animated fadeIn" href="#tab_a" data-toggle="tab">
						  			<span class="tab-head">
										<span class="tab-text-title">Organizational mapping</span>					
									</span>
						  		</a>
						  	</li>
						  	<li>
							  	<a class="animated fadeIn" href="#tab_b" data-toggle="tab">
							  		<span class="tab-head">
										<span class="tab-text-title" style="font-family:Bookman Old Style;">Contact</span>					
									</span>
							  	</a>
							</li>
						 	<li>
							  	<a class="animated fadeIn" href="#tab_c" data-toggle="tab">
							  		<span class="tab-head">
										<span class="tab-text-title" style="font-family:Bookman Old Style;">Interviews</span>					
									</span>
							  	</a>
							</li>
						</ul>

						<div class="tab-content">
					      <div class="tab-pane active animated fadeInRight" id="tab_a">
					        	<div class="tab-wrapper">
						        
									<div class="ts-service-box">
										<span class="ts-service-icon"><i class="fa fa-trophy"> </i></span>
										<div class="ts-service-box-content">
											<h3 style="font-family:Bookman Old Style;">Selection Support</h3>
											<p style="font-family:Bookman Old Style;text-align:justify;">Reference Checks are carried out for the selected candidates and the summary of the same submitted ahead of the offer or joining, as desired by the client.</p>
										</div>
									</div><!-- Service 1 end -->

									<div class="ts-service-box">
										<span class="ts-service-icon"><i class="fa fa-sliders"> </i></span>
										<div class="ts-service-box-content">
											<h3 style="font-family:Bookman Old Style;">Offer Negotiation </h3>
											<p style="font-family:Bookman Old Style;text-align:justify;">Offer Negotiation is done with the final candidate. Inputs from the team on the market trends, competitors compensation for the level and taxation and benefits assist in a closure.</p>
										</div>
									</div><!-- Service 2 end -->									

					        	</div><!-- Tab wrapper end -->
					      </div><!-- Tab pane 1 end -->

				        <div class="tab-pane animated fadeInRight" id="tab_b">
				            <p style="font-family:Bookman Old Style;text-align:justify;">Contact with the potential candidates is then made and they are briefed about the position, organization and the role specifications. A detailed discussion with the candidates ensures that the expectations from both ends are well communicated and understood and the potential candidates are motivated to pursue the opportunity.</p>

				            <div class="ts-service-box">
									<!-- <span class="ts-service-icon"><i class="fa fa-users"> </i></span> -->
									<div class="ts-service-box-content">
										<!-- <h3>A Team of Professionals</h3>
										<p>Aenean et dolor pretium, feugiat leom nongial, aliquettiabser libero. Consectetur ut vestibulum vivamus vestibulum accumsa.</p> -->
									</div>
								</div><!-- Service 1 end -->
				        </div><!-- Tab pane 2 end -->

				        	<div class="tab-pane animated fadeInLeft" id="tab_c">
				            <img class="pull-left" src="images/hhh.jpg" width="150" alt="" />
				            <p style="font-family:Bookman Old Style;text-align:justify;">Interviews with the client are scheduled after the submission of the suitable profiles and the assessment reports for the short listed candidates. Complete interview support is given to the client and the candidate including operational aspects such as travel arrangements or directions to the venue.</p>
				        	</div><!-- Tab pane 3 end -->	
						</div><!-- tab content -->
					</div><!-- Featured tab end -->	

            </div><!--/ Col end -->
			</div><!-- Row 1 end -->

			<div class="gap-30"></div>

			

			<div class="row">
				<div class="col-md-6">
					<h3 class="border-title border-left" style="font-family:Bookman Old Style;">Testimonial</h3>
					<div class="quote-item quote-border">
			         <div class="quote-text-border" style="font-family:Bookman Old Style;text-align:justify;">
			       The service received has been very good. 
			         </div>

			         <div class="quote-item-footer">
			         	<img class="testimonial-thumb" src="images/ts1.jpeg" alt="testimonial">
			         	<div class="quote-item-info">
			         		<h3 class="quote-author" style="font-family:Bookman Old Style;">ram</h3>
				         	<!-- <span class="quote-subtext" style="font-family:Bookman Old Style;">CEO, First Choice Group</span> -->
			         	</div>
			         </div>
			     </div><!-- Quote item end -->
				</div><!-- Col end -->

				<div class="col-md-6">
					<h3 class="border-title border-left">Call to Action</h3>

					<div class="call-to-action classic">
						<div class="row">
							<div class="col-md-8">
								<div class="call-to-action-text">
									<h3 class="action-title" style="font-family:Bookman Old Style;text-align:justify;">At MVG Consulting, we understand that nothing but quality guarantees a long term relationship with our clients and candidates.</h3>
								</div>
							</div><!-- Col end -->
							<div class="col-md-4">
								<div class="call-to-action-btn">
									<a class="btn btn-dark" href="#" style="font-family:Bookman Old Style;">Get a Quote</a>
								</div>
							</div><!-- col end -->
						</div><!-- row end -->
					</div><!-- Action end -->

				</div><!-- Col end -->
			</div><!-- Row 3 end -->

		</div><!-- Container end -->
	</section><!-- Main container end -->

		<?php include "footer.php" ?>