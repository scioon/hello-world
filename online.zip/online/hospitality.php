<?php include "header.php" ?>
	
	<div id="banner-area" class="banner-area" style="background-image:url(images/hos.jpg)">
		<div class="banner-text">
     		<div class="container">
	        	<div class="row">
	        		<div class="col-xs-12">
	        			<div class="banner-heading">
	        				<h1 class="border-title border-left">Hospitality</h1>
	        				<ol class="breadcrumb">
	        					<li>Home</li>
	        					<!-- <li>Projects</li> -->
	        					<li><a href="#">Hospitality</a></li>
	        				</ol>
	        			</div>
	        		</div><!-- Col end -->
	        	</div><!-- Row end -->
       	</div><!-- Container end -->
    	</div><!-- Banner text end -->
	</div><!-- Banner area end --> 

	<section id="main-container" class="main-container">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div id="page-slider" class="owl-carousel owl-theme page-slider page-slider-small">
						<!-- <div class="item">
							<img src="images/projects/project1.jpg" alt="" />
						</div> -->

						<!-- <div class="item">
							<img src="images/projects/project2.jpg" alt="" />
						</div>
					</div> --><!-- Page slider end -->

					<h2 class="project-title"  style="text-align:center;">Hospitality</h2>
				</div><!-- Slider col end -->

			</div><!-- Row end -->

			<div class="gap-20"></div>

			<div class="row">
				<div class="col-sm-3">
					<ul class="project-info unstyled">
						<li>
							<div class="project-info-label">Education</div>
							<!-- <div class="project-info-content">Pransbay Powers Authority</div> -->
						</li>
						<li>
							<div class="project-info-label">Finance</div>
							<!-- <div class="project-info-content">Dlarke Pelli Incorp</div> -->
						</li>
						<li>
							<div class="project-info-label">Information Technology</div>
							<!-- <div class="project-info-content">McLean, VA</div> -->
						</li>
						<li>
							<div class="project-info-label">Realestate</div>
							<!-- <div class="project-info-content">65,000 SF</div> -->
						</li>
						<li>
							<div class="project-info-label">Hospitality</div>
							<!-- <div class="project-info-content">2014</div> -->
						</li>
						<li>
							<!-- <div class="project-info-label">Categories</div> -->
							<!-- <div class="project-info-content">Commercial, Interiors</div> -->
						</li>
						<li>
							<div class="project-link">
								<!-- <a class="btn btn-primary" target="_blank" href="#">View Project</a> -->
							</div>
						</li>
					</ul>

				</div><!-- Content Col end -->

				<div class="col-sm-9">
					<div class="content-inner-page">
			
						<p style="font-family:Bookman Old Style;text-align:justify;">Encompassing a whole lot of areas that are diverse in themselves and yet unique in their customer centric approach, Hospitality Industry is vast and extensive. As the global economy is picking up fast, it is witnessing a growing number of opportunities for new comers as well as experienced players. The industry demands skilled candidates with a positive approach towards their specific sector and full conviction in their profile. Hard working people can see their careers rocketing as one can reach the top in a short span of time. We, at Sella Consultants, solely focus on placing quality candidates in the hospitality industry throughout the world. Serving various industries, ranging from insurance, banking and financial services to travel & leisure, we have the experts from all the sectors who assist in shortlisting the most suitable candidate, befitting your specifications. With our extensive hospitality operations and search experience, we assist recruiters to staff candidates at the staff, management and executive level coast to coast.</p>
						<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis semper lacus scelerisque, aliquam leo quis, porttitor leo. Fusce lectus ex, pretium efficitur suscipit sed, faucibus vel elit Integer adipiscing erat eget risus sollicitudin pellentesque et non erat. Proin suscipit convallis facilisis. Fusce lectus ex, pretium efficitur suscipit sed, faucibus vel elit. Sed eu vestibulum leo. Phasellus at quam id elit hendrerit semper feugiat id nunc ultrices ultrices sapien.</p>
						<ul class="list-arrow">
							<li>Street Level Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>One and Two Apartment ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>Street Level Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>A countried and green ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>A Five Storied Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
						</ul> -->



					</div><!-- Content inner end -->
				</div><!-- Content Col end -->


			</div><!-- Row end -->
		</div><!-- Conatiner end -->
	</section><!-- Main container end -->

	<?php include "footer.php" ?>