<?php include "header.php" ?>

	
	<div id="banner-area" class="banner-area" style="background-image:url(images/about.jpg)">
		<div class="banner-text">
     		<div class="container">
	        	<div class="row">
	        		<div class="col-xs-12">
	        			<div class="banner-heading">
	        				<h1 class="border-title border-left" style="font-family:Bookman Old Style;">About Us</h1>
	        				<ol class="breadcrumb">
	        					<li style="font-family:Bookman Old Style;">Home</li>
	        					<!-- <li>Company</li> -->
	        					<li><a href="#" style="font-family:Bookman Old Style;">About Us</a></li>
	        				</ol>
	        			</div>
	        		</div><!-- Col end -->
	        	</div><!-- Row end -->
       	</div><!-- Container end -->
    	</div><!-- Banner text end -->
	</div><!-- Banner area end --> 


	<section id="main-container" class="main-container">
		<div class="container">

			<div class="row">
				<div class="col-md-6">
						<h3 style="font-family:Bookman Old Style;">Overview</h3>
						<p style="font-family:Bookman Old Style;text-align:justify;">MVG Consultancy was founded in 2009 with a distinctive vision and structure aimed at achieving two basic goals - to place our clients' interests first and to lead our profession in creating value for our clients through the assessment and recruitment of top-level management resources. </p>
						<p style="font-family:Bookman Old Style;text-align:justify;">MVG Consultancy  is an executive search Company with primary focus on search and recruitment of Topnotch professionals at Senior management level across industries.</p>
						<div class="img-box">
							<div class="img-box-small" style="font-family:Bookman Old Style;">Hired Person</div>
							<figure><img class="img-responsive" src="images/hh.jpg" alt=""></figure>
							<figure><img class="img-responsive" src="images/hh1.jpg" alt=""></figure>
							<figure><img class="img-responsive" src="images/hh2.jpg" alt=""></figure>
						</div>
				</div><!-- Col end -->

				<div class="col-md-6">
					<h3 style="font-family:Bookman Old Style;">Our Working Philosophy</h3>
					<p style="font-family:Bookman Old Style;text-align:justify;">Provide innovative and optimized engineering solutions to clients.Foster a work culture that encourages creativity and provides opportunities for growth and development of its people.Maintain highest standards of technical delivery in an environment of uncompromising integrity and honesty.</p>

					<h3 style="font-family:Bookman Old Style;">Our Core Values</h3>
					
					<div class="panel-group" id="accordion">
	              	<div class="panel panel-default">
		                <div class="panel-heading">
			                <h4 class="panel-title"> 
			                	<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">The People</a> 
			                </h4>
		                </div>
		                <div id="collapseOne" class="panel-collapse collapse in">
		                  <div class="panel-body">
		                    	<p style="font-family:Bookman Old Style;text-align:justify;">Searching for a job can be tedious and frustrating  especially when you spend countless hours on a traditional job board only to find nothing.</p>
		                  </div>
		                </div>
	              	</div><!--/ Panel 1 end-->

	              	<div class="panel panel-default">
		                <div class="panel-heading">
			                <h4 class="panel-title">
			                	<a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapseTwo" style="font-family:Bookman Old Style;"> The Platform</a>
			            	</h4>
		                </div>
		                <div id="collapseTwo" class="panel-collapse collapse">
		                  <div class="panel-body">
			                  <p style="font-family:Bookman Old Style;text-align:justify;">Get to know the whole employment ecosystem. We're the only platform that brings job seekers, recruiters, and employers together in one place.</p>
		                  </div>
		                </div>
	              	</div><!--/ Panel 2 end-->


	              	<div class="panel panel-default">
		                <div class="panel-heading">
			                <h4 class="panel-title">
			                	<a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapseThree" style="font-family:Bookman Old Style;"> The Power</a>
			            	</h4>
		                </div>
		                <div id="collapseThree" class="panel-collapse collapse">
		                  <div class="panel-body">
		                    	<p style="font-family:Bookman Old Style;text-align:justify;">MVG consulting sifts through six million jobs and leverages the largest network of recruiters on the planet to bring you the best opportunities.</p>
		                  </div>
		                </div>
	              	</div><!--/ Panel 3 end-->

            	</div><!--/ Accordion end -->

				</div><!-- Col end -->
			</div><!-- Content row end -->

		</div><!-- Conatiner end -->
	</section><!-- Main container end -->


	<section id="facts" class="facts-area bg-overlay no-padding" style="background-image:url(images/bbb.jpg)">
		<div class="container">
			<div class="row">
					<div class="facts-wrapper">
						<div class="col-sm-3 ts-facts">
							<div class="ts-facts-img">
								<img src="images/icon-image/fact1.png" alt="" />
							</div>
							<div class="ts-facts-content">
								<h2 class="ts-facts-num"><span class="counterUp">789</span></h2>
								<h3 class="ts-facts-title" style="font-family:Bookman Old Style;">Jobs offered</h3>
							</div>
						</div><!-- Col end -->

						<div class="col-sm-3 ts-facts">
							<div class="ts-facts-img">
								<img src="images/icon-image/fact2.png" alt="" />
							</div>
							<div class="ts-facts-content">
								<h2 class="ts-facts-num"><span class="counterUp">447</span></h2>
								<h3 class="ts-facts-title" style="font-family:Bookman Old Style;">Persons Placed</h3>
							</div>
						</div><!-- Col end -->

						<div class="col-sm-3 ts-facts">
							<div class="ts-facts-img">
								<img src="images/icon-image/fact3.png" alt="" />
							</div>
							<div class="ts-facts-content">
								<h2 class="ts-facts-num"><span class="counterUp">200</span></h2>
								<h3 class="ts-facts-title" style="font-family:Bookman Old Style;">MNC Companies</h3>
							</div>
						</div><!-- Col end -->

						<div class="col-sm-3 ts-facts">
							<div class="ts-facts-img">
								<img src="images/icon-image/fact4.png" alt="" />
							</div>
							<div class="ts-facts-content">
								<h2 class="ts-facts-num"><span class="counterUp">2400</span></h2>
								<h3 class="ts-facts-title" style="font-family:Bookman Old Style;">Resumes Received</h3>
							</div>
						</div><!-- Col end -->

					</div> <!-- Facts end -->
			</div><!--/ Content row end -->
		</div><!--/ Container end -->
	</section><!-- Facts end -->

<br/>
	

	<?php include "footer.php" ?>