<?php include "header.php" ?>
	
	<div id="banner-area" class="banner-area" style="background-image:url(images/empp.jpg)">
		<div class="banner-text">
     		<div class="container">
	        	<div class="row">
	        		<div class="col-xs-12">
	        			<div class="banner-heading">
	        				<h1 class="border-title border-left" style="font-family:Bookman Old Style;">Employer</h1>
	        				<ol class="breadcrumb">
	        					<li style="font-family:Bookman Old Style;">Home</li>
	        					<!-- <li>Projects</li> -->
	        					<li><a href="#" style="font-family:Bookman Old Style;">Employer</a></li>
	        				</ol>
	        			</div>
	        		</div><!-- Col end -->
	        	</div><!-- Row end -->
       	</div><!-- Container end -->
    	</div><!-- Banner text end -->
	</div><!-- Banner area end --> 

	<section id="main-container" class="main-container">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div id="page-slider" class="owl-carousel owl-theme page-slider page-slider-small">
						<!-- <div class="item">
							<img src="images/projects/project1.jpg" alt="" />
						</div> -->

						<!-- <div class="item">
							<img src="images/projects/project2.jpg" alt="" />
						</div>
					</div> --><!-- Page slider end -->

					<h2 class="project-title" style="text-align:center;">Employer</h2>
				</div><!-- Slider col end -->

			</div><!-- Row end -->

			<div class="gap-20"></div>

			<div class="row">
				<div class="col-sm-3">
					<ul class="project-info unstyled">
						<li>
							<!-- <div class="project-info-label">Education</div> -->
							<!-- <div class="project-info-content">Pransbay Powers Authority</div> -->
						</li>
						<li>
							<!-- <div class="project-info-label">Finance</div> -->
							<!-- <div class="project-info-content">Dlarke Pelli Incorp</div> -->
						</li>
						<li>
							<!-- <div class="project-info-label">Information Technology</div> -->
							<!-- <div class="project-info-content">McLean, VA</div> -->
						</li>
						<li>
							<!-- <div class="project-info-label">Realestate</div> -->
							<!-- <div class="project-info-content">65,000 SF</div> -->
						</li>
						<li>
							<!-- <div class="project-info-label">Hospitality</div> -->
							<!-- <div class="project-info-content">2014</div> -->
						</li>
						<li>
							<!-- <div class="project-info-label">Categories</div> -->
							<!-- <div class="project-info-content">Commercial, Interiors</div> -->
						</li>
						<li>
							<div class="project-link">
								<!-- <a class="btn btn-primary" target="_blank" href="#">View Project</a> -->
							</div>
						</li>
					</ul>

				</div><!-- Content Col end -->

				<div class="col-sm-9">
					<div class="content-inner-page">
			
						<p style="text-align:center;margin-left:-6cm;font-family:Bookman Old Style;text-align:justify;">One of the main challenges faced by almost every organisation, is to fit the right person at the right post. Recruiting and selecting candidates has become one of the most resource consuming process both in terms of money and time. 

MVG Consultants, one of the unparalleled overseas placement bureau helps organisations recruit quality manpower, without having to go through the cumbersome recruitment process.

We are in the business of effectively understanding your manpower requirements, procuring the candidate with the desired profile and building trusting relationships. </p>
						<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis semper lacus scelerisque, aliquam leo quis, porttitor leo. Fusce lectus ex, pretium efficitur suscipit sed, faucibus vel elit Integer adipiscing erat eget risus sollicitudin pellentesque et non erat. Proin suscipit convallis facilisis. Fusce lectus ex, pretium efficitur suscipit sed, faucibus vel elit. Sed eu vestibulum leo. Phasellus at quam id elit hendrerit semper feugiat id nunc ultrices ultrices sapien.</p> -->
						<!-- <ul class="list-arrow">
							<li>Street Level Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>One and Two Apartment ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>Street Level Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>A countried and green ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>A Five Storied Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
						</ul> -->



					</div><!-- Content inner end -->
				</div><!-- Content Col end -->


			</div><!-- Row end -->
		</div><!-- Conatiner end -->
	</section><!-- Main container end -->

	<?php include "footer.php" ?>