<?php include "header.php" ?>
	<div id="banner-area" class="banner-area" style="background-image:url(images/rec.jpg)">
		<div class="banner-text">
     		<div class="container">
	        	<div class="row">
	        		<div class="col-xs-12">
	        			<div class="banner-heading">
	        				<h1 class="border-title border-left">Recruiting</h1>
	        				<ol class="breadcrumb">
	        					<li>Home</li>
	        					<!-- <li>Services</li> -->
	        					<li><a href="#">Recruiting</a></li>
	        				</ol>
	        			</div>
	        		</div><!-- Col end -->
	        	</div><!-- Row end -->
       	</div><!-- Container end -->
    	</div><!-- Banner text end -->
	</div><!-- Banner area end --> 

	<section id="main-container" class="main-container">
		<div class="container">
			<div class="row">

				<div class="col-lg-3 col-md-3 col-sm-12">
					<div class="sidebar sidebar-left">
						<div class="widget">
							<ul class="nav nav-tabs nav-stacked service-menu">
								<li class="active"><a href="#">Training</a></li>
								<li><a href="#">Recruiting</a></li>
								<li><a href="#">Placements</a></li>
								<li><a href="#">Realestate</a></li>
								<li><a href="#">Hospitality</a></li>
								<li><a href="#">Information & Technology</a></li>
							</ul>
						</div><!-- Widget end -->

						<div class="widget">
							<div class="quote-item quote-border">
					         <!-- <div class="quote-text-border"> -->
					           <!-- Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. -->
					         <!-- </div> -->

					         <div class="quote-item-footer">
					         	<!-- <img class="testimonial-thumb" src="images/clients/testimonial2.png" alt="testimonial">
					         	<div class="quote-item-info">
					         		<h3 class="quote-author">Weldon Cash</h3>
						         	<span class="quote-subtext">CEO, First Choice Group</span>
					         	</div> -->
					         </div>
					     </div><!-- Quote item end -->

						</div><!-- Widget end -->

					</div><!-- Sidebar end -->
				</div><!-- Sidebar Col end -->
				<div class="col-lg-9 col-md-9 col-sm-12">
					<div class="content-inner-page">

						<h2 class="border-title border-left">Recruiting</h2>

						<div class="row">
							<div class="col-md-6">
								<p style="font-family:Bookman Old Style;text-align:justify;">At MVG Consultancy we have designed a pragmatic framework that is result oriented and caters to the most complex demands of our client. Through extensive use of technology we are evolving the workforce dynamics to provide cutting-edge consulting solutions.</p>
								<p style="font-family:Bookman Old Style;text-align:justify;">The planning phase for us means understanding the client requirements and the utility of such requirements to strengthen our search. On the basis, of the requirements we further work to plan a strategy that would follow to serve the needs. </p>
							</div><!-- col end -->
							<div class="col-md-6">
								<div class="embed-responsive">
								<!-- Change the url -->
								<img src="images/rect.jpg">
								</div>
							</div><!-- col end -->
						</div><!-- 1st row end-->

						<div class="gap-40"></div>

						
	</section><!-- Main container end -->

	<?php include "footer.php" ?>