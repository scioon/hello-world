<?php
session_start();
echo 'welcome ' .$_SESSION['username'];
echo '<br><a href="adminlogin.php?action=logout">Logout</a>';
?>