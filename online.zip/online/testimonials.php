<?php include "header.php" ?>
	
	<div id="banner-area" class="banner-area" style="background-image:url(images/test.jpg)">
		<div class="banner-text">
     		<div class="container">
	        	<div class="row">
	        		<div class="col-xs-12">
	        			<div class="banner-heading">
	        				<h1 class="border-title border-left">Testimonials</h1>
	        				<ol class="breadcrumb">
	        					<li>Home</li>
	        					<!-- <li>Company</li> -->
	        					<li><a href="#">Testimonials</a></li>
	        				</ol>
	        			</div>
	        		</div><!-- Col end -->
	        	</div><!-- Row end -->
       	</div><!-- Container end -->
    	</div><!-- Banner text end -->
	</div><!-- Banner area end --> 


	<section id="main-container" class="main-container">
		<div class="container">
			<div class="row text-center">
				<h2 class="border-title">What People Said</h2>
				<p class="border-sub-title">
					<!-- Collaboratively administrate empowered markets via plug-and-play networks. -->
				</p>
			</div><!--/ Title row end -->


			<div class="row">
				<div class="col-md-4 col-sm-6">
					<div class="quote-item quote-border">
			         <div class="quote-text-border">
			           "The service received has been very good. VT Manpower has been in regular contact with me to check my progress. I have been pleased with the regular contact and when I have a query VT Manpower have always been there to help.”
			         </div>

			         <div class="quote-item-footer">
			         	<img class="testimonial-thumb" src="images/ts1.jpeg" alt="testimonial">
			         	<div class="quote-item-info">
			         		<h3 class="quote-author">Gabriel Denis</h3>
				         	<span class="quote-subtext">Chairman, Okt Industries</span>
			         	</div>
			         </div>
			     </div><!-- Quote item end -->
				</div><!-- End col md 4 -->

				<div class="col-md-4 col-sm-6">
					<div class="quote-item quote-border">
			         <div class="quote-text-border">
			      “I have always been very impressed with the quality of service I have received from VT Manpower. They are reliable, efficient, professional and – above all – truthful. This alone sets them out from much of their competition.”
			         </div>

			         <div class="quote-item-footer">
			         	<img class="testimonial-thumb" src="images/ts1.jpeg" alt="testimonial">
			         	<div class="quote-item-info">
			         		<h3 class="quote-author">Weldon Cash</h3>
				         	<span class="quote-subtext">CEO, First Choice Group</span>
			         	</div>
			         </div>
			     </div><!-- Quote item end -->
				</div><!-- End col md 4 -->

				<div class="col-md-4 col-sm-6">
					<div class="quote-item quote-border">
			         <div class="quote-text-border">
			         “Very Positive! Staffs are always helpful and obliging. Also they found me the exact job that I wanted in the location that I wanted. They also helped my friends to get some suitable jobs”
			         </div>

			         <div class="quote-item-footer">
			         	<img class="testimonial-thumb" src="images/ts1.jpeg" alt="testimonial">
			         	<div class="quote-item-info">
			         		<h3 class="quote-author">Hyram Izzy</h3>
				         	<span class="quote-subtext">Director, AKT Group</span>
			         	</div>
			         </div>
			     </div><!-- Quote item end -->
				</div><!-- End col md 4 -->

			</div><!-- Content row end -->

		</div><!-- Container end -->
	</section><!-- Main container end -->

	
	<?php include "footer.php" ?>