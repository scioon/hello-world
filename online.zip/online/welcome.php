<?php
session_start();
echo 'welcome ' .$_SESSION['username'];
echo '<br><a href="login.php?action=logout">Logout</a>';
?>