<?php include "header.php" ?>
	<div id="banner-area" class="banner-area" style="background-image:url(images/place.jpg)">
		<div class="banner-text">
     		<div class="container">
	        	<div class="row">
	        		<div class="col-xs-12">
	        			<div class="banner-heading">
	        				<h1 class="border-title border-left">Placements</h1>
	        				<ol class="breadcrumb">
	        					<li>Home</li>
	        					<!-- <li>Services</li> -->
	        					<li><a href="#">Placements</a></li>
	        				</ol>
	        			</div>
	        		</div><!-- Col end -->
	        	</div><!-- Row end -->
       	</div><!-- Container end -->
    	</div><!-- Banner text end -->
	</div><!-- Banner area end --> 

	<section id="main-container" class="main-container">
		<div class="container">
			<div class="row">

				<div class="col-lg-3 col-md-3 col-sm-12">
					<div class="sidebar sidebar-left">
						<div class="widget">
							<ul class="nav nav-tabs nav-stacked service-menu">
								<li class="active"><a href="#">Training</a></li>
								<li><a href="#">Recruiting</a></li>
								<li><a href="#">Placements</a></li>
								<li><a href="#">Realestate</a></li>
								<li><a href="#">Hospitality</a></li>
								<li><a href="#">Information & Technology</a></li>
							</ul>
						</div><!-- Widget end -->

						<div class="widget">
							<div class="quote-item quote-border">
					         <!-- <div class="quote-text-border">
					           Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.
					         </div> -->

					         <div class="quote-item-footer">
					         	<!-- <img class="testimonial-thumb" src="images/clients/testimonial2.png" alt="testimonial">
					         	<div class="quote-item-info">
					         		<h3 class="quote-author">Weldon Cash</h3>
						         	<span class="quote-subtext">CEO, First Choice Group</span>
					         	</div> -->
					         </div>
					     </div><!-- Quote item end -->

						</div><!-- Widget end -->

					</div><!-- Sidebar end -->
				</div><!-- Sidebar Col end -->

				<div class="col-lg-9 col-md-9 col-sm-12">
					<div class="content-inner-page">

						<h2 class="border-title border-left">Placements</h2>

						<div class="row">
							<div class="col-md-6">
								<p style="font-family:Bookman Old Style;text-align:justify;">The major objective of campus placement is to identify the talented and qualified professionals before they complete their education. This process reduces the time for an industry to pick the candidates according to their need.It is a cumbersome activity and hence majority of the companies find it difficult to trace the right talent. Many students do not understand the importance of placement training that is being imparted, whether it is an aptitude training or soft skills. </p>
								<!-- <p style="font-family:Bookman Old Style;text-align:justify;">They show the least interest in this due to various factors viz., projects, assignments or more of activities loaded by the colleges as part of their curriculum thinking that it is not useful. It is the responsibility of the companies training on placement to make the students equipped on all aspects of career development along with creating a very good impact in them which makes them feel every minute they spend in the placement training session is worth being there and will help them in getting placed in their dream companies.</p> -->
							</div><!-- col end -->
							<div class="col-md-6">
								<div class="embed-responsive">
								<!-- Change the url -->
								<img src="images/pla.jpg">
								</div>
							</div><!-- col end -->
						</div><!-- 1st row end-->

						<div class="gap-40"></div>

				
	</section><!-- Main container end -->

	<?php include "footer.php" ?>