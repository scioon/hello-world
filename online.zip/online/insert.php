<?php
$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
$db = mysql_select_db("student", $connection); // Selecting Database from Server
if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
$id = $_POST['id'];
$name = $_POST['name'];

$address = $_POST['address'];
$city= $_POST['city'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$qualification=$_POST['qualification'];
$gender = $_POST['gender'];
$birthdate = $_POST['birthdate'];

$status=$_POST['status'];
$username=$_POST['username'];
$password=$_POST['password'];
$question= $_POST['question'];
$answer = $_POST['answer'];

if($name !=''||$email !=''){
//Insert Query of SQL
$query = mysql_query("insert into users(id, name, address, city, email, mobile, qualification, gender, birthdate, resume, status, username, password, question, answer) values ('$id', '$name',  '$address', '$city', '$email', '$mobile', '$qualification', '$gender',   '$birthdate', '$status',  '$username', '$password', '$question', '$answer')");
echo "<br/><br/><span>Data Inserted successfully...!!</span>";
}
else{
echo "<p>Insertion Failed <br/> Some Fields are Blank....!!</p>";
}
}
mysql_close($connection); // Closing Connection with Server
?>