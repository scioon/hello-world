<?php include "header.php" ?>
	<div id="banner-area" class="banner-area" style="background-image:url(images/tra.jpg)">
		<div class="banner-text">
     		<div class="container">
	        	<div class="row">
	        		<div class="col-xs-12">
	        			<div class="banner-heading">
	        				<h1 class="border-title border-left">Training</h1>
	        				<ol class="breadcrumb">
	        					<li>Home</li>
	        					<!-- <li>Services</li> -->
	        					<li><a href="#">Training</a></li>
	        				</ol>
	        			</div>
	        		</div><!-- Col end -->
	        	</div><!-- Row end -->
       	</div><!-- Container end -->
    	</div><!-- Banner text end -->
	</div><!-- Banner area end --> 

	<section id="main-container" class="main-container">
		<div class="container">
			<div class="row">

				<div class="col-lg-3 col-md-3 col-sm-12">
					<div class="sidebar sidebar-left">
						<div class="widget">
							<ul class="nav nav-tabs nav-stacked service-menu">
								<li class="active"><a href="service-single1.html">Training</a></li>
								<li><a href="#">Recruiting</a></li>
								<li><a href="#">Placements</a></li>
								<li><a href="#">Realestate</a></li>
								<li><a href="#">Hospitality</a></li>
								<li><a href="#">Information & Technology</a></li>
							</ul>
						</div><!-- Widget end -->

						<div class="widget">
							<div class="quote-item quote-border">
					         <!-- <div class="quote-text-border"> -->
					           <!-- Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. -->
					         <!-- </div> -->

					         <div class="quote-item-footer">
					         	<!-- <img class="testimonial-thumb" src="images/clients/testimonial2.png" alt="testimonial">
					         	<div class="quote-item-info">
					         		<h3 class="quote-author">Weldon Cash</h3>
						         	<span class="quote-subtext">CEO, First Choice Group</span>
					         	</div> -->
					         </div>
					     </div><!-- Quote item end -->

						</div><!-- Widget end -->

					</div><!-- Sidebar end -->
				</div><!-- Sidebar Col end -->

				<div class="col-lg-9 col-md-9 col-sm-12">
					<div class="content-inner-page">

						<h2 class="border-title border-left">Training</h2>

						<div class="row">
							<div class="col-md-6">
								<p style="font-family:Bookman Old Style;text-align:justify;">MVG Consultancy has centers for Advanced Learning which have been specially created to provide quality Management Education to working professionals. MVG Consultancy expertise in the design and management of distributed education programs provides the study-environment for students, the technology platform, and the allied education services and processes that make up the total teaching-learning experience. </p>
								<p style="font-family:Bookman Old Style;text-align:justify;">Our IT training programs and IT Certifications help professionals to acquire skills in cutting-edge technologies that are being deployed in todays organizations and get an edge over their colleagues. </p>
							</div><!-- col end -->
							<div class="col-md-6">
								<div class="embed-responsive">
								<!-- Change the url -->
								<img src="images/so.jpg">
								</div>
							</div><!-- col end -->
						</div><!-- 1st row end-->

						<div class="gap-40"></div>

						
	</section><!-- Main container end -->

	<?php include "footer.php" ?>