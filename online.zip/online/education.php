<?php include "header.php" ?>
	
	<div id="banner-area" class="banner-area" style="background-image:url(images/education.jpg)">
		<div class="banner-text">
     		<div class="container">
	        	<div class="row">
	        		<div class="col-xs-12">
	        			<div class="banner-heading">
	        				<h1 class="border-title border-left">Education</h1>
	        				<ol class="breadcrumb">
	        					<li>Home</li>
	        					<!-- <li>Projects</li> -->
	        					<li><a href="#">Education</a></li>
	        				</ol>
	        			</div>
	        		</div><!-- Col end -->
	        	</div><!-- Row end -->
       	</div><!-- Container end -->
    	</div><!-- Banner text end -->
	</div><!-- Banner area end --> 

	<section id="main-container" class="main-container">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div id="page-slider" class="owl-carousel owl-theme page-slider page-slider-small">
						<!-- <div class="item">
							<img src="images/projects/project1.jpg" alt="" />
						</div> -->

						<!-- <div class="item">
							<img src="images/projects/project2.jpg" alt="" />
						</div>
					</div> --><!-- Page slider end -->

					<h2 class="project-title" style="text-align:center;">Education</h2>
				</div><!-- Slider col end -->

			</div><!-- Row end -->

			<div class="gap-20"></div>

			<div class="row">
				<div class="col-sm-3">
					<ul class="project-info unstyled">
						<li>
							<div class="project-info-label">Education</div>
							<!-- <div class="project-info-content">Pransbay Powers Authority</div> -->
						</li>
						<li>
							<div class="project-info-label">Finance</div>
							<!-- <div class="project-info-content">Dlarke Pelli Incorp</div> -->
						</li>
						<li>
							<div class="project-info-label">Information Technology</div>
							<!-- <div class="project-info-content">McLean, VA</div> -->
						</li>
						<li>
							<div class="project-info-label">Realestate</div>
							<!-- <div class="project-info-content">65,000 SF</div> -->
						</li>
						<li>
							<div class="project-info-label">Hospitality</div>
							<!-- <div class="project-info-content">2014</div> -->
						</li>
						<li>
							<!-- <div class="project-info-label">Categories</div> -->
							<!-- <div class="project-info-content">Commercial, Interiors</div> -->
						</li>
						<li>
							<div class="project-link">
								<!-- <a class="btn btn-primary" target="_blank" href="#">View Project</a> -->
							</div>
						</li>
					</ul>

				</div><!-- Content Col end -->

				<div class="col-sm-9">
					<div class="content-inner-page">
			
						<p style="font-family:Bookman Old Style;text-align:justify;">India has one of the largest higher education systems in the world. The economic growth of the country is leading to a surge in demand for more engineers, management graduates, computer engineers, and many other professionals. Given the huge opportunity in the sector, there is a growing trend of private sector participation. According to a recent FICCI report on the private sector's participation in the Indian higher education, the country has displayed impressive growth over the last decade to become one of the world's largest systems of higher education. The number of institutions has grown at a CAGR of 11% while student enrolment has grown at a CAGR of 6%.

Given the Indian government's radical reforms and massive expansion plans in the education sector, a lot more schools and colleges are going to be opened across the country, including rural areas. According to the ASER (2012) report, over the last six years, private school enrolment in rural India has gone up by 5.5 percentage points.</p>
						<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis semper lacus scelerisque, aliquam leo quis, porttitor leo. Fusce lectus ex, pretium efficitur suscipit sed, faucibus vel elit Integer adipiscing erat eget risus sollicitudin pellentesque et non erat. Proin suscipit convallis facilisis. Fusce lectus ex, pretium efficitur suscipit sed, faucibus vel elit. Sed eu vestibulum leo. Phasellus at quam id elit hendrerit semper feugiat id nunc ultrices ultrices sapien.</p> -->
						<!-- <ul class="list-arrow">
							<li>Street Level Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>One and Two Apartment ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>Street Level Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>A countried and green ipsum dolor sit amet, consectetur adipiscing elit</li>
							<li>A Five Storied Lorem ipsum dolor sit amet, consectetur adipiscing elit</li>
						</ul> -->



					</div><!-- Content inner end -->
				</div><!-- Content Col end -->


			</div><!-- Row end -->
		</div><!-- Conatiner end -->
	</section><!-- Main container end -->

	<?php include "footer.php" ?>