<head>
<style>
.facts-area1 {
   padding: 100px 0;
   color: #ffffff;
   background-color: #ffc000;
   background-image: url(../images/bbb.jpg);
   background-repeat: no-repeat;
   background-size: cover;
   background-attachment: fixed;
   background-position: 50% 50%;
}
</style>
</head>
<?php include "header.php"?>
	<!-- Carousel -->
 	<div id="main-slide" class="carousel slide" data-ride="carousel">

		<!-- Indicators -->
		<ol class="carousel-indicators visible-lg visible-md">
		  	<li data-target="#main-slide" data-slide-to="0" class="active"></li>
		   <li data-target="#main-slide" data-slide-to="1"></li>
		   <li data-target="#main-slide" data-slide-to="2"></li>
		</ol><!--/ Indicators end-->

		<!-- Carousel inner -->
		<div class="carousel-inner">

			<div class="item active" style="background-image:url(images/s1.jpg)">
           	<div class="slider-content text-left">
               <div class="col-md-12">
                  <!-- <h2 class="slide-title-box animated2">27 Years Young</h2>
                  <h3 class="slide-title animated3">With a Bench Strength of</h3>
                  <h3 class="slide-sub-title animated3">1170+ Construction Experts</h3>	
                  <p class="animated3">
                   	<a href="#" class="slider btn btn-primary border">Our Services</a>
                  </p>	      -->
               </div>
           	</div>
		   </div><!--/ Carousel item 1 end -->

			<div class="item" style="background-image:url(images/s2.jpg)">
           	<div class="slider-content">
               <div class="col-md-12 text-center">
                  <!-- <h2 class="slide-title animated4">We are the Leader in</h2>
                  <h3 class="slide-sub-title animated5">Construction Industry</h3>	
                  <p class="slider-description lead animated3">We will deal with your failure that determines how you achieve success.</p>
                   <p>
                   	<a href="#" class="slider btn btn-primary">Our Services</a>
                   	<a href="#" class="slider btn btn-primary border">Call Now</a>
                   </p>	      -->
               </div>
           	</div>
		   </div><!--/ Carousel item 2 end -->

		   <div class="item" style="background-image:url(images/s3.jpg)">
            <div class="slider-content text-right">
               <div class="col-md-12">
                   <!-- <h2 class="slide-title animated6">Meet Our Engineers</h2>
                   <h3 class="slide-sub-title animated7">We care our Cummunities</h3>	
                   <p class="slider-description lead animated7">We will deal with your failure that determines how you achieve success.</p> -->
                   <!-- <p>
                   	<a href="#" class="slider btn btn-primary">Get Free Quote</a>
                   	<a href="#" class="slider btn btn-primary border">Learn More</a>
                   </p>	      -->
               </div>
           	</div>
		    </div><!--/ Carousel item 3 end -->
		    
		</div><!-- Carousel inner end-->

		<!-- Controllers -->
		<a class="left carousel-control" href="#main-slide" data-slide="prev">
	    	<span><i class="fa fa-angle-left"></i></span>
		</a>
		<a class="right carousel-control" href="#main-slide" data-slide="next">
	    	<span><i class="fa fa-angle-right"></i></span>
		</a>
	</div><!--/ Carousel end -->  

	<section class="call-to-action">
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-xs-12">
					<h3 class="call-to-action-title" style="font-family:Bookman Old Style;">We are committed to providing the best jobs.</h3>
				</div>

				<div class="col-md-2 col-xs-12">
					<div class="call-to-action-btn-angle">
						<a href="#" style="font-family:Bookman Old Style;"><i class="fa fa-paper-plane" ></i>Contact Us</a>
					</div>
				</div>
			</div><!-- Row end -->
		</div><!-- Container end -->
	</section><!-- Call to action end -->

	<section id="ts-features" class="ts-features">
		<div class="container">
			<div class="row">
				<div class="col-sm-6">
					<div class="intro-feature">
						<h3 style="font-family:Bookman Old Style;">Hire the right candidates quickly and cost effectively.
</h3>
						<p style="text-align:justify;font-family:Bookman Old Style;">Hiring a coveted candidate is like winning a new customer. You need to think like a marketer—and you’ll need the right tools, too. Unlike a traditional Applicant Tracking System, MVG Consulting Hire is part of a complete recruiting not only software platform that accelerates the entire recruiting process from sourcing to onboarding.Top companies with primary focus on search and recruitment of Topnotch professionals at Senior management level across industries.</p>
						<p><a class="intro-link" href="#" style="font-family:Bookman Old Style;"><i class="fa fa-caret-right"> </i> More Information</a></p>
						<div class="img-box">
							<div class="img-box-small" style="font-family:Bookman Old Style;">Hired Person</div>
							<figure><img class="img-responsive" src="images/hh.jpg" alt=""></figure>
							<figure><img class="img-responsive" src="images/hh1.jpg" alt=""></figure>
							<figure><img class="img-responsive" src="images/hh2.jpg" alt=""></figure>
						</div>
					</div><!-- Intro box end -->
				</div><!-- Col end -->

				<div class="col-sm-6">

					<div class="featured-tab">
						<ul class="nav nav-tabs">
						  	<li class="active">
						  		<a class="animated fadeIn" href="#tab_a" data-toggle="tab">
						  			<span class="tab-head">
										<span class="tab-text-title" style="font-family:Bookman Old Style;">The People</span>					
									</span>
						  		</a>
						  	</li>
						  	<li>
							  	<a class="animated fadeIn" href="#tab_b" data-toggle="tab">
							  		<span class="tab-head">
										<span class="tab-text-title" style="font-family:Bookman Old Style;">The Platform</span>					
									</span>
							  	</a>
							</li>
						 	<li>
							  	<a class="animated fadeIn" href="#tab_c" data-toggle="tab">
							  		<span class="tab-head">
										<span class="tab-text-title" style="font-family:Bookman Old Style;">The Power</span>					
									</span>
							  	</a>
							</li>
						</ul>

						<div class="tab-content">
					      <div class="tab-pane active animated fadeInRight" id="tab_a">
					        	<div class="tab-wrapper">
						        
									<div class="ts-service-box">
										<span class="ts-service-icon"><i class="fa fa-trophy"> </i></span>
										<div class="ts-service-box-content">
											<h3 style="font-family:Bookman Old Style;">We Refer the people.</h3>
											<p style="font-family:Bookman Old Style;text-align:justify;">Searching for a job can be tedious and frustrating  especially when you spend countless hours on a traditional job board only to find nothing. Recruiter is a new kind of recruiting platform. We change the way people look for work.</p>
										</div>
									</div><!-- Service 1 end -->

									<div class="ts-service-box">
										<span class="ts-service-icon"><i class="fa fa-sliders"> </i></span>
										<div class="ts-service-box-content">
											<h3 style="font-family:Bookman Old Style;">We Build Platform.</h3>
											<p style="font-family:Bookman Old Style;text-align:justify;">Get to know the whole employment ecosystem. We're the only platform that brings job seekers, recruiters, and employers together in one place. We have thousands of expert-level career advice articles to help you be the best candidate you can be.</p>
										</div>
									</div><!-- Service 2 end -->

									<div class="ts-service-box">
										<span class="ts-service-icon"><i class="fa fa-thumbs-up"> </i></span>
										<div class="ts-service-box-content">
											<h3 style="font-family:Bookman Old Style;">We develope the power.</h3>
											<p style="font-family:Bookman Old Style;text-align:justify;">MVG consulting sifts through six million jobs and leverages the largest network of recruiters on the planet to bring you the best opportunities. </p>
										</div>
									</div><!-- Service 3 end -->

					        	</div><!-- Tab wrapper end -->
					      </div><!-- Tab pane 1 end -->

				        <div class="tab-pane animated fadeInRight" id="tab_b">
				            <!-- <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p> -->

				            <div class="ts-service-box">
									<span class="ts-service-icon"><i class="fa fa-users"> </i></span>
									<div class="ts-service-box-content">
										<h3 style="font-family:Bookman Old Style;">A Team of Recruiting System</h3>
										<p style="font-family:Bookman Old Style;">Recruiting is in our DNA. We know recruiting.</p>
									</div>
								</div><!-- Service 1 end -->

								<div class="ts-service-box">
									<span class="ts-service-icon">
										<i class="fa fa-hourglass"> </i>
									</span>
									<div class="ts-service-box-content">
										<h3 style="font-family:Bookman Old Style;">Placement Process</h3>
										<p style="font-family:Bookman Old Style;">Our friendly staff helps with feedback and the placement process.</p>
									</div>
								</div><!-- Service 2 end -->
				        </div><!-- Tab pane 2 end -->

				        	<div class="tab-pane animated fadeInLeft" id="tab_c">
				            <img class="pull-left" src="images/hhh.jpg" alt="" />
				        <h2 style="text-align:justify; font-family:Bookman Old Style;">   Why Recruiters On Line?</h2>

 <p style="font-family:Bookman Old Style;text-align:justify;">Because.... We've been Inventing the Future of Recruiting since 1995. For nearly two decades, RON has provided tools and technologies to help hundreds of 3rd party recruiters and staffing firms.

Recruitersonline provides Web sites, job publishing, Splits, and access to fresh resumes. Make Recruiters Online your first and last stop on the internet. Our mission at Recruiters Online Network is to help 3rd party recruiters be more successful in the search and placement industry by creating your web-based office - You Just need to bring the coffee.</p>
				        	</div><!-- Tab pane 3 end -->	
						</div><!-- tab content -->
					</div><!-- Featured tab end -->

				</div><!-- Col end -->
			</div><!-- Row end -->
		</div><!-- Container end -->
	</section><!-- Feature are end -->

  	<section id="facts" class="facts-area bg-overlay no-padding" style=" background-image: url(images/bbb.jpg);">
		<div class="container">
			<div class="row">
				<div class="facts-wrapper">
					<div class="col-sm-3 ts-facts">
						<div class="ts-facts-img">
							<img src="images/icon-image/fact1.png" alt="" />
						</div>
						<div class="ts-facts-content">
							<h2 class="ts-facts-num"><span class="counterUp">789</span></h2>
							<h3 class="ts-facts-title" style="font-family:Bookman Old Style;">Jobs Offered</h3>
						</div>
					</div><!-- Col end -->

					<div class="col-sm-3 ts-facts">
						<div class="ts-facts-img">
							<img src="images/icon-image/fact2.png" alt="" />
						</div>
						<div class="ts-facts-content">
							<h2 class="ts-facts-num"><span class="counterUp">447</span></h2>
							<h3 class="ts-facts-title" style="font-family:Bookman Old Style;">Persons Placed</h3>
						</div>
					</div><!-- Col end -->

					<div class="col-sm-3 ts-facts">
						<div class="ts-facts-img">
							<img src="images/icon-image/fact3.png" alt="" />
						</div>
						<div class="ts-facts-content">
							<h2 class="ts-facts-num"><span class="counterUp">200</span></h2>
							<h3 class="ts-facts-title" style="font-family:Bookman Old Style;">MNC Companies</h3>
						</div>
					</div><!-- Col end -->

					<div class="col-sm-3 ts-facts">
						<div class="ts-facts-img">
							<img src="images/icon-image/fact4.png" alt="" />
						</div>
						<div class="ts-facts-content">
							<h2 class="ts-facts-num"><span class="counterUp">2400</span></h2>
							<h3 class="ts-facts-title" style="font-family:Bookman Old Style;">Resumes Received</h3>
						</div>
					</div><!-- Col end -->

				</div> <!-- Facts end -->
			</div><!--/ Content row end -->
		</div><!--/ Container end -->
	</section><!-- Facts end -->
<br/>
	<section id="ts-service-area" class="ts-service-area" style="background-color:#272d33;">
		<div class="container">
			<div class="row text-center">
				<h2 class="border-title" style="color:orange;font-family:Bookman Old Style;">What We Do</h2>
				<p class="border-sub-title" style="color:white;font-family:Bookman Old Style;">
					We will offer you the jobs which is relevant to your profile.
				</p>
			</div><!--/ Title row end -->

			<div class="row">
				<div class="col-md-4">
					<div class="ts-service-box">
			        	<div class="ts-service-box-img pull-left">
			          	<img src="images/icon-image/service-icon1.png" alt="" />
			        	</div>
			        	<div class="ts-service-box-info">
			          	<h3 class="service-box-title"><a href="#" style="color:orange;font-family:Bookman Old Style;">Pre-Registration</a></h3>
			          	<p style="color:white;font-family:Bookman Old Style;">Job seeker to register first in MVG Consulting.</p>
			        </div>
			      </div><!-- Service 1 end -->

			      <div class="ts-service-box">
			        	<div class="ts-service-box-img pull-left">
			          	<img src="images/cv.png"  width="60" height="60" alt="" />
			        	</div>
			        	<div class="ts-service-box-info">
			          	<h3 class="service-box-title"><a href="#" style="color:orange;font-family:Bookman Old Style;">Resume Upload</a></h3>
			          	<p style="color:white;font-family:Bookman Old Style;">They Should uplod the resume to tackle the job.</p>
			        </div>
			      </div><!-- Service 2 end -->

			       <div class="ts-service-box">
			        	<div class="ts-service-box-img pull-left">
			          	<img src="images/icon-image/service-icon3.png" alt="" />
			        	</div>
			        	<div class="ts-service-box-info">
			          	<h3 class="service-box-title"><a href="#" style="color:orange;font-family:Bookman Old Style;">Company visits your resume</a></h3>
			          	<p style="color:white;font-family:Bookman Old Style;">If Company is hiring they visited your details.</p>
			        </div>
			      </div><!-- Service 3 end -->

				</div><!-- Col end -->

				<div class="col-md-4 text-center">
					<img class="service-center-img img-responsive" src="images/cons.png" alt=""  height="645"/>
				</div><!-- Col end -->

				<div class="col-md-4">
					<div class="ts-service-box">
			        	<div class="ts-service-box-img pull-left">
			          	<img src="images/job.png" alt="" width="60" height="60" />
			        	</div>
			        	<div class="ts-service-box-info">
			          	<h3 class="service-box-title"><a href="#" style="color:orange;">Short listed the job seeker</a></h3>
			          	<p style="color:white;font-family:Bookman Old Style;">According to cutoff they shortlisted the jobseeker.</p>
			        </div>
			      </div><!-- Service 4 end -->

			     	<div class="ts-service-box">
			        	<div class="ts-service-box-img pull-left">
			          	<img src="images/mail.png" alt="" width="60" height="60"/>
			        	</div>
			        	<div class="ts-service-box-info">
			          	<h3 class="service-box-title"><a href="#" style="color:orange;font-family:Bookman Old Style;">Get a mail or call</a></h3>
			          	<p style="color:white;font-family:Bookman Old Style;">They intimated by call or email if you are shortlisted.</p>
			        </div>
			      </div><!-- Service 5 end -->

			      <div class="ts-service-box">
			        	<div class="ts-service-box-img pull-left">
			          	<img src="images/exam.png" alt=""  width="60" height="60"/>
			        	</div>
			        	<div class="ts-service-box-info">
			          	<h3 class="service-box-title"><a href="#" style="color:orange;font-family:Bookman Old Style;">Should attend the exam.</a></h3>
			          	<p style="color:white;font-family:Bookman Old Style;">Final you should attend exam to proove your knowledge.</p>
			        </div>
			      </div><!-- Service 6 end -->
				</div><!-- Col end -->
			</div><!-- Content row end -->

		</div><!--/ Container end -->
	</section><!-- Service end -->

	

	<section class="content" >
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<h3 class="border-title border-left" style="font-family:Bookman Old Style;">How it works?</h3>

					<div class="panel-group" id="accordion">
	              	<div class="panel panel-default">
		                <div class="panel-heading">
			                <h4 class="panel-title"> 
			                	<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" style="font-family:Bookman Old Style;">Requirement Analysis</a> 
			                </h4>
		                </div>
		                <div id="collapseOne" class="panel-collapse collapse in">
		                  <div class="panel-body">
		                  	<!-- <img class="pull-left" src="images/services/service1.jpg" alt="" /> -->
		                    	<p style="font-family:Bookman Old Style;">Evaluation of the position with respect to the skills, competencies, responsibilities, key deliverables and other details is done followed by a discussion with the client on the same.</p>
		                  </div>
		                </div>
	              	</div><!--/ Panel 1 end-->

	              	<div class="panel panel-default">
		                <div class="panel-heading">
			                <h4 class="panel-title">
			                	<a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapseTwo" style="font-family:Bookman Old Style;"> Sourcing and Assessment</a>
			            	</h4>
		                </div>
		                <div id="collapseTwo" class="panel-collapse collapse">
		                  <div class="panel-body">
			                  <!-- <img class="pull-right" src="images/services/service2.jpg" alt="" /> -->
			                  <p style="font-family:Bookman Old Style;">Identification of the suitable candidates searched from various sources like the databases, advertising or networking.</p>
		                  </div>
		                </div>
	              	</div><!--/ Panel 2 end-->

	              	<div class="panel panel-default">
		                <div class="panel-heading">
			                <h4 class="panel-title">
			                	<a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapseThree" style="font-family:Bookman Old Style;"> Selection Support</a>
			            	</h4>
		                </div>
		                <div id="collapseThree" class="panel-collapse collapse">
		                  <div class="panel-body">
		                  	<!-- <img class="pull-left" src="images/services/service3.jpg" alt="" /> -->
		                    	<p style="font-family:Bookman Old Style;">Interviews with the client are scheduled after the submission of the suitable profiles and the assessment reports for the short listed candidates. </p>
		                  </div>
		                </div>
	              	</div><!--/ Panel 3 end-->

            	</div><!--/ Accordion end -->
				</div><!-- Col end -->

				<div class="col-md-6">

					<h3 class="border-title border-left" style="font-family:Bookman Old Style;">Happy Clients</h3>

					<div class="row all-clients">
						<div class="col-sm-4">
							<figure class="clients-logo">
								<a href="#"><img class="img-responsive" src="images/c1.png" alt="" /></a>
							</figure>
						</div><!-- Client 1 end -->

						<div class="col-sm-4">
							<figure class="clients-logo">
								<a href="#"><img class="img-responsive" src="images/c2.png" alt="" /></a>
							</figure>
						</div><!-- Client 2 end -->

						<div class="col-sm-4">
							<figure class="clients-logo">
								<a href="#"><img class="img-responsive" src="images/c3.png" alt="" /></a>
							</figure>
						</div><!-- Client 3 end -->

						<div class="col-sm-4">
							<figure class="clients-logo">
								<a href="#"><img class="img-responsive" src="images/c4.png" alt="" /></a>
							</figure>
						</div><!-- Client 4 end -->

						<div class="col-sm-4">
							<figure class="clients-logo">
								<a href="#"><img class="img-responsive" src="images/c5.png" alt="" /></a>
							</figure>
						</div><!-- Client 5 end -->

						<div class="col-sm-4">
							<figure class="clients-logo">
								<a href="#"><img class="img-responsive" src="images/c6.png" alt="" /></a>
							</figure>
						</div><!-- Client 6 end -->

					</div><!-- Clients row end -->

				</div><!-- Col end -->

			</div><!--/ Content row end -->
		</div><!--/ Container end -->
	</section><!-- Content end -->


	

	<?php include "footer.php"?>