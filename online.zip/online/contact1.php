<?php include "header.php" ?>
	
	<div id="banner-area" class="banner-area" style="background-image:url(images/cont.jpg)">
		<div class="banner-text">
     		<div class="container">
	        	<div class="row">
	        		<div class="col-xs-12">
	        			<div class="banner-heading">
	        				<h1 class="border-title border-left">Contact Us</h1>
	        				<ol class="breadcrumb">
	        					<li>Home</li>
	        					<!-- <li>Contact</li> -->
	        					<li><a href="#">Contact Us</a></li>
	        				</ol>
	        			</div>
	        		</div><!-- Col end -->
	        	</div><!-- Row end -->
       	</div><!-- Container end -->
    	</div><!-- Banner text end -->
	</div><!-- Banner area end --> 

	<section id="main-container" class="main-container">
		<div class="container">

			<div class="row">

				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
					<div class="sidebar sidebar-left">
						<div class="widget contact-info">
							<h3 class="widget-title" style="font-family:Bookman Old Style;">Contact Us</h3>

							<div class="contact-info-box">
								<i class="fa fa-map">&nbsp;</i>
								<div class="contact-info-box-content">
									<h4 style="font-family:Bookman Old Style;">Visit Us</h4>
									<p style="font-family:Bookman Old Style;">Plot No 10-5-438/e Sri Rama Bhavanamu 3rd Floor, Road No 4, West Marredpally, Hyderabad - 500026, Above Heritage Super Market.</p>
								</div>
							</div>

							<div class="contact-info-box">
								<i class="fa fa-envelope">&nbsp;</i>
								<div class="contact-info-box-content">
									<h4>Mail Us</h4>
									<p style="font-family:Bookman Old Style;">contact@mvg.com</p>
								</div>
							</div>

							<div class="contact-info-box">
								<i class="fa fa-phone-square">&nbsp;</i>
								<div class="contact-info-box-content">
									<h4 style="font-family:Bookman Old Style;">Call Us</h4>
									<p> +(91)-40-64644501</p>
								</div>
							</div>

						</div><!-- Widget end -->
					</div><!-- Sidebar left end -->
				</div><!-- Sidebar col end -->

				<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
	    			<h3 class="border-title border-left">Contact Form</h3>
	    			<form id="contact-form" action="contact-form.php" method="post" role="form">
	    				<div class="error-container"></div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label>Name</label>
								<input class="form-control form-control-name" name="name" id="name" placeholder="" type="text" required>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Email</label>
									<input class="form-control form-control-email" name="email" id="email" 
									placeholder="" type="email" required>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Subject</label>
									<input class="form-control form-control-subject" name="subject" id="subject" 
									placeholder="" required>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label>Message</label>
							<textarea class="form-control form-control-message" name="message" id="message" placeholder="" rows="10" required></textarea>
						</div>
						<div class="text-right"><br>
							<button class="btn btn-primary solid blank" type="submit">Send Message</button> 
						</div>
					</form>
	    		</div>
			
			</div><!-- Content row -->
		</div><!-- Conatiner end -->
	</section><!-- Main container end -->

	<section id="map-wrapper" class="no-padding">
		<iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3806.2482365943392!2d78.50083386397901!3d17.447828905653616!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sWest+Marredpally%2C+Hyderabad+-+500026%2C+Above+Heritage+Super+Market!5e0!3m2!1sen!2sin!4v1479190675859" width="1400" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
	</section><!-- Map end -->

	
	<?php include "footer.php" ?>