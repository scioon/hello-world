<?php
session_start();
echo 'welcome ' .$_SESSION['username'];
echo '<br><a href="companylogin.php?action=logout">Logout</a>';
?>