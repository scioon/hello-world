<?php include 'header.php';?>

		
		<!-- Page title -->
			<section class="page-title-wrap">
				<div class="page-title-img service-pagetitle-bg">
					<div class="container">
						<div class="row">
							<div class="cp-page-title-wrap">
								<div class="header-color-back">
									<div class="header-main-content">
										<h1><span>Our Services</span></h1>
										<p>We are Mahesh Wooden Furniture. </p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Page title -->
		
		<!-- Main Content -->
			<section id="our-services">
				<div class="container">
					<div class="row service-row">
						<div class="col-sm-8">
							<div class="service-header">
								<h2>our services</h2>
								
								<div class="custom-border">
									<div class="custom-border-1"></div>
								</div>
								
								<p>
									Welcome to Mahesh Wooden Furniture, amazing interior design template. It’s time to stand out from the crowd and offer your clients
									unique and amazing experience. Mahesh Wooden Furniture comes in two versions: clean corporate site and modern, unique layout which
									you are seeing right now. unique layout which you are seeing right now. Choose the one you like more, you won't be disaponted,.
								</p>
							</div>
							
							<div class="service-detail">
								<!-- Choose Us Post One -->	
								<div class="choose-comments">
									<div class="choose-comment-detail">
										<div class="choose-image wow fadeInDown">
											<span><i class="fa fa-check"></i></span>
										</div>
										<div class="choose-comment">
											<h5 class="wow fadeInRight">Interior & Exterior Planning</h5>
											<p class="wow fadeInRight">This is Mahesh Wooden Furniture, clean, professional and modern interior agency company website template. Make outstanding website with this beautiful template.</p>
										</div>
									</div>
								</div>
								<!--/ End Choose Us Post One -->

								<!-- Choose Us Post Two -->	
								<div class="choose-comments">
									<div class="choose-comment-detail">
										<div class="choose-image wow fadeInDown">
											<span><i class="fa fa-check"></i></span>
										</div>
										<div class="choose-comment">
											<h5 class="wow fadeInRight">Visualization</h5>
											<p class="wow fadeInRight">Mahesh Wooden Furniture is not bloated with unnecessary content, but offers only the best and most useful elements that will make your site differ, but also fast and smooth.</p>
										</div>
									</div>
								</div>
								<!--/ End Choose Us Post Two -->

								<!-- Choose Us Post Three -->	
								<div class="choose-comments">
									<div class="choose-comment-detail">
										<div class="choose-image wow fadeInDown">
											<span><i class="fa fa-check"></i></span>
										</div>
										<div class="choose-comment">
											<h5 class="wow fadeInRight">Interior & Exterior Design</h5>
											<p class="wow fadeInRight">Great attention to details is extremelly important, so we made Mahesh Wooden Furniture to be pixel perfect with small unique touches, to draw users attention.</p>
										</div>
									</div>
								</div>
								<!--/ End Choose Us Post Three -->
							</div>
							
							<div class="service-detail-button">
								<a href="corporate-portfolio.php">VIEW PORTFOLIO</a> 
							</div>  
							
						</div>
						
						<div class="col-sm-4">
							<div class="service-right-image">
								<img src="assets/images/cp-about-1.jpg" alt="">
								
								<img src="assets/images/cp-about-2.jpg" alt="">
							</div>
						</div>
						
					</div>
				</div>
			</section>
		<!--/ End Main Content -->
		
<?php include 'footer.php';?>
		
		
    	<!-- Theme Panel Switcher End -->	
		

		<!-- ============ Js Files ============ -->

	    <!-- Placed at the end of the document so the pages load faster -->
		
		<!-- main js -->
			<script src="assets/js/jquery-1.11.2.min.js"></script>
				
			<script src="assets/js/bootstrap.min.js"></script>	
			<script src="assets/js/jquery.sticky.js"></script>	
			
			<script src="assets/js/slider/jquery.themepunch.tools.min.js"></script>	
			<script src="assets/js/slider/jquery.themepunch.revolution.min.js"></script>	
			<script src="assets/js/slider/portfolio-single-custom.js"></script>	
			
			<script src="assets/js/jquery.cubeportfolio.min.js"></script>	
			<script src="assets/js/portfolio-custom.js"></script>	
			<script src="assets/js/slick.min.js"></script>
			<script src="assets/js/modernizr.custom.js"></script>
			<script src="assets/js/jquery.magnific-popup.min.js"></script>
			<script src="assets/js/jquery.touchSwipe.min.js"></script>
			<script src="assets/js/jquery.liquid-slider.js"></script>
			<script src="assets/js/jquery.backstretch.min.js"></script>
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script> 
			<script src="assets/js/gmap3.min.js"></script>
			<script src="assets/js/ionrangeslider.js"></script>
			<script src="assets/js/classie.js"></script>
			<script src="assets/js/wow.min.js"></script>
			
		       
		<!-- Custom Script -->		
			<script src="assets/js/main.js"></script>
		<!-- Theme Panel Style Switcher -->
			<script src="assets/js/theme_panel.js"></script>		
		
	</body>

<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-services.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:45:40 GMT -->
</html>
