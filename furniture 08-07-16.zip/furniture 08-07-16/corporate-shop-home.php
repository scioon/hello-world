<!DOCTYPE html>
<html lang="en">
	
	
<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-shop-home.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:46:27 GMT -->
<head>
		<title>Ricochet Multi-Purpose HTML Template By Mkscoder</title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="assets/images/service-logo.png">

		
		<!-- Web fonts -->
			<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,800,300,600,700' rel='stylesheet' type='text/css'>
			<link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
			<link href='http://fonts.googleapis.com/css?family=Raleway:500,600,700,300' rel='stylesheet' type='text/css'>
		<!-- Main css -->
			<link href="assets/css/font-awesome.min.css" rel="stylesheet" >
			<link href="assets/css/bootstrap.min.css" rel="stylesheet">
			<link href="assets/css/style.css" rel="stylesheet">
			<link href="assets/css/slick.css" rel="stylesheet">
			<link href="assets/css/media.css" rel="stylesheet">
			<link href="assets/css/animate.min.css" rel="stylesheet" >
			<link href="assets/css/liquid-slider.css" rel="stylesheet" >
			<link href="assets/css/component.css" rel="stylesheet">
		<!-- Skin Color -->
			<link href="assets/css/color/beige.css" rel="stylesheet" id="color-skins" >
		
		<!-- Style Switcher --> 
        	<link href="assets/css/theme_panel.css" rel="stylesheet" />		
			
	</head>
  

	<body class="parallax">
		
		<!-- PRELOADER START -->
			<div id="preloader">
				<div class="preloader-container">
					<h4 class="preload-logo triggerAnimation animated" data-animate="bounceIn">Ricochet</h4>
					<img src="assets/images/preloader.gif" class="preload-gif" alt="Ricochet">
				</div>
			</div>
		<!-- PRELOADER END -->
	
		<!-- Corporate Nav Top -->
			<section id="nav-top-corporate" class="hidden-xs">
				<div class="container">
					<div class="row">
						<div class="col-sm-6">
							<div class="Corporate-top-left">
								<p><span>+41 (0) 57 7876 3452</span> info@ricochet.com</p>
							</div>
						</div>
						<div class="col-sm-6 corporate-cart">
							<div class="corporate-top-cart">
								<div class="corporate-nav-cart">
									<ul>
										<li><a href="#">LOGIN<span>/</span></a></li>
										<li><a href="#">CART<span>$0</span></a></li>
										<li><img src="assets/images/cart-count-icon-white.png" alt=""></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Corporate Nav Top -->

		<!-- Navigation Section -->
			<section id="navigation" class="shadow">
			
				<div class=" container inner navigation">
					
					<!-- Logo Img -->
					
					<div class="logo">
						<a class="scroll" href="corporate-home.php"><img src="assets/images/logo.png" alt="Logo"/></a>
						<p class="hidden-xs"><em>Where Art Meets Interior</em></p>
					</div>
					
					
					
					<!-- Nav Menu -->
					<div class="nav-menu">
						
						<ul class="nav main-nav right-30">
						
							<li class="dropdown-toggle nav-toggle">
								<a class="scroll" href="#">Home</a>
								<ul class="dropdown-menu">
									<li><a href="corporate-home.php">Home 1</a></li>
									<li><a href="corporate-home-2.php">Home 2</a></li>
								</ul>
							</li>
							
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="#">About</a>

								<ul class="dropdown-menu">

									<li><a href="corporate-about-us.php">About us</a></li>
									<li><a href="corporate-services.php">our services</a></li>

								</ul>

							</li>
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="#">portfolio</a>

								<ul class="dropdown-menu">

									<li><a href="corporate-portfolio.php">portfolio</a></li>
									<li><a href="corporate-portfolio-two.php">portfolio 2</a></li>
									<li><a href="corporate-portfolio-single.php">portfolio single</a></li>

								</ul>

							</li>
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="#">news</a>

								<ul class="dropdown-menu">

									<li><a href="corporate-blog.php">Blog</a></li>
									<li><a href="corporate-blog-single.php">Blog single</a></li>

								</ul>

							</li>
							<li class="dropdown-toggle nav-toggle active"><a class="scroll" href="#">Shop</a>

								<ul class="dropdown-menu">

									<li class="active"><a href="corporate-shop-home.php">Shop home</a></li>
									<li><a href="corporate-shop-list.php">shop list</a></li>
									<li><a href="corporate-shop-detail.php">Shop detail</a></li>

								</ul>

							</li>
							
							<li><a class="scroll" href="corporate-contact.php">contact</a></li>
						
						</ul>
						
						<div class="top-search">
							<div id="morphsearch" class="morphsearch">
								<form class="morphsearch-form">
									<input class="morphsearch-input" type="search" placeholder="Search"/>
									<i class="fa fa-search morph-icon"></i>
									<button class="morphsearch-submit" type="submit">aaaaaa</button>
								</form>
								<!-- /morphsearch-content -->
								<span class="morphsearch-close"></span>
							</div>
							
						</div>					
					</div>			
					
					<!-- Dropdown Menu For Mobile Devices-->
					
						<div class="dropdown mobile-drop">
						  	<a data-toggle="dropdown" class="mobile-menu" href="#"><i class="fa fa-bars"></i></a>
						  
							<ul class="nav dropdown-menu extra fullwidth" role="menu" >
								<li class="dropdown-toggle mobile-toggle"><a class="scroll">Home</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-home.php">Home 1</a></li>
										<li><a href="corporate-home-2.php">Home 2</a></li>

									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="scroll">about</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-about-us.php">About us</a></li>
										<li><a href="corporate-services.php">our services</a></li>

									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="scroll">portfolio</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-portfolio.php">portfolio</a></li>
										<li><a href="corporate-portfolio-two.php">portfolio 2</a></li>
										<li><a href="corporate-portfolio-single.php">portfolio single</a></li>

									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="scroll">news</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-blog.php">Blog</a></li>
										<li><a href="corporate-blog-single.php">Blog single</a></li>


									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle active"><a class="scroll">Shop</a>

									<ul class="dropdown-menu dr-mobile">

										<li class="active"><a href="corporate-shop-home.php">Shop home</a></li>
										<li><a href="corporate-shop-list.php">shop list</a></li>
										<li><a href="corporate-shop-detail.php">Shop detail</a></li>

									</ul>

								</li>
								
								<li><a class="scroll" href="corporate-contact.php">contact</a></li>
							</ul>
												  
						</div>
						
						
						
					
				
					<div class="clear"></div>
					
				</div>
					
			
			</section>
		<!-- End Navigation Section -->
		
		<!-- Slider Content -->
			<section id="corporate-shop-home">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<div class="cp-home-slider-content-1">
								<div class="row">
									<div class="col-sm-5">
										<div class="shop-home-left">
											<a class="wow fadeInDown" data-wow-delay=".0s" href="#">GO TO SHOP</a>
											<h2 class="wow fadeInDown" data-wow-delay=".1s">SOFA <br>COLLECTION</h2>
											<h4 class="wow fadeInDown" data-wow-delay=".2s"><span>20% OFF</span></h4>
											<p class="wow fadeInDown" data-wow-delay=".3s">
												Modern Sofa with fine fabric cover. <br>Color 
												combinations and <br>material variations available.
											</p>
										</div>
									</div>
									
									<div class="pull-right col-sm-5">
										<div class="shop-home-right">
											<p class="wow fadeInDown" data-wow-delay=".0s"><span>$419</span></p>
											<div class="home-item wow fadeInDown" data-wow-delay=".1s">
												<img src="assets/images/shop/home-sofa-1.jpg" alt="">
												<img src="assets/images/shop/home-sofa-2.jpg" alt="">
											</div>
											<div class="home-item wow fadeInDown" data-wow-delay=".2s">
												<img src="assets/images/shop/home-sofa-3.jpg" alt="">
												<img src="assets/images/shop/home-sofa-4.jpg" alt="">
											</div>
											
											<div class="shop-home-link wow fadeInDown" data-wow-delay=".3s">
												<a href="corporate-shop-detail.php">View Detailes</a>
												<a href="#">Add to cart</a>
											</div>
										</div>
									</div>
								</div>
								
							</div>
							
						</div>
					</div>
				</div>
			</section>
		<!--/ End Slider Content -->
		
		<!-- Corporate Home Services -->
		<section id="cp-services">
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						<div class="cp-shop-header">
							<h2><span>SHOP CATEGORIES</span></h2>
						</div>
					</div>
				</div>
				<div class="row cp-service-row">
					<div class="shop-service">
						<div>
							<div class="cp-services-main">
								<img class="img-responsive" src="assets/images/service-1.jpg" alt="">
								
								<div class="service-img-bottom">
									<div class="service-number">
										<p>01</p>
									</div>
									<div class="number-head">
										<h3><a href="#">LIVING ROOM</a></h3>
										<p>Sofa, Couch, Lamp, Decore and more</p>
									</div>
								</div>
								
							</div>
						</div>
						
						<div>
							<div class="cp-services-main">
								<img class="img-responsive" src="assets/images/service-2.jpg" alt="">
								
								<div class="service-img-bottom">
									<div class="service-number">
										<p>02</p>
									</div>
									<div class="number-head">
										<h3><a href="#">KITCHEN</a></h3>
										<p>All your kitchen needs</p>
									</div>
								</div>
								
							</div>
						</div>
						
						<div>
							<div class="cp-services-main">
								<img class="img-responsive" src="assets/images/service-3.jpg" alt="">
								
								<div class="service-img-bottom">
									<div class="service-number">
										<p>03</p>
									</div>
									<div class="number-head">
										<h3><a href="#">bedroom</a></h3>
										<p>Modern and Retro Bedrooms</p>
									</div>
								</div>
								
							</div>
						</div>
						
						<div>
							<div class="cp-services-main">
								<img class="img-responsive" src="assets/images/service-1.jpg" alt="">
								
								<div class="service-img-bottom">
									<div class="service-number">
										<p>01</p>
									</div>
									<div class="number-head">
										<h3><a href="#">LIVING ROOM</a></h3>
										<p>Sofa, Couch, Lamp, Decore and more</p>
									</div>
								</div>
								
							</div>
						</div>
						
						<div>
							<div class="cp-services-main">
								<img class="img-responsive" src="assets/images/service-2.jpg" alt="">
								
								<div class="service-img-bottom">
									<div class="service-number">
										<p>02</p>
									</div>
									<div class="number-head">
										<h3><a href="#">KITCHEN</a></h3>
										<p>All your kitchen needs</p>
									</div>
								</div>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Corporate Home Services -->
		
	
		<!-- Section Start -->
		<section id="feature" class="cp-shop-feature">
			<div class="container">
				<div class="row">
					<div class="col-sm-6 feature-left-content">
						<div class="shop-item-details">
							<div class="page-header-1">
								<h1>FEATURED PRODUCT - MODERN SOFA</h1>
								
								<div class="custom-border">
									<div class="custom-border-1"></div>
								</div>
							</div>
							
							<div class="detail-content">
								<div class="rating">
									<ul>
										<li class="rating-price wow fadeInRight"><del>$487</del> <span>$250</span></li>
										<li class="wow fadeInRight"><a><img src="assets/images/shop/star.png" alt=""><span>1 rating</span></a></li>
									</ul>
								</div>
								<div class="item-description">
									<ul>
										<li class="wow fadeInRight" data-wow-delay=".1s">
											<i class="fa fa-circle-thin"></i>
											<span>Material:</span>
											Soft Fabric 20%, Leather 80%
										</li>
										<li class="wow fadeInRight" data-wow-delay=".2s">
											<i class="fa fa-circle-thin"></i>
											<span>Style:</span>
											Modern
										</li>
										<li class="wow fadeInRight" data-wow-delay=".3s">
											<i class="fa fa-circle-thin"></i>
											<span>Brand:</span>
											XXL Sofas
										</li>
										<li class="wow fadeInRight" data-wow-delay=".4s">
											<i class="fa fa-circle-thin"></i>
											<span>Dimensions:</span>
											185cm x 90cm x 70cm
										</li>
									</ul>
								</div>
								
								<p class="bot wow fadeInRight" data-wow-delay=".4s">
									Duis eget leo venenatis, accumsan erat nec, tempor odio. Nulla facilisi. Curabitur eu accumsan turpis. Ut sollicitudin adipiscing
									enim, sed gravida elit imperdiet nec. Praesent sed suscipit tortor, sit amet sagittis eros. Cum sociis natoque penatibus et
									magnis dis parturient montes, nascetur ridiculus mus. Fusce
								</p>
							
								
								<div class="shop-home-link">
									<a href="#">Add to cart</a>
								</div>
								
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="">
							<img src="assets/images/feature-right.jpg" alt="">
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Testimonial Section -->

		<!-- CP Subscribe Section -->
			<section id="from-shop">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<div class="cp-shop-header">
								<h2><span>FROM THE SHOP</span></h2>
							</div>
						</div>
					</div>
					<!-- Shop Item First Row -->	
					<div class="row custom-15">
					<!-- Shop Item One -->
						<div class="col-sm-3">
							<div class="thumbnail light-grey">
								<div class="shop-item-figure">
									<img src="assets/images/shop/shop-item-1.jpg" alt="">
									<div class="shop-item-figcaption">
										<div class="star-image">
											<ul>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
											</ul>
										</div>
										<div class="shop-item-link">
											<ul>
												<li><a class="link-one" href="#">Add to wishlist</a></li>
												<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
											</ul>
										</div>
									</div>
									
									<div class="item-sale">
										<P>Sale!</P>
									</div>
								</div>
								<div class="caption">
									<h4>LIVING ROOM</h4>
									<h2>Modern Sofa</h2>
									<p><span><del>$487</del></span> $250</p>
									<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
								</div>
							</div>
						</div>
					<!--/ End Shop Item One -->
					
					<!-- Shop Item Two -->
						<div class="col-sm-3">
							<div class="thumbnail light-grey">
								<div class="shop-item-figure">
									<img src="assets/images/shop/shop-item-2.jpg" alt="">
									<div class="shop-item-figcaption">
										<div class="star-image">
											<ul>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
											</ul>
										</div>
										<div class="shop-item-link">
											<ul>
												<li><a class="link-one" href="#">Add to wishlist</a></li>
												<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
											</ul>
										</div>
									</div>
									
								</div>
								<div class="caption">
									<h4>BEDROOM</h4>
									<h2>NIGHT LAMP</h2>
									<h5>$89</h5>
									<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
								</div>
							</div>
						</div>
					<!--/ End Shop Item Two -->
					
					<!-- Shop Item Three -->
						<div class="col-sm-3">
							<div class="thumbnail light-grey">
								<div class="shop-item-figure">
									<img src="assets/images/shop/shop-item-3.jpg" alt="">
									<div class="shop-item-figcaption">
										<div class="star-image">
											<ul>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
											</ul>
										</div>
										<div class="shop-item-link">
											<ul>
												<li><a class="link-one" href="#">Add to wishlist</a></li>
												<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
											</ul>
										</div>
									</div>
									
								</div>
								<div class="caption">
									<h4>LIVING ROOM</h4>
									<h2>RED COUCH</h2>
									<h5>$853</h5>
									<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
								</div>
							</div>
						</div>
					<!--/ End Shop Item Three -->
					
					<!-- Shop Item Four -->
						<div class="col-sm-3">
							<div class="thumbnail light-grey">
								<div class="shop-item-figure">
									<img src="assets/images/shop/shop-item-4.jpg" alt="">
									<div class="shop-item-figcaption">
										<div class="star-image">
											<ul>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
											</ul>
										</div>
										<div class="shop-item-link">
											<ul>
												<li><a class="link-one" href="#">Add to wishlist</a></li>
												<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
											</ul>
										</div>
									</div>
									
								</div>
								<div class="caption">
									<h4>LIVING ROOM</h4>
									<h2>BLACK LATHER COUCH</h2>
									<h5>$1479</h5>
									<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
								</div>
							</div>
						</div>
					<!--/ End Shop Item Four -->
					</div>
				<!--/ End Shop Item First Row -->	
				
				
				<!-- Shop Item Second Row -->	
					<div class="row custom-15">
					<!-- Shop Item One -->
						<div class="col-sm-3">
							<div class="thumbnail light-grey">
								<div class="shop-item-figure">
									<img src="assets/images/shop/shop-item-5.jpg" alt="">
									<div class="shop-item-figcaption">
										<div class="star-image">
											<ul>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
											</ul>
										</div>
										<div class="shop-item-link">
											<ul>
												<li><a class="link-one" href="#">Add to wishlist</a></li>
												<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
											</ul>
										</div>
									</div>
									
									<div class="item-sale">
										<P>Sale!</P>
									</div>
								</div>
								<div class="caption">
									<h4>BEDROOM</h4>
									<h2>COUCH - BED</h2>
									<p><span><del>$487</del></span> $250</p>
									<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
								</div>
							</div>
						</div>
					<!--/ End Shop Item One -->
					
					<!-- Shop Item Two -->
						<div class="col-sm-3">
							<div class="thumbnail light-grey">
								<div class="shop-item-figure">
									<img src="assets/images/shop/shop-item-6.jpg" alt="">
									<div class="shop-item-figcaption">
										<div class="star-image">
											<ul>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
											</ul>
										</div>
										<div class="shop-item-link">
											<ul>
												<li><a class="link-one" href="#">Add to wishlist</a></li>
												<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
											</ul>
										</div>
									</div>
									
									<div class="item-sale">
										<P>Sale!</P>
									</div>
								</div>
								<div class="caption">
									<h4>BEDROOM</h4>
									<h2>STANDING LAMP</h2>
									<p><span><del>$487</del></span> $129</p>
									<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
								</div>
							</div>
						</div>
					<!--/ End Shop Item Two -->
					
					<!-- Shop Item Three -->
						<div class="col-sm-3">
							<div class="thumbnail light-grey">
								<div class="shop-item-figure">
									<img src="assets/images/shop/shop-item-7.jpg" alt="">
									<div class="shop-item-figcaption">
										<div class="star-image">
											<ul>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
											</ul>
										</div>
										<div class="shop-item-link">
											<ul>
												<li><a class="link-one" href="#">Add to wishlist</a></li>
												<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
											</ul>
										</div>
									</div>
									
								</div>
								<div class="caption">
									<h4>LIVING ROOM</h4>
									<h2>Modern Sofa</h2>
									<h5>$853</h5>
									<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
								</div>
							</div>
						</div>
					<!--/ End Shop Item Three -->
					
					<!-- Shop Item Four -->
						<div class="col-sm-3">
							<div class="thumbnail light-grey">
								<div class="shop-item-figure">
									<img src="assets/images/shop/shop-item-8.jpg" alt="">
									<div class="shop-item-figcaption">
										<div class="star-image">
											<ul>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
												<li><i class="fa fa-star-half-empty"></i></li>
											</ul>
										</div>
										<div class="shop-item-link">
											<ul>
												<li><a class="link-one" href="#">Add to wishlist</a></li>
												<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
											</ul>
										</div>
									</div>
									
								</div>
								<div class="caption">
									<h4>KITCHEN</h4>
									<h2>SMALL KITCHEN TABLE</h2>
									<h5>$1479</h5>
									<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
								</div>
							</div>
						</div>
					<!--/ End Shop Item Four -->
					</div>
				<!--/ End Shop Item Second Row -->
				</div>
			</section>
		<!--/ End CP Subscribe Section -->
		
		<!-- Shop Subscription Section -->
			<section id="shop-subscription">
				<div class="container">
					<div class="row shop-subscription-row">
					<!-- First Column -->
						<div class="col-sm-3">
							<div class="onsale-left">
								<div class="sidebar-box">
									<h3>newslettter subscribe</h3>
									
									<div class="shop-newsletter h-35 wow fadeInDown">
										<p>
											Subscribe to our newsletter feed to get
											notified about latest sale offers and new 
										</p>
										<div class="input-group">
											<input type="email" class="form-control" placeholder="Enter Your Email..." aria-describedby="basic-addon2">
											<span class="input-group-addon" id="basic-addon2"><i class="fa fa-envelope-o"></i></span>
										</div>
									</div>
								</div>
							</div>
						</div>
					
					<!-- Second Column -->	
						<div class="col-sm-3 shop-home-1">
							<div class="onsale-left">
								<div class="sidebar-box">
									<h3>MOST POPULAR</h3>
									
									<div class="onsale-cart-image wow fadeInDown" data-wow-delay=".0s">
										<img src="assets/images/shop/left-cart-1.jpg" alt="">
										<div class="onsale-cart-content">
											<h6><a href="#">Retro Sofa</a></h6>
											<p><span>$99</span></p>
										</div>
									</div>
									
									<div class="onsale-cart-image wow fadeInDown" data-wow-delay=".1s">
										<img src="assets/images/shop/left-cart-3.jpg" alt="">
										<div class="onsale-cart-content">
											<h6><a href="#">Leather Couch</a></h6>
											<p><span>$99</span></p>
										</div>
									</div>
									
									<div class="onsale-cart-image wow fadeInDown" data-wow-delay=".2s">
										<img src="assets/images/shop/left-cart-3.jpg" alt="">
										<div class="onsale-cart-content">
											<h6><a href="#">Relaxing Sofa</a></h6>
											<p><span>$75</span></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					
					<!-- Third Column -->	
						<div class="col-sm-3">
							<div class="onsale-left">
								<div class="sidebar-box">
									<h3>On sale</h3>
									
									<div class="onsale-cart-image wow fadeInDown" data-wow-delay=".0s">
										<img src="assets/images/shop/left-cart-1.jpg" alt="">
										<div class="onsale-cart-content">
											<h6><a href="#">Retro Sofa</a></h6>
											<p> <del> $125 </del> <span>$99</span></p>
										</div>
									</div>
									
									<div class="onsale-cart-image wow fadeInDown" data-wow-delay=".1s">
										<img src="assets/images/shop/left-cart-2.jpg" alt="">
										<div class="onsale-cart-content">
											<h6><a href="#">Leather Couch</a></h6>
											<p> <del> $125 </del> <span>$99</span></p>
										</div>
									</div>
									
									<div class="onsale-cart-image wow fadeInDown" data-wow-delay=".2s">
										<img src="assets/images/shop/left-cart-3.jpg" alt="">
										<div class="onsale-cart-content">
											<h6><a href="#">Modern Red Sofa</a></h6>
											<p> <del> $99 </del> <span>$75</span></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					
					<!-- Fourth Column -->	
						<div class="col-sm-3">
							<div class="onsale-left">
								<div class="sidebar-box">
									<h3>BEST RATED</h3>
									
									<div class="onsale-cart-image wow fadeInDown" data-wow-delay=".0s">
										<img src="assets/images/shop/left-cart-1.jpg" alt="">
										<div class="onsale-cart-content">
											<h6><a href="#">Blue Retro Sofa</a></h6>
											<p><img src="assets/images/shop/star.png" alt=""></p>
										</div>
									</div>
									
									<div class="onsale-cart-image wow fadeInDown" data-wow-delay=".1s">
										<img src="assets/images/shop/left-cart-2.jpg" alt="">
										<div class="onsale-cart-content">
											<h6><a href="#">Red Couch</a></h6>
											<p><img src="assets/images/shop/star.png" alt=""></p>
										</div>
									</div>
									
									<div class="onsale-cart-image wow fadeInDown" data-wow-delay=".2s">
										<img src="assets/images/shop/left-cart-3.jpg" alt="">
										<div class="onsale-cart-content">
											<h6><a href="#">Living Room Set</a></h6>
											<p><img src="assets/images/shop/star.png" alt=""></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Shop Subscription Section -->

		<!-- Partners Section -->
			<section id="partner-slide">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<div class="cp-page-header">
								<h2>Brands</h2>
								<p>Materials & Furniture Supplier Partners</p>
								<img src="assets/images/header-bottom.png" alt="">
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-sm-12">
							<div class="partner-logo">
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-1.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-2.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-3.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-4.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-1.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-2.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-3.png" alt=""></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Partners Section -->
		
		
		<!-- Footer Top Start -->
			<section id="corporate-footer-top">
				<div class="container">
					<div class="row">
						<div class="col-sm-4">
						<div class="footer-top-back">
							<div class="cp-footer-top-left">
								<a class="wow fadeInDown" data-wow-delay=".0s" href="corporate-home.php"><img src="assets/images/logo-white.png" alt=""></a>
								
								
								<p class="wow fadeInDown" data-wow-delay=".1s"><strong><a href="tel:+4105778763452">+41 (0) 57 7876 3452</a></strong></p>
								<p class="wow fadeInDown" data-wow-delay=".2s"><a href="mailto:info@ricochet.com">info@ricochet.com</a></p>
								<p class="wow fadeInDown" data-wow-delay=".3s">1st Kengiston Street, LA, USA</p>
							</div>
						</div>	
						</div>
						<div class="col-sm-4">
							<div class="cp-footer-top-middle">
								<div class="cp-footer-head">
									<h3>Quick Links</h3>
								</div>
								
								<div class="middle-left-cp">
									<ul>
										<li class="wow fadeInRight" data-wow-delay=".0s"><a href="#"><i class="fa fa-angle-right"></i>About Us</a></li>
										<li class="wow fadeInRight" data-wow-delay=".1s"><a href="#"><i class="fa fa-angle-right"></i>Our Services</a></li>
										<li class="wow fadeInRight" data-wow-delay=".2s"><a href="#"><i class="fa fa-angle-right"></i>Company news</a></li>
										<li class="wow fadeInRight" data-wow-delay=".3s"><a href="#"><i class="fa fa-angle-right"></i>Portfolio</a></li>
										<li class="wow fadeInRight" data-wow-delay=".4s"><a href="#"><i class="fa fa-angle-right"></i>Shop</a></li>
									</ul>
								</div>
								<div class="middle-right-cp">
									<ul>
										<li class="wow fadeInRight" data-wow-delay=".0s"><a href="#"><i class="fa fa-angle-right"></i>Buyer Support</a></li>
										<li class="wow fadeInRight" data-wow-delay=".1s"><a href="#"><i class="fa fa-angle-right"></i>Legal Information</a></li>
										<li class="wow fadeInRight" data-wow-delay=".2s"><a href="#"><i class="fa fa-angle-right"></i>Privacy Policy</a></li>
										<li class="wow fadeInRight" data-wow-delay=".3s"><a href="#"><i class="fa fa-angle-right"></i>Payment Options</a></li>
										<li class="wow fadeInRight" data-wow-delay=".4s"><a href="#"><i class="fa fa-angle-right"></i>Partners & Suppliers</a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="cp-footer-top-right">
								<div class="cp-footer-head">
									<h3>SOCIAL</h3>
								</div>
								<div class="cp-footer-social">
									<ul>
										<li class="wow fadeInDown" data-wow-delay=".0s"><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".1s"><a href="#"><i class="fa fa-dribbble"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".2s"><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".3s"><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".4s"><a href="#"><i class="fa fa-skype"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Footer Top -->

		
		<!-- Footer Start -->
			<section id="corporate-footer">
				<div class="container">
					<div class="row">
						<div class="col-sm-6 corporate-footer-left">
							<p>RICOCHET 2015. Design by Pixel Industry d.o.o.</p>
						</div>
						
						<div class="col-sm-6 corporate-footer-right">
							<p>Pixel Industry d.o.o. All Rights Reserved</p>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Footer -->
		
		<!-- Theme Panel Switcher Start -->
	        <section id="theme-panel" class="panel-close">
	            <a class="panel-btn"><i class="fa fa-spinner icon-spin"></i></a>
	            <div class="theme-panel-title">
	                <h4>Style Switcher</h4>
	            </div>
	            <div class="colors-container">
	                <p class="amount-1" style="line-height:0;">10 Color Skins</p>
					<a title="beige" class="color-switch beige"></a>
	                <a title="red" class="color-switch red"></a>
					<a title="blue-2" class="color-switch blue-2"></a>
	                <a title="pink" class="color-switch pink"></a>
	                <a title="blue" class="color-switch blue"></a>
	                <a title="purple" class="color-switch purple"></a>
	                <a title="green" class="color-switch green"></a>
	                <a title="yellow" class="color-switch yellow"></a>
	                <a title="orange" class="color-switch orange"></a>
					<a title="midnight" class="color-switch midnight"></a>
	            </div>
	            <div class="colors-container">
	            	<p class="about-colors">
					There are unlimited posibilities to make your own color style. We have included 10 color css in this template. Thanks for using our themplate.
					</p>
				</div>
	        </section>
    	<!-- Theme Panel Switcher End -->	
		

		<!-- ============ Js Files ============ -->

	    <!-- Placed at the end of the document so the pages load faster -->
		
		<!-- main js -->
			<script src="assets/js/jquery-1.11.2.min.js"></script>
				
			<script src="assets/js/bootstrap.min.js"></script>	
			<script src="assets/js/jquery.sticky.js"></script>	
			
			<script src="assets/js/jquery.cubeportfolio.min.js"></script>	
			<script src="assets/js/portfolio-custom.js"></script>	
			<script src="assets/js/slick.min.js"></script>
			<script src="assets/js/modernizr.custom.js"></script>
			<script src="assets/js/jquery.magnific-popup.min.js"></script>
			<script src="assets/js/jquery.touchSwipe.min.js"></script>
			<script src="assets/js/jquery.liquid-slider.js"></script>
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script> 
			<script src="assets/js/gmap3.min.js"></script>
			<script src="assets/js/ionrangeslider.js"></script>
			<script src="assets/js/classie.js"></script>
			<script src="assets/js/wow.min.js"></script>
		       
		<!-- Custom Script -->		
			<script src="assets/js/main.js"></script>
		<!-- Theme Panel Style Switcher -->
			<script src="assets/js/theme_panel.js"></script>		
		
	</body>

<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-shop-home.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:46:36 GMT -->
</html>
