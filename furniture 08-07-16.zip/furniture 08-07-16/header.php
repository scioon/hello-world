<!DOCTYPE html>
<html lang="en">
	
	
<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-home-2.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:45:17 GMT -->
<head>
		<title>Mahesh Wooden Furniture</title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="assets/images/service-logo.png">

		
		<!-- Web fonts -->
			<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,800,300,600,700' rel='stylesheet' type='text/css'>

			<link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>

			<link href='http://fonts.googleapis.com/css?family=Raleway:500,600,700,300' rel='stylesheet' type='text/css'>
		<!-- Main css -->
			<link href="assets/css/font-awesome.min.css" rel="stylesheet" >
			<link href="assets/css/bootstrap.min.css" rel="stylesheet">
			<link href="assets/css/style.css" rel="stylesheet">
			<link href="assets/css/slider/settings.css" rel="stylesheet">
			<link href="assets/css/slider/extralayers.css" rel="stylesheet">
			<link href="assets/css/slick.css" rel="stylesheet">
			<link href="assets/css/media.css" rel="stylesheet">
			<link href="assets/css/animate.min.css" rel="stylesheet" >
			<link href="assets/css/liquid-slider.css" rel="stylesheet" >
			<link href="assets/css/component.css" rel="stylesheet">
		<!-- Skin Color -->
			<link href="assets/css/color/beige.css" rel="stylesheet" id="color-skins" >
		
		<!-- Style Switcher --> 
        	<link href="assets/css/theme_panel.css" rel="stylesheet" />		
			
	</head>
  

	<body class="parallax">
		
		<!-- PRELOADER START -->
			<div id="preloader">
				<div class="preloader-container">
					<h4 class="preload-logo triggerAnimation animated" data-animate="bounceIn">Mahesh Wooden Furniture</h4>
					<img src="assets/images/preloader.gif" class="preload-gif" alt="Ricochet">
				</div>
			</div>
		<!-- PRELOADER END -->
	
		<!-- Corporate Nav Top -->
			<section id="nav-top-corporate" class="hidden-xs">
				<div class="container">
					<div class="row">
						<div class="col-sm-6">
							<div class="Corporate-top-left">
								<p><span><a href="tel:+4105778763452">Call Now <i class="fa fa-phone" aria-hidden="true">+(91) - 9154288965</a></i></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><i class="fa fa-envelope" aria-hidden="true">&nbsp;info@woodenfurniture.com</a></p></i>
							</div>
						</div>
						<div class="col-sm-6 corporate-cart">
							<div class="corporate-top-cart">
							<div class="cp-footer-social">
									<ul>
										<li class="wow fadeInDown" data-wow-delay=".0s"><a href="https://www.facebook.com/mahesh.wooden"><i class="fa fa-facebook"></i></a></li>
										<!-- <li class="wow fadeInDown" data-wow-delay=".1s"><a href="#"><i class="fa fa-dribbble"></i></a></li> -->
										<li class="wow fadeInDown" data-wow-delay=".2s"><a href="https://twitter.com/woodenfurnitur3"><i class="fa fa-twitter"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".2s"><a href="https://plus.google.com/collections?hl=en"><i class="fa fa-google-plus"></i></a></li>
										<!-- <li class="wow fadeInDown" data-wow-delay=".3s"><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".4s"><a href="#"><i class="fa fa-skype"></i></a></li> -->
									</ul>
								</div>
								<div class="corporate-nav-cart">
									<ul>
										<!-- <li><a href="#">LOGIN<span>/</span></a></li>
										<li><a href="#">CART<span>$0</span></a></li> -->
										<!-- <li><img src="assets/images/cart-count-icon-white.png" alt=""></li> -->
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Corporate Nav Top -->

		<!-- Navigation Section -->
			<section id="navigation" class="shadow">
			
				<div class="container inner navigation">
					
					<!-- Logo Img -->
					
					<div class="logo">
						<a class="scroll" href="corporate-home.php"><img src="assets/images/l1.png" alt="Logo"/></a>
						<p class="hidden-xs"><em>Furniture is meant to be used and enjoyed. 
</em></p>
					</div>
					
					
					
					<!-- Nav Menu -->
					<div class="nav-menu">
						
						<ul class="nav main-nav right-30">
						
							<li class="dropdown-toggle nav-toggle active">
								<li class="active"><a href="index.php">Home</a>
								<ul class="dropdown-menu">
									
									<!-- <li class="active"><a href="corporate-home-2.php">Home 2</a></li> -->
								</ul>
							</li>
							
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="about.php">About Us</a>

								<!-- <ul class="dropdown-menu">

									<li><a href="about.php">About us</a></li>
									<li><a href="corporate-services.php">our services</a></li>

								</ul> -->

							</li>
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="portfolio.php">portfolio</a>

								<!-- <ul class="dropdown-menu">

									<li><a href="corporate-portfolio.php">portfolio</a></li>
									<li><a href="corporate-portfolio-two.php">portfolio 2</a></li>
									<li><a href="corporate-portfolio-single.php">portfolio single</a></li>

								</ul> -->

							</li>
							<!-- <li class="dropdown-toggle nav-toggle"><a class="scroll" href="#">news</a> -->

								<!-- <ul class="dropdown-menu">

									<li><a href="corporate-blog.php">Blog</a></li>
									<li><a href="corporate-blog-single.php">Blog single</a></li>

								</ul> -->

							<!-- </li> -->
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="shopdetail.php">Shop</a>

								<!-- <ul class="dropdown-menu">

									<li><a href="corporate-shop-home.php">Shop home</a></li>
									<li><a href="corporate-shop-list.php">shop list</a></li>
									<li><a href="corporate-shop-detail.php">Shop detail</a></li>

								</ul> -->

							</li>
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="services.php">Services</a>
</li>
							<li><a class="scroll" href="contact.php">contact</a></li>
						
						</ul>
						
						<div class="top-search">
							<div id="morphsearch" class="morphsearch">
								<form class="morphsearch-form">
									<input class="morphsearch-input" type="search" placeholder="Search"/>
									<i class="fa fa-search morph-icon"></i>
									<button class="morphsearch-submit" type="submit">aaaaaa</button>
								</form>
								<!-- /morphsearch-content -->
								<span class="morphsearch-close"></span>
							</div>
							
						</div>
						
						
						
					</div>
					
					
					
					
						<!-- Dropdown Menu For Mobile Devices-->
					
						<div class="dropdown mobile-drop">
						  <a data-toggle="dropdown" class="mobile-menu" href="#"><i class="fa fa-bars"></i></a>
						  
							<ul class="nav dropdown-menu extra fullwidth" role="menu" >
								<li class="dropdown-toggle mobile-toggle active"><a class="scroll">Home</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-home.php">Home 1</a></li>
										<li class="active"><a href="corporate-home-2.php">Home 2</a></li>

									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="scroll">about</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-about-us.php">About us</a></li>
										<li><a href="corporate-services.php">our services</a></li>

									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="portfolio.php">portfolio</a>

									<!-- <ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-portfolio.php">portfolio</a></li>
										<li><a href="corporate-portfolio-two.php">portfolio 2</a></li>
										<li><a href="corporate-portfolio-single.php">portfolio single</a></li>

									</ul> -->

								</li>
								<!-- <li class="dropdown-toggle mobile-toggle"><a class="scroll">news</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-blog.php">Blog</a></li>
										<li><a href="corporate-blog-single.php">Blog single</a></li>


									</ul> -->

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="shopdetail.php">Shop</a>

									<ul class="dropdown-menu dr-mobile">

										<!-- <li><a href="corporate-shop-home.php">Shop home</a></li>
									<li><a href="corporate-shop-list.php">shop list</a></li>
									<li><a href="corporate-shop-detail.php">Shop detail</a></li> -->


									</ul>

								</li>
								
								<li><a class="scroll" href="contact.php">contact</a></li>
							</ul>
						  
						  
						</div>
						
						
						
					
				
					<div class="clear"></div>
					
				</div>
					
			
			</section>
		<!-- End Navigation Section -->