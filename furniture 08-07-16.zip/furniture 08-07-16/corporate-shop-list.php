<!DOCTYPE html>
<html lang="en">
	
	
<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-shop-list.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:46:36 GMT -->
<head>
		<title>Ricochet Multi-Purpose HTML Template By Mkscoder</title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="assets/images/service-logo.png">

		
		<!-- Web fonts -->
			<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,800,300,600,700' rel='stylesheet' type='text/css'>
			<link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
			<link href='http://fonts.googleapis.com/css?family=Raleway:500,600,700,300' rel='stylesheet' type='text/css'>
		<!-- Main css -->
			<link href="assets/css/font-awesome.min.css" rel="stylesheet" >
			<link href="assets/css/bootstrap.min.css" rel="stylesheet">
			<link href="assets/css/style.css" rel="stylesheet">
			<link href="assets/css/cubeportfolio.css" rel="stylesheet">
			<link href="assets/css/media.css" rel="stylesheet">
			<link href="assets/css/animate.min.css" rel="stylesheet" >
			<link href="assets/css/liquid-slider.css" rel="stylesheet" >
			<link href="assets/css/component.css" rel="stylesheet">
		<!-- Skin Color -->
			<link href="assets/css/color/beige.css" rel="stylesheet" id="color-skins" >
		
		<!-- Style Switcher --> 
        	<link href="assets/css/theme_panel.css" rel="stylesheet" />		
			
	</head>
  

	<body class="parallax">
		
		<!-- PRELOADER START -->
			<div id="preloader">
				<div class="preloader-container">
					<h4 class="preload-logo triggerAnimation animated" data-animate="bounceIn">Ricochet</h4>
					<img src="assets/images/preloader.gif" class="preload-gif" alt="Ricochet">
				</div>
			</div>
		<!-- PRELOADER END -->

		<!-- Corporate Nav Top -->
			<section id="nav-top-corporate" class="hidden-xs">
				<div class="container">
					<div class="row">
						<div class="col-sm-6">
							<div class="Corporate-top-left">
								<p><span><a href="tel:+4105778763452">+41 (0) 57 7876 3452</a></span> <a href="mailto:info@ricochet.com">info@ricochet.com</a></p>
							</div>
						</div>
						<div class="col-sm-6 corporate-cart">
							<div class="corporate-top-cart">
								<div class="corporate-nav-cart">
									<ul>
										<li><a href="#">LOGIN<span>/</span></a></li>
										<li><a href="#">CART<span>$0</span></a></li>
										<li><img src="assets/images/cart-count-icon-white.png" alt=""></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Corporate Nav Top -->

		<!-- Navigation Section -->
			<section id="navigation" class="shadow">
			
				<div class=" container inner navigation">
					
					<!-- Logo Img -->
					
					<div class="logo">
						<a class="scroll" href="corporate-home.php"><img src="assets/images/logo.png" alt="Logo"/></a>
						<p class="hidden-xs"><em>Where Art Meets Interior</em></p>
					</div>
					
					
					
					<!-- Nav Menu -->
					<div class="nav-menu">
						
						<ul class="nav main-nav right-30">
						
							<li class="dropdown-toggle nav-toggle">
								<a class="scroll" href="#">Home</a>
								<ul class="dropdown-menu">
									<li><a href="corporate-home.php">Home 1</a></li>
									<li><a href="corporate-home-2.php">Home 2</a></li>
								</ul>
							</li>
							
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="#">About</a>

								<ul class="dropdown-menu">

									<li><a href="corporate-about-us.php">About us</a></li>
									<li><a href="corporate-services.php">our services</a></li>

								</ul>

							</li>
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="#">portfolio</a>

								<ul class="dropdown-menu">

									<li><a href="corporate-portfolio.php">portfolio</a></li>
									<li><a href="corporate-portfolio-two.php">portfolio 2</a></li>
									<li><a href="corporate-portfolio-single.php">portfolio single</a></li>

								</ul>

							</li>
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="#">news</a>

								<ul class="dropdown-menu">

									<li><a href="corporate-blog.php">Blog</a></li>
									<li><a href="corporate-blog-single.php">Blog single</a></li>

								</ul>

							</li>
							<li class="dropdown-toggle nav-toggle active"><a class="scroll" href="#">Shop</a>

								<ul class="dropdown-menu">

									<li><a href="corporate-shop-home.php">Shop home</a></li>
									<li class="active"><a href="corporate-shop-list.php">shop list</a></li>
									<li><a href="corporate-shop-detail.php">Shop detail</a></li>

								</ul>

							</li>
							
							<li><a class="scroll" href="corporate-contact.php">contact</a></li>
						
						</ul>
						
						<div class="top-search">
							<div id="morphsearch" class="morphsearch">
								<form class="morphsearch-form">
									<input class="morphsearch-input" type="search" placeholder="Search"/>
									<i class="fa fa-search morph-icon"></i>
									<button class="morphsearch-submit" type="submit">aaaaaa</button>
								</form>
								<!-- /morphsearch-content -->
								<span class="morphsearch-close"></span>
							</div>
							
						</div>
						
						
						
					</div>
					
					
					
					
						<!-- Dropdown Menu For Mobile Devices-->
					
						<div class="dropdown mobile-drop">
						  <a data-toggle="dropdown" class="mobile-menu" href="#"><i class="fa fa-bars"></i></a>
						  
						<ul class="nav dropdown-menu extra fullwidth" role="menu" >
								<li class="dropdown-toggle mobile-toggle"><a class="scroll">Home</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-home.php">Home 1</a></li>
										<li><a href="corporate-home-2.php">Home 2</a></li>

									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="scroll">about</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-about-us.php">About us</a></li>
										<li><a href="corporate-services.php">our services</a></li>

									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="scroll">portfolio</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-portfolio.php">portfolio</a></li>
										<li><a href="corporate-portfolio-two.php">portfolio 2</a></li>
										<li><a href="corporate-portfolio-single.php">portfolio single</a></li>

									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="scroll">news</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-blog.php">Blog</a></li>
										<li><a href="corporate-blog-single.php">Blog single</a></li>


									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle active"><a class="scroll">Shop</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-shop-home.php">Shop home</a></li>
										<li class="active"><a href="corporate-shop-list.php">shop list</a></li>
										<li><a href="corporate-shop-detail.php">Shop detail</a></li>


									</ul>

								</li>
								
								<li><a class="scroll" href="corporate-contact.php">contact</a></li>
							</ul>
						  
						  
						</div>
						
						
						
					
				
					<div class="clear"></div>
					
				</div>
					
			
			</section>
		<!--/ End Navigation Section -->
		
		<!-- Page title -->
			<section class="page-title-wrap">
				<div class="page-title-img shop-pagetitle-bg">
					<div class="container">
						<div class="row">
							<div class="cp-page-title-wrap">
								<div class="header-color-back">
									<div class="header-main-content">
										<h1><span>Shop</span></h1>
										<p>We are Ricochet. Interior Design Company.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Page title -->
		
		<!-- Main Content -->
			<section id="shop-item" class="shop-item">
				<div class="container">
					<div class="row">
						<!-- Shop Item -->
						<div class="col-sm-9">
							<div class="shop-right">
								<div class="row">
									<div class="col-sm-6">
										<div class="shop-item-heading">
											<p>Showing all 9 results</p>
										</div>
									</div>
									<div class="col-sm-6 shop-right-item-padding">
										<div class="shop-item-heading-right">
											<ul>
												<li>
												<!-- Shop Top Dropdown -->
													<div class="shop-top-dropdown">
														<div class="shop-top-dropdown">
															<div class="">
																<select>
																	<option>Default Sorting</option>
																	<option>Newest Item</option>
																	<option>Date</option>
																	<option>Price</option>
																	<option>Newest Item</option>
																</select>
															</div>
														</div>
													</div>
												<!--/ End Shop Top Dropdown -->	
												</li>
												<li>
													<!-- Shop Top Pagination Button -->
														<div class="shop-pagination">
															<div class="btn-group" role="group" aria-label="first group">
																<button type="button" class="btn btn-default active">1</button>
															</div>
															<div class="btn-group" role="group" aria-label="first group">
																<button type="button" class="btn btn-default">2</button>
															</div>
															<div class="btn-group" role="group" aria-label="first group">
																<button type="button" class="btn btn-default">3</button>
															</div>
														</div>
													<!--/ Shop Top Pagination Button -->
												</li>
											</ul>
											
										</div>
									</div>
								</div>
								<div class="shop-heading-border"></div>
							<!-- Shop Item First Row -->	
								<div class="row custom-15">
								<!-- Shop Item One -->
									<div class="col-sm-4">
										<div class="thumbnail light-grey">
											<div class="shop-item-figure">
												<img src="assets/images/shop/shop-item-1.jpg" alt="">
												<div class="shop-item-figcaption">
													<div class="star-image">
														<ul>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
														</ul>
													</div>
													<div class="shop-item-link">
														<ul>
															<li><a class="link-one" href="#">Add to wishlist</a></li>
															<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
														</ul>
													</div>
												</div>
												
												<div class="item-sale">
													<P>Sale!</P>
												</div>
											</div>
											<div class="caption">
												<h4>LIVING ROOM</h4>
												<h2>Modern Sofa</h2>
												<p><span><del>$487</del></span> $250</p>
												<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
											</div>
										</div>
									</div>
								<!--/ End Shop Item One -->
								
								<!-- Shop Item Two -->
									<div class="col-sm-4">
										<div class="thumbnail light-grey">
											<div class="shop-item-figure">
												<img src="assets/images/shop/shop-item-2.jpg" alt="">
												<div class="shop-item-figcaption">
													<div class="star-image">
														<ul>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
														</ul>
													</div>
													<div class="shop-item-link">
														<ul>
															<li><a class="link-one" href="#">Add to wishlist</a></li>
															<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
														</ul>
													</div>
												</div>
												
											</div>
											<div class="caption">
												<h4>BEDROOM</h4>
												<h2>NIGHT LAMP</h2>
												<h5>$89</h5>
												<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
											</div>
										</div>
									</div>
								<!--/ End Shop Item Two -->
								
								<!-- Shop Item Three -->
									<div class="col-sm-4">
										<div class="thumbnail light-grey">
											<div class="shop-item-figure">
												<img src="assets/images/shop/shop-item-3.jpg" alt="">
												<div class="shop-item-figcaption">
													<div class="star-image">
														<ul>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
														</ul>
													</div>
													<div class="shop-item-link">
														<ul>
															<li><a class="link-one" href="#">Add to wishlist</a></li>
															<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
														</ul>
													</div>
												</div>
												
											</div>
											<div class="caption">
												<h4>LIVING ROOM</h4>
												<h2>RED COUCH</h2>
												<h5>$853</h5>
												<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
											</div>
										</div>
									</div>
								<!--/ End Shop Item Three -->
								
								</div>
							<!--/ End Shop Item First Row -->	
							
							
							<!-- Shop Item Second Row -->	
								<div class="row custom-15">
								<!-- Shop Item One -->
									<div class="col-sm-4">
										<div class="thumbnail light-grey">
											<div class="shop-item-figure">
												<img src="assets/images/shop/shop-item-4.jpg" alt="">
												<div class="shop-item-figcaption">
													<div class="star-image">
														<ul>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
														</ul>
													</div>
													<div class="shop-item-link">
														<ul>
															<li><a class="link-one" href="#">Add to wishlist</a></li>
															<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
														</ul>
													</div>
												</div>
												
											</div>
											<div class="caption">
												<h4>LIVING ROOM</h4>
												<h2>BLACK LATHER COUCH</h2>
												<h5>$1479</h5>
												<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
											</div>
										</div>
									</div>
									
								<!--/ End Shop Item One -->
								
								<!-- Shop Item Two -->
									<div class="col-sm-4">
										<div class="thumbnail light-grey">
											<div class="shop-item-figure">
												<img src="assets/images/shop/shop-item-5.jpg" alt="">
												<div class="shop-item-figcaption">
													<div class="star-image">
														<ul>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
														</ul>
													</div>
													<div class="shop-item-link">
														<ul>
															<li><a class="link-one" href="#">Add to wishlist</a></li>
															<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
														</ul>
													</div>
												</div>
												
												<div class="item-sale">
													<P>Sale!</P>
												</div>
											</div>
											<div class="caption">
												<h4>BEDROOM</h4>
												<h2>COUCH - BED</h2>
												<p><span><del>$487</del></span> $250</p>
												<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
											</div>
										</div>
									</div>
									
								<!--/ End Shop Item Two -->
								
								<!-- Shop Item Three -->
									<div class="col-sm-4">
										<div class="thumbnail light-grey">
											<div class="shop-item-figure">
												<img src="assets/images/shop/shop-item-6.jpg" alt="">
												<div class="shop-item-figcaption">
													<div class="star-image">
														<ul>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
														</ul>
													</div>
													<div class="shop-item-link">
														<ul>
															<li><a class="link-one" href="#">Add to wishlist</a></li>
															<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
														</ul>
													</div>
												</div>
												
											</div>
											<div class="caption">
												<h4>LIVING ROOM</h4>
												<h2>Modern Sofa</h2>
												<h5>$853</h5>
												<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
											</div>
										</div>
									</div>
								<!--/ End Shop Item Three -->
								</div>
							<!--/ End Shop Item Second Row -->
							
							<!-- Shop Item Third Row -->	
								<div class="row custom-15">
								<!-- Shop Item One -->
									<div class="col-sm-4">
										<div class="thumbnail light-grey">
											<div class="shop-item-figure">
												<img src="assets/images/shop/shop-item-7.jpg" alt="">
												<div class="shop-item-figcaption">
													<div class="star-image">
														<ul>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
														</ul>
													</div>
													<div class="shop-item-link">
														<ul>
															<li><a class="link-one" href="#">Add to wishlist</a></li>
															<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
														</ul>
													</div>
												</div>
												
												<div class="item-sale">
													<P>Sale!</P>
												</div>
											</div>
											<div class="caption">
												<h4>BEDROOM</h4>
												<h2>STANDING LAMP</h2>
												<p><span><del>$487</del></span> $129</p>
												<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
											</div>
										</div>
									</div>
								<!--/ End Shop Item One -->
								
								<!-- Shop Item Two -->
									<div class="col-sm-4">
										<div class="thumbnail light-grey">
											<div class="shop-item-figure">
												<img src="assets/images/shop/shop-item-8.jpg" alt="">
												<div class="shop-item-figcaption">
													<div class="star-image">
														<ul>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
														</ul>
													</div>
													<div class="shop-item-link">
														<ul>
															<li><a class="link-one" href="#">Add to wishlist</a></li>
															<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
														</ul>
													</div>
												</div>
												
											</div>
											<div class="caption">
												<h4>KITCHEN</h4>
												<h2>SMALL KITCHEN TABLE</h2>
												<h5>$1479</h5>
												<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
											</div>
										</div>
									</div>
								<!--/ End Shop Item Two -->
								
								<!-- Shop Item Three -->
									<div class="col-sm-4">
										<div class="thumbnail light-grey">
											<div class="shop-item-figure">
												<img src="assets/images/shop/shop-item-3.jpg" alt="">
												<div class="shop-item-figcaption">
													<div class="star-image">
														<ul>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
															<li><i class="fa fa-star-half-empty"></i></li>
														</ul>
													</div>
													<div class="shop-item-link">
														<ul>
															<li><a class="link-one" href="#">Add to wishlist</a></li>
															<li><a class="link-two" href="corporate-shop-detail.php">View Details</a></li>
														</ul>
													</div>
												</div>
												
											</div>
											<div class="caption">
												<h4>LIVING ROOM</h4>
												<h2>RED COUCH</h2>
												<h5>$853</h5>
												<p><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p>
											</div>
										</div>
									</div>
								<!--/ End Shop Item Three -->
								
								</div>
							<!--/ End Shop Item Third Row -->

							
								<div class="row custom-15">
									<div class="col-sm-12 align">
										<!-- Shop Bottom Pagination Button -->
											<div class="shop-pagination">
												<div class="btn-group" role="group" aria-label="first group">
													<button type="button" class="btn btn-default active">1</button>
												</div>
												<div class="btn-group" role="group" aria-label="first group">
													<button type="button" class="btn btn-default">2</button>
												</div>
												<div class="btn-group" role="group" aria-label="first group">
													<button type="button" class="btn btn-default">3</button>
												</div>
											</div>
										<!--/ Shop Bottom Pagination Button -->
									</div>
								</div>
							</div>
						</div>
						
						<div class="col-sm-3 shop-item-left-back">
							<div class="shop-item-left">
								<div class="left-cart">
									<h4>Cart</h4>
									<div class="left-cart-image">
										<img src="assets/images/shop/left-cart-1.jpg" alt="">
										<div class="left-cart-content">
											<h6>Modern Sofa</h6>
											<p>1 x <span>$250</span></p>
										</div>
									</div>
								</div>
								<div class="left-cart-border"></div>
								
								<p class="left-cart-total">Subtotal:<span>$250</span></p>
								<div class="left-cart-link">
									<ul>
										<li>
											<a href="#">View Cart</a>
										</li>
										<li>
											<a href="#">Cheakout</a>
										</li>
									</ul>
								</div>
								
								<div class="sidebar-box">
									<h4>Filter by price</h4>
									<input type="text" id="price-slider">
									<div class="filter">
										<h5><span>Filter</span></h5>
										<p>Price: $25-$399</p>
									</div>
								</div>
								
								<div class="Shop-category">
									<div class="sidebar-box">
										<h4>shop categories</h4>
									</div>
									<div class="blog-category">
										<ul>
											<li>
												<a href="#">
													<i class="fa fa-angle-right"></i><span>All</span>
												</a>
											</li>
											<li>
												<a href="#">
													<i class="fa fa-angle-right"></i><span>Living Room</span>
												</a>
											</li>
											<li>
												<a href="#">
													<i class="fa fa-angle-right"></i><span>Bedroom</span>
												</a>
											</li>
											<li class="no-border">
												<a href="#">
													<i class="fa fa-angle-right"></i><span>Kitchen</span>
												</a>
											</li>
										</ul>
									</div>
								</div>
								
								<div class="onsale-left">
									<div class="sidebar-box">
										<h4>On sale</h4>
										
										<div class="onsale-cart-image">
											<img src="assets/images/shop/left-cart-1.jpg" alt="">
											<div class="onsale-cart-content">
												<h6><a href="#">Orange Retro Sofa</a></h6>
												<p> <del> $125 </del> <span>$99</span></p>
											</div>
										</div>
										
										<div class="onsale-cart-image">
											<img src="assets/images/shop/left-cart-2.jpg" alt="">
											<div class="onsale-cart-content">
												<h6><a href="#">Leather Couch</a></h6>
												<p> <del> $125 </del> <span>$99</span></p>
											</div>
										</div>
										
										<div class="onsale-cart-image">
											<img src="assets/images/shop/left-cart-3.jpg" alt="">
											<div class="onsale-cart-content">
												<h6><a href="#">Red Modern Sofa</a></h6>
												<p> <del> $99 </del> <span>$75</span></p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Main Content -->
		
		<!-- Footer Top Start -->
			<section id="corporate-footer-top">
				<div class="container">
					<div class="row">
						<div class="col-sm-4">
						<div class="footer-top-back">
							<div class="cp-footer-top-left">
								<a class="wow fadeInDown" data-wow-delay=".0s" href="corporate-home.php"><img src="assets/images/logo-white.png" alt=""></a>
								
								
								<p class="wow fadeInDown" data-wow-delay=".1s"><strong><a href="tel:+4105778763452">+41 (0) 57 7876 3452</a></strong></p>
								<p class="wow fadeInDown" data-wow-delay=".2s"><a href="mailto:info@ricochet.com">info@ricochet.com</a></p>
								<p class="wow fadeInDown" data-wow-delay=".3s">1st Kengiston Street, LA, USA</p>
							</div>
						</div>	
						</div>
						<div class="col-sm-4">
							<div class="cp-footer-top-middle">
								<div class="cp-footer-head">
									<h3>Quick Links</h3>
								</div>
								
								<div class="middle-left-cp">
									<ul>
										<li class="wow fadeInRight" data-wow-delay=".0s"><a href="#"><i class="fa fa-angle-right"></i>About Us</a></li>
										<li class="wow fadeInRight" data-wow-delay=".1s"><a href="#"><i class="fa fa-angle-right"></i>Our Services</a></li>
										<li class="wow fadeInRight" data-wow-delay=".2s"><a href="#"><i class="fa fa-angle-right"></i>Company news</a></li>
										<li class="wow fadeInRight" data-wow-delay=".3s"><a href="#"><i class="fa fa-angle-right"></i>Portfolio</a></li>
										<li class="wow fadeInRight" data-wow-delay=".4s"><a href="#"><i class="fa fa-angle-right"></i>Shop</a></li>
									</ul>
								</div>
								<div class="middle-right-cp">
									<ul>
										<li class="wow fadeInRight" data-wow-delay=".0s"><a href="#"><i class="fa fa-angle-right"></i>Buyer Support</a></li>
										<li class="wow fadeInRight" data-wow-delay=".1s"><a href="#"><i class="fa fa-angle-right"></i>Legal Information</a></li>
										<li class="wow fadeInRight" data-wow-delay=".2s"><a href="#"><i class="fa fa-angle-right"></i>Privacy Policy</a></li>
										<li class="wow fadeInRight" data-wow-delay=".3s"><a href="#"><i class="fa fa-angle-right"></i>Payment Options</a></li>
										<li class="wow fadeInRight" data-wow-delay=".4s"><a href="#"><i class="fa fa-angle-right"></i>Partners & Suppliers</a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="cp-footer-top-right">
								<div class="cp-footer-head">
									<h3>SOCIAL</h3>
								</div>
								<div class="cp-footer-social">
									<ul>
										<li class="wow fadeInDown" data-wow-delay=".0s"><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".1s"><a href="#"><i class="fa fa-dribbble"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".2s"><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".3s"><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".4s"><a href="#"><i class="fa fa-skype"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Footer Top -->

		
		<!-- Footer Start -->
			<section id="corporate-footer">
				<div class="container">
					<div class="row">
						<div class="col-sm-6 corporate-footer-left">
							<p>RICOCHET 2015. Design by Pixel Industry d.o.o.</p>
						</div>
						
						<div class="col-sm-6 corporate-footer-right">
							<p>Pixel Industry d.o.o. All Rights Reserved</p>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Footer -->
		
		<!-- Theme Panel Switcher Start -->
	        <section id="theme-panel" class="panel-close">
	            <a class="panel-btn"><i class="fa fa-spinner icon-spin"></i></a>
	            <div class="theme-panel-title">
	                <h4>Style Switcher</h4>
	            </div>
	            <div class="colors-container">
	                <p class="amount-1" style="line-height:0;">10 Color Skins</p>
					<a title="beige" class="color-switch beige"></a>
	                <a title="red" class="color-switch red"></a>
					<a title="blue-2" class="color-switch blue-2"></a>
	                <a title="pink" class="color-switch pink"></a>
	                <a title="blue" class="color-switch blue"></a>
	                <a title="purple" class="color-switch purple"></a>
	                <a title="green" class="color-switch green"></a>
	                <a title="yellow" class="color-switch yellow"></a>
	                <a title="orange" class="color-switch orange"></a>
					<a title="midnight" class="color-switch midnight"></a>
	            </div>
	            <div class="colors-container">
	            	<p class="about-colors">
					There are unlimited posibilities to make your own color style. We have included 10 color css in this template. Thanks for using our themplate.
					</p>
				</div>
	        </section>
    	<!-- Theme Panel Switcher End -->	
		

		<!-- ============ Js Files ============ -->

	    <!-- Placed at the end of the document so the pages load faster -->
		
		<!-- main js -->
			<script src="assets/js/jquery-1.11.2.min.js"></script>
				
			<script src="assets/js/bootstrap.min.js"></script>	
			<script src="assets/js/jquery.sticky.js"></script>	
			
			<script src="assets/js/jquery.cubeportfolio.min.js"></script>	
			<script src="assets/js/portfolio-custom.js"></script>	
			<script src="assets/js/slick.min.js"></script>
			<script src="assets/js/modernizr.custom.js"></script>
			<script src="assets/js/jquery.magnific-popup.min.js"></script>
			<script src="assets/js/jquery.touchSwipe.min.js"></script>
			<script src="assets/js/jquery.liquid-slider.js"></script>
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script> 
			<script src="assets/js/gmap3.min.js"></script>	
			<script src="assets/js/ionrangeslider.js"></script>
			<script src="assets/js/classie.js"></script>
			<script src="assets/js/wow.min.js"></script>
			
		       
		<!-- Custom Script -->		
			<script src="assets/js/main.js"></script>
		<!-- Theme Panel Style Switcher -->
			<script src="assets/js/theme_panel.js"></script>		
		
	</body>

<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-shop-list.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:46:36 GMT -->
</html>
