<!DOCTYPE html>
<html lang="en">
	
	
<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-portfolio.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:45:40 GMT -->
<head>
		<title>Mahesh Wooden Furniture</title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="assets/images/service-logo.png">

		
		<!-- Web fonts -->
			<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,800,300,600,700' rel='stylesheet' type='text/css'>
			<link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
			<link href='http://fonts.googleapis.com/css?family=Raleway:500,600,700,300' rel='stylesheet' type='text/css'>
		<!-- Main css -->
			<link href="assets/css/font-awesome.min.css" rel="stylesheet" >
			<link href="assets/css/bootstrap.min.css" rel="stylesheet">
			<link href="assets/css/style.css" rel="stylesheet">
			<link href="assets/css/cubeportfolio.css" rel="stylesheet">
			<link href="assets/css/media.css" rel="stylesheet">
			<link href="assets/css/animate.min.css" rel="stylesheet" >
			<link href="assets/css/liquid-slider.css" rel="stylesheet" >
			<link href="assets/css/component.css" rel="stylesheet">	
		<!-- Skin Color -->
			<link href="assets/css/color/beige.css" rel="stylesheet" id="color-skins" >
		
		<!-- Style Switcher --> 
        	<link href="assets/css/theme_panel.css" rel="stylesheet" />		
	</head>
  

	<body class="parallax">
		
		<!-- PRELOADER START -->
			<div id="preloader">
				<div class="preloader-container">
					<h4 class="preload-logo triggerAnimation animated" data-animate="bounceIn">Mahesh Wooden Furniture</h4>
					<img src="assets/images/preloader.gif" class="preload-gif" alt="Ricochet">
				</div>
			</div>
		<!-- PRELOADER END -->

		<!-- Corporate Nav Top -->
			<section id="nav-top-corporate" class="hidden-xs">
				<div class="container">
					<div class="row">
						<div class="col-sm-6">
							<div class="Corporate-top-left">
								<p><span><a href="tel:+4105778763452">Call Now <i class="fa fa-phone" aria-hidden="true">+(91) - 9154288965</a></i></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><i class="fa fa-envelope" aria-hidden="true">&nbsp;info@woodenfurniture.com</a></p></i>
							</div>
						</div>
						<div class="col-sm-6 corporate-cart">
							<div class="corporate-top-cart">
							<div class="cp-footer-social">
									<ul>
										<li class="wow fadeInDown" data-wow-delay=".0s"><a href="https://www.facebook.com/mahesh.wooden"><i class="fa fa-facebook"></i></a></li>
										<!-- <li class="wow fadeInDown" data-wow-delay=".1s"><a href="#"><i class="fa fa-dribbble"></i></a></li> -->
										<li class="wow fadeInDown" data-wow-delay=".2s"><a href="https://twitter.com/woodenfurnitur3"><i class="fa fa-twitter"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".2s"><a href="https://plus.google.com/collections?hl=en"><i class="fa fa-google-plus"></i></a></li>
										<!-- <li class="wow fadeInDown" data-wow-delay=".3s"><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".4s"><a href="#"><i class="fa fa-skype"></i></a></li> -->
									</ul>
								</div>
								<div class="corporate-nav-cart">
									<ul>
										<!-- <li><a href="#">LOGIN<span>/</span></a></li>
										<li><a href="#">CART<span>$0</span></a></li>
										<li><img src="assets/images/cart-count-icon-white.png" alt=""></li> -->
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Corporate Nav Top -->

		<!-- Navigation Section -->
			<section id="navigation" class="shadow">
			
				<div class="container inner navigation">
					
					<!-- Logo Img -->
					
					<div class="logo">
						<a class="scroll" href="corporate-home.html"><img src="assets/images/logo.png" alt="Logo"/></a>
						<p class="hidden-xs"><em>Furniture is meant to be used and enjoyed.</em></p>
					</div>
					
					
					
					<!-- Nav Menu -->
					
					<!-- Nav Menu -->
					<div class="nav-menu">
						
						<ul class="nav main-nav right-30">
						
							<li class="dropdown-toggle nav-toggle active">
								<li class="active"><a href="index.php">Home</a>
								<ul class="dropdown-menu">
									
									<!-- <li class="active"><a href="corporate-home-2.php">Home 2</a></li> -->
								</ul>
							</li>
							
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="about.php">About Us</a>

								<!-- <ul class="dropdown-menu">

									<li><a href="about.php">About us</a></li>
									<li><a href="corporate-services.php">our services</a></li>

								</ul> -->

							</li>
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="portfolio.php">portfolio</a>

								<!-- <ul class="dropdown-menu">

									<li><a href="corporate-portfolio.php">portfolio</a></li>
									<li><a href="corporate-portfolio-two.php">portfolio 2</a></li>
									<li><a href="corporate-portfolio-single.php">portfolio single</a></li>

								</ul> -->

							</li>
							<!-- <li class="dropdown-toggle nav-toggle"><a class="scroll" href="#">news</a> -->

								<!-- <ul class="dropdown-menu">

									<li><a href="corporate-blog.php">Blog</a></li>
									<li><a href="corporate-blog-single.php">Blog single</a></li>

								</ul> -->

							<!-- </li> -->
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="shopdetail.php">Shop</a>

								<!-- <ul class="dropdown-menu">

									<li><a href="corporate-shop-home.php">Shop home</a></li>
									<li><a href="corporate-shop-list.php">shop list</a></li>
									<li><a href="corporate-shop-detail.php">Shop detail</a></li>

								</ul> -->

							</li>
							<li class="dropdown-toggle nav-toggle"><a class="scroll" href="services.php">Services</a>
</li>
							<li><a class="scroll" href="contact.php">contact</a></li>
						
						</ul>
						
						<div class="top-search">
							<div id="morphsearch" class="morphsearch">
								<form class="morphsearch-form">
									<input class="morphsearch-input" type="search" placeholder="Search"/>
									<i class="fa fa-search morph-icon"></i>
									<button class="morphsearch-submit" type="submit">aaaaaa</button>
								</form>
								<!-- /morphsearch-content -->
								<span class="morphsearch-close"></span>
							</div>
							
						</div>
						
						
						
					</div>
					
					
					
					
						<!-- Dropdown Menu For Mobile Devices-->
					
						<div class="dropdown mobile-drop">
						  <a data-toggle="dropdown" class="mobile-menu" href="#"><i class="fa fa-bars"></i></a>
						  
							<ul class="nav dropdown-menu extra fullwidth" role="menu" >
								<li class="dropdown-toggle mobile-toggle active"><a class="scroll">Home</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-home.php">Home 1</a></li>
										<li class="active"><a href="corporate-home-2.php">Home 2</a></li>

									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="scroll">about</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-about-us.php">About us</a></li>
										<li><a href="corporate-services.php">our services</a></li>

									</ul>

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="portfolio.php">portfolio</a>

									<!-- <ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-portfolio.php">portfolio</a></li>
										<li><a href="corporate-portfolio-two.php">portfolio 2</a></li>
										<li><a href="corporate-portfolio-single.php">portfolio single</a></li>

									</ul> -->

								</li>
								<!-- <li class="dropdown-toggle mobile-toggle"><a class="scroll">news</a>

									<ul class="dropdown-menu dr-mobile">

										<li><a href="corporate-blog.php">Blog</a></li>
										<li><a href="corporate-blog-single.php">Blog single</a></li>


									</ul> -->

								</li>
								<li class="dropdown-toggle mobile-toggle"><a class="shopdetail.php">Shop</a>

									<ul class="dropdown-menu dr-mobile">

										<!-- <li><a href="corporate-shop-home.php">Shop home</a></li>
									<li><a href="corporate-shop-list.php">shop list</a></li>
									<li><a href="corporate-shop-detail.php">Shop detail</a></li> -->


									</ul>

								</li>
								
								<li><a class="scroll" href="contact.php">contact</a></li>
							</ul>
						  
						  
						</div>
						
						
						
					
				
					<div class="clear"></div>
					
				</div>
					
			
			</section>
		<!--/ End Page title -->
		
		<!-- Main Content -->
			<section id="portfolio">
				<div class="container-fluid">
					<div class="cbp-panel portfolio-wrapper">

				        <div id="filters-container" class="cbp-l-filters-work">
				            <div data-filter="*" class="cbp-filter-item-active cbp-filter-item">
				               	<div class="filter-hover-1"></div>
				               	<div>ALL</div>
				            </div>
				            <div data-filter=".identity" class="cbp-filter-item">
				                <div class="filter-hover-2"></div>
				                <div>LIVING ROOM </div>
				            </div>
				            <div data-filter=".web-design" class="cbp-filter-item">
				                <div class="filter-hover-3"></div>
				                <div>KITCHEN </div>
				            </div>
				            <div data-filter=".graphic" class="cbp-filter-item">
				                <div class="filter-hover-4"></div>
				                <div>BATHROOM </div>
				            </div>
				            <div data-filter=".logos" class="cbp-filter-item">
				                <div class="filter-hover-5"></div>
				                <div>BEDROOM </div>
				            </div>
				            <!-- <div data-filter=".exterior" class="cbp-filter-item">
				                <div class="filter-hover-6"></div>
				                <div>EXTERIOR </div>
				            </div> -->
				        </div>
                         <!--LIVING ROOM-->
				        <div id="grid-container" class="cbp cbp-l-grid-work">
				            <div class="cbp-item identity">
				                <a href="assets/images/portfolio/l2.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/l2.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">LIVING ROOM</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>

				            <div class="cbp-item logos">
				                <a href="assets/images/portfolio/2.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/2.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">MODERN BEDROOM</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
							<div class="cbp-item logos">
				                <a href="assets/images/portfolio/be2.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/be2.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">MODERN BEDROOM</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
							<div class="cbp-item logos">
				                <a href="assets/images/portfolio/be3.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/be3.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">MODERN BEDROOM</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
							<div class="cbp-item logos">
				                <a href="assets/images/portfolio/be4.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/be4.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">MODERN BEDROOM</div>
				                <!--<div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
				            <div class="cbp-item identity">
				                <a href="assets/images/portfolio/3.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/3.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">PENTHOUSE LIVING ROOM</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
				            <div class="cbp-item identity">
				                <a href="assets/images/portfolio/4.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/4.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">PENTHOUSE LIVING ROOM</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
				            <div class="cbp-item identity">
				                <a href="assets/images/portfolio/l1.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/l1.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">LIVING ROOM</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
				            <div class="cbp-item graphic">
				                <a href="assets/images/portfolio/6.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/6.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">BATHROOM</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
							 <div class="cbp-item graphic">
				                <a href="assets/images/portfolio/b2.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/b2.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">SPA BATHROOM</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
							 <div class="cbp-item graphic">
				                <a href="assets/images/portfolio/b8.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/b8.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">BATHROOM</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
							 <div class="cbp-item graphic">
				                <a href="assets/images/portfolio/b4.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/b4.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">MODERN BATHROOM</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
				            <div class="cbp-item web-design">
				                <a href="assets/images/portfolio/7.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/7.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">SMALL APARTMENT KITCHEN</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
				            <div class="cbp-item web-design">
				                <a href="assets/images/portfolio/l3.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/l3.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">Kichen</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
							<div class="cbp-item web-design">
				                <a href="assets/images/portfolio/l4.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/l4.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">Kitchen</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
							<div class="cbp-item web-design">
				                <a href="assets/images/portfolio/l5.jpg" class="cbp-caption cbp-lightbox">
				                    <div class="cbp-caption-defaultWrap">
				                        <img class="img-responsive" src="assets/images/portfolio/l5.jpg" alt="">
				                    </div>
				                    <div class="cbp-caption-activeWrap"></div>
				                </a>
				                <div class="cbp-project-title">Modern Kitchen</div>
				                <!-- <div class="cbp-l-grid-work-desc">Some short portfolio project description. What</div>
				                <div class="cbp-l-grid-work-desc">services did you perfoem, fror who and similar.</div>
				                <a href="#" class="cbp-l-grid-work-title"><span>View Project</span></a> -->
				            </div>
				        </div>
					</div>
				</div>
			</section>
		<!--/ End Main Content -->
		
		<!-- Footer Top Start -->
			<section id="corporate-footer-top">
				<div class="container">
					<div class="row">
						<div class="col-sm-4">
						<div class="footer-top-back">
							<div class="cp-footer-top-left">
								<a class="wow fadeInDown" data-wow-delay=".0s" href="corporate-home.html"><img src="assets/images/logo-white.png" alt=""></a>
								
								
								<p class="wow fadeInDown" data-wow-delay=".1s"><strong><a href="tel:+4105778763452">+(91)- 9154288965</a></strong></p>
								<p class="wow fadeInDown" data-wow-delay=".2s"><a href="mailto:info@ricochet.com">info@woodenfurniture.com</a></p>
								<p class="wow fadeInDown" data-wow-delay=".3s">Padma Nagar, Chintal, Bajpayee Nagar, Quthbullapur, Hyderabad, Telangana 500054.</p>
							</div>
						</div>	
						</div>
						<div class="col-sm-4">
							<div class="cp-footer-top-middle">
								<div class="cp-footer-head">
									<h3>Quick Links</h3>
								</div>
								
								<div class="middle-left-cp">
									<ul>
										<li class="wow fadeInRight" data-wow-delay=".0s"><a href="#"><i class="fa fa-angle-right"></i>About Us</a></li>
										<li class="wow fadeInRight" data-wow-delay=".1s"><a href="#"><i class="fa fa-angle-right"></i>Our Services</a></li>
										<li class="wow fadeInRight" data-wow-delay=".2s"><a href="#"><i class="fa fa-angle-right"></i>Company news</a></li>
										<li class="wow fadeInRight" data-wow-delay=".3s"><a href="#"><i class="fa fa-angle-right"></i>Portfolio</a></li>
										<li class="wow fadeInRight" data-wow-delay=".4s"><a href="#"><i class="fa fa-angle-right"></i>Shop</a></li>
									</ul>
								</div>
								<div class="middle-right-cp">
									<ul>
										<!-- <li class="wow fadeInRight" data-wow-delay=".0s"><a href="#"><i class="fa fa-angle-right"></i>Buyer Support</a></li>
										<li class="wow fadeInRight" data-wow-delay=".1s"><a href="#"><i class="fa fa-angle-right"></i>Legal Information</a></li>
										<li class="wow fadeInRight" data-wow-delay=".2s"><a href="#"><i class="fa fa-angle-right"></i>Privacy Policy</a></li>
										<li class="wow fadeInRight" data-wow-delay=".3s"><a href="#"><i class="fa fa-angle-right"></i>Payment Options</a></li>
										<li class="wow fadeInRight" data-wow-delay=".4s"><a href="#"><i class="fa fa-angle-right"></i>Partners & Suppliers</a></li> -->
									</ul>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="cp-footer-top-right">
								<div class="cp-footer-head">
									<h3>SOCIAL</h3>
								</div>
								<div class="cp-footer-social">
									<ul>
										<li class="wow fadeInDown" data-wow-delay=".0s"><a href="https://www.facebook.com/mahesh.wooden"><i class="fa fa-facebook"></i></a></li>
										<!-- <li class="wow fadeInDown" data-wow-delay=".1s"><a href="#"><i class="fa fa-dribbble"></i></a></li> -->
										<li class="wow fadeInDown" data-wow-delay=".2s"><a href="https://twitter.com/woodenfurnitur3"><i class="fa fa-twitter"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".2s"><a href="https://plus.google.com/collections?hl=en"><i class="fa fa-google-plus"></i></a></li>
										<!-- <li class="wow fadeInDown" data-wow-delay=".3s"><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".4s"><a href="#"><i class="fa fa-skype"></i></a></li> -->
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Footer Top -->

		
		<!-- Footer Start -->
			<section id="corporate-footer">
				<div class="container">
					<div class="row">
						<div class="col-sm-6 corporate-footer-left">
							<p>copy &copy 2016 Mahesh Wooden Furniture All Rights Reserved.</p>
						</div>
						
						<div class="col-sm-6 corporate-footer-right">
							Website Design by <a href="http://www.aniinfosoft.com"><b>Aniinfosoft Inc.</b>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Footer -->
		
		<!-- Theme Panel Switcher Start -->
	        <section id="theme-panel" class="panel-close">
	            <!-- <a class="panel-btn"><i class="fa fa-spinner icon-spin"></i></a> -->
	            <div class="theme-panel-title">
	                <h4>Style Switcher</h4>
	            </div>
	            <div class="colors-container">
	                <p class="amount-1" style="line-height:0;">10 Color Skins</p>
					<a title="beige" class="color-switch beige"></a>
	                <a title="red" class="color-switch red"></a>
					<a title="blue-2" class="color-switch blue-2"></a>
	                <a title="pink" class="color-switch pink"></a>
	                <a title="blue" class="color-switch blue"></a>
	                <a title="purple" class="color-switch purple"></a>
	                <a title="green" class="color-switch green"></a>
	                <a title="yellow" class="color-switch yellow"></a>
	                <a title="orange" class="color-switch orange"></a>
					<a title="midnight" class="color-switch midnight"></a>
	            </div>
	            <div class="colors-container">
	            	<p class="about-colors">
					There are unlimited posibilities to make your own color style. We have included 10 color css in this template. Thanks for using our themplate.
					</p>
				</div>
	        </section>
    	<!-- Theme Panel Switcher End -->	
		

		<!-- ============ Js Files ============ -->

	    <!-- Placed at the end of the document so the pages load faster -->
		
		<!-- main js -->
			<script src="assets/js/jquery-1.11.2.min.js"></script>
				
			<script src="assets/js/bootstrap.min.js"></script>	
			<script src="assets/js/jquery.sticky.js"></script>	
			
			<script src="assets/js/jquery.cubeportfolio.min.js"></script>	
			<script src="assets/js/portfolio-custom.js"></script>	
			<script src="assets/js/slick.min.js"></script>
			<script src="assets/js/modernizr.custom.js"></script>
			<script src="assets/js/jquery.magnific-popup.min.js"></script>
			<script src="assets/js/jquery.touchSwipe.min.js"></script>
			<script src="assets/js/jquery.liquid-slider.js"></script>
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script> 
			<script src="assets/js/gmap3.min.js"></script>
			<script src="assets/js/ionrangeslider.js"></script>
			<script src="assets/js/classie.js"></script>
			<script src="assets/js/wow.min.js"></script>
			
		       
		<!-- Custom Script -->		
			<script src="assets/js/main.js"></script>
		<!-- Theme Panel Style Switcher -->
			<script src="assets/js/theme_panel.js"></script>		
		
	</body>

<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-portfolio.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:45:40 GMT -->
</html>
