<?php include 'header.php';?>
		
		<!-- Page title -->
			<section class="page-title-wrap">
				<div class="page-title-img default-pagetitle-bg">
					<div class="container">
						<div class="row">
							<div class="cp-page-title-wrap">
								<div class="header-color-back">
									<div class="header-main-content">
										<h1><span>Contact</span></h1>
										<p>We are Mahesh Wooden Furniture.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Page title -->
		
		<!-- Main Content -->
			<section id="contact-us">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 padding-0 custom-80">
							<div id="map1">
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15220.767958499517!2d78.45489066920565!3d17.49834627304365!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb9013012f00cf%3A0x14e359976f14a7b!2sQuthbullapur%2C+Hyderabad%2C+Telangana!5e0!3m2!1sen!2sin!4v1467786292923" width="1200" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6 padding-0">
							
							<div class="contact-us-info-1">
								<h2>Contact Info</h2>
								
								<div class="custom-border">
									<div class="custom-border-1"></div>
								</div>
								
								<p class="wow fadeInRight" data-wow-delay=".0s">
									Your satisfaction with your furniture is very important to us. If you have any questions about the furniture you have on order or the furniture in your home, we are here to help.
								</p>
								<p class="contact-add-1 custom-p wow fadeInRight" data-wow-delay=".1s"><b><span>Address:</span></b> Padma Nagar, Chintal, Bajpayee Nagar, Quthbullapur, </p>
								<p class="wow fadeInRight" data-wow-delay=".1s"> Hyderabad, Telangana 500054</p>
								<p class="wow fadeInRight" data-wow-delay=".2s"><b><span>Telephone:</span> </b><a href="tel:+001233456">  +(91)-9154288965</a></p>
								<p class="wow fadeInRight" data-wow-delay=".3s"><b><span>Email:</span></b> <a href="mailto:info@business.com">info@woodenfurniture.com</a></p>
							</div>
						</div>
						<div class="col-sm-6 padding-0">
							
							<div class="contact-form-2">
								<h2>Send us a Message</h2>
								
								<div class="custom-border">
									<div class="custom-border-1"></div>
								</div>
								
								<!-- Contact Form -->                            
								<form class="form" id="contact_form" action="#" method="post" autocomplete="off">
									<div class="clearfix">
										<div id="contact_message"></div>
										
										<div class="contact-applied-form-1">
											
											<!-- Name -->
											<div class="form-group custom-group wow fadeInDown" data-wow-delay=".0s">
												<label for="name"> <span class="content-red">*</span> Full Name</label>
												<input type="text" name="senderName" id="senderName" class="reply-info-field form-control" pattern=".{2,100}" required>
											</div>
										</div>
										<div class="contact-applied-form-1">
											<!-- Email -->
											<div class="form-group custom-group wow fadeInDown" data-wow-delay=".1s">
												<label for="email"><span class="content-red">*</span>Your Email address</label>
												<input type="email" name="senderEmail" id="senderEmail" class="reply-info-field form-control" pattern=".{5,100}" required>
											</div>
										</div>
								
										<div class="contact-applied-form-1">
											
											<!-- Message -->
											<div class="form-group wow fadeInDown" data-wow-delay=".2s">
												<label for="message">Your message:</label>
												<textarea rows="5" name="senderMessage" id="senderMessage" class="reply-info-area form-control"></textarea>
											</div>
											
										</div>
										
									</div>
									
									<!-- Send Button -->
									<button class="submit_btn btn btn-mod btn-large btn-full contact-submit-btn-2 wow fadeInDown" data-wow-delay=".3s" id="submit_btn">
										apply now
									</button>
									
								</form>
							</div>
							
							
						</div>
					</div>
				</div>
			</section>
		<!--/ End Main Content -->
		
			<?php include 'footer.php';?>