<?php include 'header.php';?>
		
		<!-- Slider Content -->
			<section id="corporate-home-slider1">
				<div class="tp-banner-container">
					<div class="tp-banner" >
						<ul>	<!-- SLIDE  -->

	
							<!-- SLIDE  -->
							<li data-transition="slidevertical" data-slotamount="1" data-masterspeed="1000" data-thumb="assets/images/s1.jpg"  data-saveperformance="off"  data-title="Slide">
								<!-- MAIN IMAGE -->
								<img src="assets/images/s1.jpg"  alt="fullslide6"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
								
								<!-- LAYER NR. 1 -->
								<div class="tp-caption white_heavy_70 skewfromleftshort fadeout tp-resizeme rs-parallaxlevel-10"
									data-x="center"
									data-y="150"
									data-speed="500"
									data-start="2400"
									data-easing="Power3.easeInOut"
									data-splitin="chars"
									data-splitout="none"
									data-elementdelay="0.1"
									data-endelementdelay="0.1"
									data-endspeed="300"
									style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;font-family:Times New Roman;">There's no Place Like Home.
								</div>
								<!-- LAYER NR. 1 -->
								
								<!-- LAYER NR. 2 -->
								<div class="tp-caption thintext_dark lfb ltt tp-resizeme"
									data-x="center" data-hoffset="0"
									data-y="225" data-voffset="0"
									data-speed="600"
									data-start="2500"
									data-easing="Power4.easeOut"
									data-splitin="none"
									data-splitout="none"
									data-elementdelay="0.01"
									data-endelementdelay="0.1"
									data-endspeed="500"
									data-endeasing="Power4.easeIn"
									style=" z-index:4; max-width: auto; max-height: auto; white-space: nowrap;;font-weight:bold;color:#F0F3F4;font-family:Times New Roman;">
									Welcome to Mahesh Wooden Furniture. We are a team of architect an<br>
									interior designers team that are focused on transferring your interior into warm and <br>
									creative home.
								</div>
								<!-- LAYER NR. 2 -->
								
								<!-- LAYER NR. 3 -->
								<div class="tp-caption small_light_white customin stt tp-resizeme"
									data-x="center" data-hoffset="0"
									data-y="325" data-voffset="0"
									data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
									data-speed="1000"
									data-start="2300"
									data-easing="Power4.easeOut"
									data-splitin="none"
									data-splitout="none"
									data-elementdelay="0.1"
									data-endelementdelay="0.1"
									data-endspeed="500"
									data-endeasing="Power4.easeInOut"
						
									style="z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;">
									<span class="cp-slider-button1">
										<a href="portfolio.php">VIEW PORTFOLIO</a> 
									</span>
								</div>
								<!-- LAYER NR. 3 -->
								
							</li>
	
							<!-- SLIDE  -->
							<li data-transition="slidevertical" data-slotamount="1" data-masterspeed="1000" data-thumb="assets/images/s2.jpg"  data-saveperformance="off"  data-title="Slide">
								<!-- MAIN IMAGE -->
								<img src="assets/images/s2.jpg"  alt="fullslide6"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
								
								<!-- LAYER NR. 1 -->
								<div class="tp-caption white_heavy_70 skewfromleftshort fadeout tp-resizeme rs-parallaxlevel-10"
									data-x="center"
									data-y="150"
									data-speed="500"
									data-start="2400"
									data-easing="Power3.easeInOut"
									data-splitin="chars"
									data-splitout="none"
									data-elementdelay="0.1"
									data-endelementdelay="0.1"
									data-endspeed="300"
									style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;font-family:Times New Roman;">Happy To Sleep.
								</div>
								<!-- LAYER NR. 1 -->
								
								<!-- LAYER NR. 2 -->
								<div class="tp-caption thintext_dark lfb ltt tp-resizeme"
									data-x="center" data-hoffset="0"
									data-y="225" data-voffset="0"
									data-speed="600"
									data-start="2500"
									data-easing="Power4.easeOut"
									data-splitin="none"
									data-splitout="none"
									data-elementdelay="0.01"
									data-endelementdelay="0.1"
									data-endspeed="500"
									data-endeasing="Power4.easeIn"
									style=" z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;font-family:Times New Roman;">
									Welcome to Mahesh Wooden Furniture. We are a team of architect an<br>
									interior designers team that are focused on transferring your interior into warm and <br>
									creative home.
								</div>
								<!-- LAYER NR. 2 -->
								
								<!-- LAYER NR. 3 -->
								<div class="tp-caption small_light_white customin stt tp-resizeme"
									data-x="center" data-hoffset="0"
									data-y="325" data-voffset="0"
									data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
									data-speed="1000"
									data-start="2300"
									data-easing="Power4.easeOut"
									data-splitin="none"
									data-splitout="none"
									data-elementdelay="0.1"
									data-endelementdelay="0.1"
									data-endspeed="500"
									data-endeasing="Power4.easeInOut"
						
									style="z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;">
									<span class="cp-slider-button1">
										<a href="corporate-portfolio.php">VIEW PORTFOLIO</a> 
									</span>
								</div>
								<!-- LAYER NR. 3 -->
								
							</li>
							<!-- SLIDE  -->
							<li data-transition="slidevertical" data-slotamount="1" data-masterspeed="1000" data-thumb="assets/images/s3.jpg"  data-saveperformance="off"  data-title="Slide">
								<!-- MAIN IMAGE -->
								<img src="assets/images/s3.jpg"  alt="fullslide6"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
								
								<!-- LAYER NR. 1 -->
								<div class="tp-caption white_heavy_70 skewfromleftshort fadeout tp-resizeme rs-parallaxlevel-10"
									data-x="center"
									data-y="150"
									data-speed="500"
									data-start="2400"
									data-easing="Power3.easeInOut"
									data-splitin="chars"
									data-splitout="none"
									data-elementdelay="0.1"
									data-endelementdelay="0.1"
									data-endspeed="300"
									style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;font-family:Times New Roman;">Sitting Room.
								</div>
								<!-- LAYER NR. 1 -->
								
								<!-- LAYER NR. 2 -->
								<div class="tp-caption thintext_dark lfb ltt tp-resizeme"
									data-x="center" data-hoffset="0"
									data-y="225" data-voffset="0"
									data-speed="600"
									data-start="2500"
									data-easing="Power4.easeOut"
									data-splitin="none"
									data-splitout="none"
									data-elementdelay="0.01"
									data-endelementdelay="0.1"
									data-endspeed="500"
									data-endeasing="Power4.easeIn"
									style=" z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;font-family:Times New Roman;">
									Welcome to Mahesh Wooden Furniture. A Cool Living Room For a Warm Welcome.... 
									
								</div>
								<!-- LAYER NR. 2 -->
								
								<!-- LAYER NR. 3 -->
								<div class="tp-caption small_light_white customin stt tp-resizeme"
									data-x="center" data-hoffset="0"
									data-y="325" data-voffset="0"
									data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
									data-speed="1000"
									data-start="2300"
									data-easing="Power4.easeOut"
									data-splitin="none"
									data-splitout="none"
									data-elementdelay="0.1"
									data-endelementdelay="0.1"
									data-endspeed="500"
									data-endeasing="Power4.easeInOut"
						
									style="z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;">
									<span class="cp-slider-button1">
										<a href="portfolio.php">VIEW PORTFOLIO</a> 
									</span>
								</div>
								<!-- LAYER NR. 3 -->
								
							</li>
						</ul>		
						<div class="tp-bannertimer"></div>	
					</div>
				</div>
			</section>
		<!--/ End Slider Content -->
		
		<!-- Corporate Home Services -->
		<section id="cp-services" class="custom-15">
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						<div class="cp-page-header">
							<h2 style="font-family:Times New Roman;">Our Services</h2>
							<p  style="font-family:Times New Roman;">How It Works.</p>
							<img src="assets/images/header-bottom.png" alt="">
						</div>
					</div>
				</div>
				<div class="row cp-service-row">
					<div class="col-sm-4">
						<div class="cp-services-main">
							<img class="img-responsive wow fadeInLeft" src="assets/images/cp-services-1.jpg" alt="">
							
							<div class="service-img-bottom media-left wow fadeInRight">
								<div class="service-number">
									<p>01</p> 
								</div>
								<div class="number-head">
									<h3  style="font-family:Times New Roman;"><a href="services.php">PLANNING</a></h3>
									<p  style="font-family:Times New Roman;">Interior Design Planning</p>
								</div>
							</div>
							
							<p class="service-text wow fadeInRight"  style="font-family:Times New Roman;">
								Before diving into design first step is planning how your
								interior will look. We work with 3D software so you can see
								how it will look in reality.
							</p>
						</div>
					</div>
					
					<div class="col-sm-4">
						<div class="cp-services-main">
							<img class="img-responsive wow fadeInLeft" src="assets/images/cp-services-2.jpg" alt="">
							
							<div class="service-img-bottom media-left wow fadeInRight">
								<div class="service-number">
									<p>02</p>
								</div>
								<div class="number-head">
									<h3  style="font-family:Times New Roman;"><a href="services.php">INTERIOR DESIGN</a></h3>
									<p  style="font-family:Times New Roman;">Interior Design Planning</p>
								</div>
							</div>
							
							<p class="service-text wow fadeInRight"  style="font-family:Times New Roman;">
								Our architects and interior designers will design your
								dream home according to your wishes. We will deliver
								nothing but hight quality solution.
							</p>
						</div>
					</div>
					
					<div class="col-sm-4">
						<div class="cp-services-main">
							<img class="img-responsive wow fadeInLeft" src="assets/images/cp-services-3.jpg" alt="">
							
							<div class="service-img-bottom media-left wow fadeInRight">
								<div class="service-number">
									<p>03</p>
								</div>
								<div class="number-head">
									<h3  style="font-family:Times New Roman;"><a href="services.php">EXTERIOR DESIGN</a></h3>
									<p  style="font-family:Times New Roman;">Interior Design Planning</p>
								</div>
							</div>
							
							<p class="service-text wow fadeInRight"  style="font-family:Times New Roman;">
								Our professional designers and architects can also design
								your home exterior to deliver full package of custom, warm
								home solution.
							</p>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Corporate Home Services -->
		
		<!-- Corporate Portfolio -->
		<section id="cp-portfolio">
			<div class="container-fluid">
				<div class="row">
					<div class="col-sm-12">
						<div class="cp-page-header">
							<h2  style="font-family:Times New Roman;">Our Portfolio</h2>
							<p  style="font-family:Times New Roman;">Latest projects we worked on</p>
							<img src="assets/images/header-bottom.png" alt="">
						</div>
					</div>
				</div>
				<div class="row custom-15">
					<div class="col-sm-12 port-padding">
						<div class="portfolio-slide">
						<!-- Portfolio Item Start -->
							<div class="item">
							<!-- First Item -->
								<div>
									<div class="cp-item">
										<ul class="cp-image cp-image-hover">
											<li>
											<figure>
													<img class="img-responsive" src="assets/images/portfolio/1.jpg" alt="team-1">
													<figcaption>
														<div class="cp-caption-title">
															<a href="#">TV ROOM</a>
														</div>
														<div class="cp-caption-desc">
															<a href="portfolio.php">View Project</a>
														</div>
												</figcaption>
												</figure>
											</li>
										</ul>
									</div>
								</div>
							<!-- Second Item -->
								<div>
									<div class="cp-item">
										<ul class="cp-image cp-image-hover">
											<li>
												<figure>
													<img class="img-responsive" src="assets/images/portfolio/2.jpg" alt="team-1">
													<figcaption>
														<div class="cp-caption-title">
															<a href="#">BED ROOM</a>
														</div>
													<div class="cp-caption-desc">
															<a href="portfolio.php">View Project</a>
														</div>
													</figcaption>
												</figure>
											</li>
										</ul>
									</div>
								</div>
							<!-- Third Item -->
								<div>
									<div class="cp-item">
										<ul class="cp-image cp-image-hover">
											<li>
												<figure>
													<img class="img-responsive" src="assets/images/portfolio/3.jpg" alt="team-1">
													<figcaption>
														<div class="cp-caption-title">
															<a href="#">LIVING ROOM</a>
														</div>
														<div class="cp-caption-desc">
															<a href="portfolio.php">View Project</a>
														</div>
													</figcaption>
												</figure>
											</li>
										</ul>
									</div>
								</div>
							<!-- Fourth Item -->
								<div>
									<div class="cp-item">
										<ul class="cp-image cp-image-hover">
											<li>
												<figure>
													<img class="img-responsive" src="assets/images/portfolio/4.jpg" alt="team-1">
													<figcaption>
														<div class="cp-caption-title">
															<a href="#">LIVING ROOM</a>
														</div>
														<div class="cp-caption-desc">
															<a href="portfolio.php">View Project</a>
														</div>
													</figcaption>
												</figure>
											</li>
										</ul>
									</div>
								</div>
							<!-- Fifth Item -->
								<div>
									<div class="cp-item">
										<ul class="cp-image cp-image-hover">
											<li>
												<figure>
													<img class="img-responsive" src="assets/images/portfolio/5.jpg" alt="team-1">
													<figcaption>
														<div class="cp-caption-title">
															<a href="#">REST ROOM</a>
														</div>
														<div class="cp-caption-desc">
															<a href="portfolio.php">View Project</a>
														</div>
													</figcaption>
												</figure>
												</li>
											</ul>
										</div>
									</div>
							<!-- Sixth Item -->
								<div>
									<div class="cp-item">
										<ul class="cp-image cp-image-hover">
											<li>
												<figure>
													<img class="img-responsive" src="assets/images/portfolio/6.jpg" alt="team-1">
													<figcaption>
														<div class="cp-caption-title">
															<a href="#">MODERN BATHROOM</a>
														</div>
														<div class="cp-caption-desc">
															<a href="portfolio.php">View Project</a>
														</div>
													</figcaption>
												</figure>
											</li>
										</ul>
									</div>
								</div>
							<!-- Seventh Item -->
								<div>
									<div class="cp-item">
										<ul class="cp-image cp-image-hover">
											<li>
												<figure>
													<img class="img-responsive" src="assets/images/portfolio/7.jpg" alt="team-1">
													<figcaption>
														<div class="cp-caption-title">
															<a href="#">MODERN BATHROOM</a>
														</div>
														<div class="cp-caption-desc">
															<a href="portfolio.php">View Project</a>
														</div>
													</figcaption>
												</figure>
											</li>
										</ul>
									</div>
								</div>
							<!-- Eighth Item -->
								<div>
									<div class="cp-item">
										<ul class="cp-image cp-image-hover">
											<li>
												<figure>
													<img class="img-responsive" src="assets/images/portfolio/8.jpg" alt="team-1">
													<figcaption>
														<div class="cp-caption-title">
															<a href="#">MEETING ROOM</a>
														</div>
														<div class="cp-caption-desc">
															<a href="portfolio.php">View Project</a>
														</div>
													</figcaption>
												</figure>
											</li>
										</ul>
									</div>
								</div>
							</div>
						<!-- Portfolio Item End -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Corporate Portfolio -->
		
		<!-- Testimonial Section Start -->
		<section id="testimonial">
			<div class="container">
				<div class="row">
					<div class="col-sm-8">
						<div class="testimonial-header-1">
							<h3  style="font-family:Times New Roman;">Why Choose us</h3>
							<!-- <p>From Company Blog</p> -->
							<img src="assets/images/header-bottom.png" alt="">
						</div>

						<!-- Choose Us Post One -->	
						<div class="choose-comments">
							<div class="choose-comment-detail">
								<div class="choose-image wow fadeInDown">
									<span><i class="fa fa-check"></i></span>
								</div>
								<div class="choose-comment">
									<h5 class="wow fadeInRight"  style="font-family:Times New Roman;">Only High Skilled Architects & Interior Designers.</h5>
									<p class="wow fadeInRight"  style="font-family:Times New Roman;">We look to the future, through a commitment to innovation and embracing evolving technology demands</p>
								</div>
							</div>
						</div>
						<!--/ End Choose Us Post One -->

						<!-- Choose Us Post Two -->	
						<div class="choose-comments">
							<div class="choose-comment-detail">
								<div class="choose-image wow fadeInDown">
									<span><i class="fa fa-check"></i></span>
								</div>
								<div class="choose-comment">
									<h5 class="wow fadeInRight"  style="font-family:Times New Roman;">Lowest Prices.</h5>
									<p class="wow fadeInRight"  style="font-family:Times New Roman;">We price our Best Selling Mahesh Wooden Furniture range to be lowest in the Market, some other retailers may have lower prices but there are still delivery charges to take into account in the small print. </p>
								</div>
							</div>
						</div>
						<!--/ End Choose Us Post Two -->

						<!-- Choose Us Post Three -->	
						<div class="choose-comments">
							<div class="choose-comment-detail">
								<div class="choose-image wow fadeInDown">
									<span><i class="fa fa-check"></i></span>
								</div>
								<div class="choose-comment">
									<h5 class="wow fadeInRight"  style="font-family:Times New Roman;">Confidential Helpline.</h5>
									<p class="wow fadeInRight"  style="font-family:Times New Roman;">Some of the products we sell can be a sensitive subject and not everyone will wish to discuss their personal needs. We understand this and are here to help. </p>
								</div>
							</div>
						</div>
						<!--/ End Choose Us Post Three -->
					</div>


					<div class="col-sm-4">
						<div class="testimonial-header-1">
							<h3  style="font-family:Times New Roman;">Testimonials</h3>
							<p  style="font-family:Times New Roman;">What Our Clients Say</p>
							<img src="assets/images/header-bottom.png" alt="">
						</div>

						<!-- testimonial Comment Post One -->	
						<div class="testimonial-comments">
							<div class="testimonial-comment-detail">
								<div class="testimonial-image wow fadeInDown">
									<img src="assets/images/testimonial-1.jpg" alt="">
									<div class="blockquote">
										<span>“</span>
									</div>
								</div>
								<div class="client-comment">
									<h5 class="wow fadeInRight">Sharada</h5>
									<p class="wow fadeInRight" style="text-align:justify; font-family:Times New Roman;">Loved the leather sofas made by Stitchwood. It is just like how we wanted it. We just sent Stitchwood the images of sofa designs, and a video of my living room. They helped me visualise how the would look in my living room.sofa  Finally the sofa has come out perfectly as we wanted. 								 </p>
								</div>
								<!-- <a href="#" class="testimonial-comment-date wow fadeInLeft"> View Project</a> -->
								
							</div>
						</div>
						<!--/ End testimonial Comment Post One -->

						<!-- testimonial Comment Post Two -->	
						<div class="testimonial-comments">
							<div class="testimonial-comment-detail">
								<div class="testimonial-image wow fadeInDown">
									<img src="assets/images/testimonial-2.jpg" alt="">
									<div class="blockquote">
										<span>“</span>
									</div>
								</div>
								<div class="client-comment">
									<h5 class="wow fadeInRight"  style="font-family:Times New Roman;">Harika</h5>
									<p class="wow fadeInRight"  style="font-family:Times New Roman;">The Diwans look really good. The build quality is excellent. I am really pleased with this. </p>
								</div>
								<!-- <a href="#" class="testimonial-comment-date wow fadeInLeft"> View Project</a> -->
								
							</div>
						</div>
						<!--/ End testimonial Comment Post Two -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Testimonial Section -->

		<!-- CP Subscribe Section -->
			<section id="cp-subscribe">
				<div class="container-fluid">
					<div class="row-fluid cp-subscribe-wrap">
						<div class="col-sm-6 subscribe-blog-part padding">

							<!-- Subscribe Left Content -->
							<div class="cp-subscribe-left">
								<div class="subscribe-slide">
								<!-- Slide Item One -->
									<div>
										<div class="subscribe-slide-item">
											<div class="col-sm-2 padding">
												<div class="Subscribe-left-date">
													<!-- <div class="Date-left-content">
														<h2>03</h2>
														<p>DEC</p>
													</div> -->
												</div>
											</div>

											<div class="col-sm-10">
												<div class="subscribe-left-content">
													<h1  style="font-family:Times New Roman;">Modern Living Room Concept Design</h1>
													<h6><i class="fa fa-tags"></i>Planning, Design</h6>
													<p  style="font-family:Times New Roman;text-align:justify;">Depending on the layout of your home, a modern living room can serve many different functions. If you have a separate family room, your living room is often a formal sitting area or parlor used for reading, relaxing and entertaining guests. If it's the only living space you have, it's probably also used for watching TV, playing games and spending time with family. As you start your minimalist living room remodel, think about the space's desired purpose — is it going to have a more formal feel or will you aim for a more low-key setting? Regardless of its intent, any good space should have a few staple items, such as a comfortable sofa, a coffee table of some sort, and a focal point, like a fireplace or entertainment center. Read on for more layout and decorating tips to get to most out of your new space:</p>
													<!-- <a href="#">READ ARTICLE</a> -->
												</div>
											</div>
										</div>
									</div>
								<!--/ End Slide Item One -->

								<!-- Slide Item Two -->
									<div>
										<div class="subscribe-slide-item">
											<div class="col-sm-2 padding">
												<div class="Subscribe-left-date">
													<!-- <div class="Date-left-content">
														<h2>03</h2>
														<p>DEC</p>
													</div> -->
												</div>
											</div>

											<div class="col-sm-10">
												<div class="subscribe-left-content">
													<h1  style="font-family:Times New Roman;">Modern Bed Room Concept Design</h1>
													<h6><i class="fa fa-tags"></i>Planning, Design</h6>
													<p  style="font-family:Times New Roman;text-align:justify;">At the end of a long hard day there is nothing better than lying down on fresh bedding and crisp sheets, but how many of us have a conducive interior style in the bedroom? It’s hard to design a bedroom that is stylish yet functional and calming without making it look like a soulless showhome. We all know the importance of a good night’s sleep but do we realise how much the interior can impact this? The LuxPad spoke to designer bloggers and interior experts to get their top tips and advice on bedroom styles that will look great and provide you with the relaxing haven that you need. </p>
													<!-- <a href="#">READ ARTICLE</a> -->
												</div>
											</div>
										</div>
									</div>
								<!--/ End Slide Item Two -->

								<!-- Slide Item Three -->
									<div>
										<div class="subscribe-slide-item">
											<div class="col-sm-2 padding">
												<div class="Subscribe-left-date">
													<!-- <div class="Date-left-content">
														<h2>03</h2>
														<p>DEC</p>
													</div> -->
												</div>
											</div>

											<div class="col-sm-10">
												<div class="subscribe-left-content">
													<h1  style="font-family:Times New Roman;">Modern Dining Room Concept Design</h1>
													<h6><i class="fa fa-tags"></i>Planning, Design</h6>
													<p  style="font-family:Times New Roman;text-align:justify;">The opposite of bustling, multifunctional rooms like the kitchen, the contemporary dining room is a simple space devoted solely to hosting and feasting. While it’s a room that may be used infrequently, it is ideal for large get-togethers, family dinners and celebrations. When perusing dining room ideas, consider what kind of furniture and decorative accents will transform the space into an entertaining mecca. </p>
													<!-- <a href="#">READ ARTICLE</a> -->
												</div>
											</div>
										</div>
									</div>
								<!--/ End Slide Item Three -->
								</div>
							</div>
							<!--/ End Subscribe Left Content -->
						</div>

						<div class="col-sm-6 subscribe-form-part padding">
							<div class="subscribe-mail-back">
								<div class="subscribe-mail">
									<span><i class="fa fa-envelope-o"></i></span>
									<h2 class="wow fadeInLeft">subscribe to our mailing list</h2>
									<form class="form-inline wow fadeInRight">
										<div class="form-group">
										    <label class="sr-only" for="exampleInputEmail3">Email address</label>
										    <input type="email" class="form-control subscribe-form" id="exampleInputEmail3" placeholder="Enter Your Email...">
										</div>
									
									  	<button type="submit" class="btn btn-default subscribe-mail-btn"><i class="fa fa-envelope-o"></i></button>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End CP Subscribe Section -->

		<!-- Partners Section -->
			<section id="partner-slide">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<div class="cp-page-header">
								<h2>Partners</h2>
								<p>Materials & Furniture Supplier Partners</p>
								<img src="assets/images/header-bottom.png" alt="">
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-sm-12">
							<div class="partner-logo">
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-1.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-2.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-3.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-4.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-1.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-2.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-3.png" alt=""></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Partners Section -->
		
		
<?php include 'footer.php';?>
		<!-- ============ Js Files ============ -->

	    <!-- Placed at the end of the document so the pages load faster -->
		
		<!-- main js -->
			<script src="assets/js/jquery-1.11.2.min.js"></script>
				
			<script src="assets/js/bootstrap.min.js"></script>	
			<script src="assets/js/jquery.sticky.js"></script>	
			
			<script src="assets/js/slider/jquery.themepunch.tools.min.js"></script>	
			<script src="assets/js/slider/jquery.themepunch.revolution.min.js"></script>	
			<script src="assets/js/slider/corporate-slider.js"></script>	
			
			<script src="assets/js/jquery.cubeportfolio.min.js"></script>	
			<script src="assets/js/portfolio-custom.js"></script>	
			<script src="assets/js/slick.min.js"></script>
			<script src="assets/js/modernizr.custom.js"></script>
			<script src="assets/js/jquery.magnific-popup.min.js"></script>
			<script src="assets/js/jquery.touchSwipe.min.js"></script>
			<script src="assets/js/jquery.liquid-slider.js"></script>
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script> 
			<script src="assets/js/gmap3.min.js"></script>
			<script src="assets/js/ionrangeslider.js"></script>
			<script src="assets/js/classie.js"></script>
			<script src="assets/js/wow.min.js"></script>
			
		       
		<!-- Custom Script -->		
			<script src="assets/js/main.js"></script>
		<!-- Theme Panel Style Switcher -->
			<script src="assets/js/theme_panel.js"></script>		
		
	</body>

<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-home-2.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:45:20 GMT -->
</html>
