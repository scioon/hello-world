	jQuery(document).ready(function() {
				jQuery('.tp-banner').show().revolution(
					{
						delay:9000,
							startwidth:1170,
							startheight:500,
							hideThumbs:10,
							fullWidth:"on",
							forceFullWidth:"on",
							navigationStyle:"preview4"
					});
					
					
					
									
				});	//ready