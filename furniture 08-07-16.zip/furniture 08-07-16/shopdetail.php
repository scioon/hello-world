<?php include 'header.php';?>
		
		<!-- Page title -->
			<section class="page-title-wrap">
				<div class="page-title-img shop-pagetitle-bg">
					<div class="container">
						<div class="row">
							<div class="cp-page-title-wrap">
								<div class="header-color-back">
									<div class="header-main-content">
										<h1><span>Modern Sofa</span></h1>
										<p>We are Mahesh Wooden Furniture</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Page title -->
		
		<!-- Main Content -->
			<section id="shop-item-1">
				<div class="container">
					<div class="row">
						<div class="col-sm-6">
							<div class="single-item-show">
								<div id="surround">
    
									<img class="cloudzoom" alt ="Cloud Zoom small image" id ="zoom1" src="assets/images/shop/products/large/image1.jpg"
									   data-cloudzoom="useZoom:'.cloudzoom', image:'assets/images/shop/products/large/image1.jpg', zoomPosition:'inside' ">
								 
								 
									<div id="slider1">
										
										<ul>
											<li>
												<img class="cloudzoom-gallery" src="assets/images/shop/products/image1.jpg" alt=""
													data-cloudzoom="useZoom:'.cloudzoom', image:'assets/images/shop/products/large/image1.jpg', zoomPosition:'inside' ">
											</li>

											<li>
												<img class='cloudzoom-gallery' src="assets/images/shop/products/image2.jpg" alt=""
													data-cloudzoom ="useZoom:'.cloudzoom', image:'assets/images/shop/products/large/image2.jpg', zoomPosition:'inside' ">
											</li>

											<li>
												<img class='cloudzoom-gallery' src="assets/images/shop/products/image3.jpg" alt=""
													data-cloudzoom ="useZoom:'.cloudzoom', image:'assets/images/shop/products/large/image3.jpg', zoomPosition:'inside' ">
											</li>

											<li>
												<img class='cloudzoom-gallery' src="assets/images/shop/products/image4.jpg" alt=""
													data-cloudzoom ="useZoom:'.cloudzoom', image:'assets/images/shop/products/large/image4.jpg', zoomPosition:'inside' ">
											</li>

											<li>
												<img class='cloudzoom-gallery' src="assets/images/shop/products/image5.jpg" alt=""
													data-cloudzoom ="useZoom:'.cloudzoom', image:'assets/images/shop/products/large/image5.jpg', zoomPosition:'inside' ">
											</li>

											<li>
												<img class='cloudzoom-gallery' src="assets/images/shop/products/image6.jpg" alt=""
													data-cloudzoom ="useZoom:'.cloudzoom', image:'assets/images/shop/products/large/image6.jpg', zoomPosition:'inside' ">
											</li>
										</ul>
									</div>
									
								</div>
								 

							</div>
						</div>
						<div class="col-sm-6">
							<div class="shop-item-details">
								<div class="page-header-1">
									<h1>MODERN SOFA</h1>
									
									<div class="custom-border">
										<div class="custom-border-1"></div>
									</div>
								</div>
								
								<div class="detail-content">
									<div class="rating">
										<ul>
											<li class="rating-price wow fadeInRight" data-wow-delay=".0s"><del>44,4487 RS</del> <span>22,250 RS</span></li>
											<li class="wow fadeInRight" data-wow-delay=".1s"><a><img src="assets/images/shop/star.png" alt=""><span>1 rating</span></a></li>
										</ul>
									</div>
									<div class="item-description">
										<ul>
											<li class="wow fadeInRight" data-wow-delay=".2s">
												<i class="fa fa-circle-thin"></i>
												<span>Material:</span>
												Soft Fabric 20%, Leather 80%
											</li>
											<li class="wow fadeInRight" data-wow-delay=".3s">
												<i class="fa fa-circle-thin"></i>
												<span>Style:</span>
												Modern
											</li>
											<li class="wow fadeInRight" data-wow-delay=".4s">
												<i class="fa fa-circle-thin"></i>
												<span>Brand:</span>
												XXL Sofas
											</li>
											<li class="wow fadeInRight" data-wow-delay=".5s">
												<i class="fa fa-circle-thin"></i>
												<span>Dimensions:</span>
												185cm x 90cm x 70cm
											</li>
										</ul>
									</div>
									
									<p class="bot wow fadeInRight" data-wow-delay=".6s" style="font-family:Times New Roman;">
										Casually modern couches for warm, welcoming spaces. With cozy modern sofas that are high-quality and feature clean lines, plush pillows and sturdy construction, it's easy to create a space that's as stylish as it is comfortable.
									</p>
									<!-- <p class="bot-1 wow fadeInRight" data-wow-delay=".7s">
										pharetra aliquam ante sed aliquet. Aenean bibendum sem et purus cursus pharetra. Morbi turpis quam, adipiscing in posuere
										quis, bibendum sit amet elit. Sed convallis fringilla porta. In aliquet, tortor non laoreet aliquam, magna elit.
									</p> -->
									
									<div class="Choose-item">
										<ul class="wow fadeInDown">
											<li>
												<div class="cart-item-quantity">
													<!-- <button class="cart-item-minus minus-custom"><i class="fa fa-minus"></i></button>
														<input type="text" name="cart-quantity" class="cart-quantity minus-custom" value="1" />
													<button class="cart-item-plus minus-custom"><i class="fa fa-plus"></i></button> -->
												</div>
											</li>
											<li>
												<!-- Shop Top Dropdown -->
													<div class="shop-top-dropdown">
														<div class="shop-top-dropdown">
															<!-- <div class="">
																<select>
																	<option>Default Sorting</option>
																	<option>Newest Item</option>
																	<option>Date</option>
																	<option>Price</option>
																	<option>Newest Item</option>
																</select>
															</div> -->
														</div>
													</div>
												<!--/ End Shop Top Dropdown -->	
											</li>
										</ul>
									</div>
									
									<div class="cart-button wow fadeInUp">
										<!-- <a href="#">Add to cart</a> -->
									</div>
									
									<div class="item-description margin-20">
										<ul>
											<li class="wow fadeInRight" data-wow-delay=".1s">
												<span>Categories:</span>
												Living Room, Sofas
											</li>
											<li class="wow fadeInRight" data-wow-delay=".2s">
												<span>Tags:</span>
												sofa, blue, red, orange, living room
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Main Content -->
		
		<!-- Related Product Section -->
			<section id="related-item-1" class="grey related-product">
				<div class="container-fluid">
						<div class="row">
							<div class="col-sm-12">
								<div class="cp-page-header">
									<h2>Related Products</h2>
									<p>Shop similar products</p>
									<img src="assets/images/header-bottom.png" alt="">
								</div>
							</div>
						</div>
					<!-- Shop Item First Row -->	
						<div class="row custom-15">
						
							<!-- Shop Item One -->
								<div class="col-md-2 col-sm-4 col-xs-6">
									<div class="thumbnail">
										<div class="shop-item-figure">
											<img class="img-bottom-border" src="assets/images/shop/shop-item-5.jpg" alt="">
											<div class="shop-item-figcaption">
												<div class="star-image">
													<ul>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
													</ul>
												</div>
												<div class="shop-item-link">
													<!-- <ul>
														<li><a class="link-one" href="#">Add to wishlist</a></li>
														<li><a class="link-two" href="#">View Details</a></li>
													</ul> -->
												</div>
											</div>
											
											<div class="item-sale">
												<P>Sale!</P>
											</div>
										</div>
										<div class="caption">
											<h4>BEDROOM</h4>
											<h2>COUCH - BED</h2>
											<p><span><del>3487 RS</del></span>3250 RS</p>
											<!-- <p class="related-add-cart"><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p> -->
										</div>
									</div>
								</div>
							<!--/ End Shop Item One -->
							
							<!-- Shop Item Two -->
								<div class="col-md-2 col-sm-4 col-xs-6">
									<div class="thumbnail">
										<div class="shop-item-figure">
											<img class="img-bottom-border" src="assets/images/shop/shop-item-7.jpg" alt="">
											<div class="shop-item-figcaption">
												<div class="star-image">
													<ul>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
													</ul>
												</div>
												<div class="shop-item-link">
													<!-- <ul>
														<li><a class="link-one" href="#">Add to wishlist</a></li>
														<li><a class="link-two" href="#">View Details</a></li>
													</ul> -->
												</div>
											</div>
											
										</div>
										<div class="caption">
											<h4>LIVING ROOM</h4>
											<h2>MODERN SOFA</h2>
											<h5>2853 RS</h5>
											<!-- <p class="related-add-cart"><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p> -->
										</div>
									</div>
								</div>
							<!--/ End Shop Item Two -->
							
							<!-- Shop Item Three -->
								<div class="col-md-2 col-sm-4 col-xs-6">
									<div class="thumbnail">
										<div class="shop-item-figure">
											<img class="img-bottom-border" src="assets/images/shop/shop-item-4.jpg" alt="">
											<div class="shop-item-figcaption">
												<div class="star-image">
													<ul>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
													</ul>
												</div>
												<div class="shop-item-link">
													<ul>
														<!-- <li><a class="link-one" href="#">Add to wishlist</a></li>
														<li><a class="link-two" href="#">View Details</a></li> -->
													</ul>
												</div>
											</div>
											
										</div>
										<div class="caption">
											<h4>LIVING ROOM</h4>
											<h2>BLACK LATHER COUCH</h2>
											<h5>1479 RS</h5>
											<!-- <p class="related-add-cart"><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p> -->
										</div>
									</div>
								</div>
							<!--/ End Shop Item Three -->
							
							<!-- Shop Item Four -->
								
								<div class="col-md-2 col-sm-4 col-xs-6">
									<div class="thumbnail">
										<div class="shop-item-figure">
											<img class="img-bottom-border" src="assets/images/shop/shop-item-3.jpg" alt="">
											<div class="shop-item-figcaption">
												<div class="star-image">
													<ul>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
													</ul>
												</div>
												<div class="shop-item-link">
													<ul>
														<!-- <li><a class="link-one" href="#">Add to wishlist</a></li>
														<li><a class="link-two" href="#">View Details</a></li> -->
													</ul>
												</div>
											</div>
											
										</div>
										<div class="caption">
											<h4>LIVING ROOM</h4>
											<h2>RED COUCH</h2>
											<h5>853 RS</h5>
											<!-- <p class="related-add-cart"><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p> -->
										</div>
									</div>
								</div>
							<!--/ End Shop Item Four -->

							<!-- Shop Item Five -->
								<div class="col-md-2 col-sm-4 col-xs-6">
									<div class="thumbnail">
										<div class="shop-item-figure">
											<img class="img-bottom-border" src="assets/images/shop/shop-item-1.jpg" alt="">
											<div class="shop-item-figcaption">
												<div class="star-image">
													<ul>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
													</ul>
												</div>
												<div class="shop-item-link">
													<ul>
														<!-- <li><a class="link-one" href="#">Add to wishlist</a></li>
														<li><a class="link-two" href="#">View Details</a></li> -->
													</ul>
												</div>
											</div>
											
											<div class="item-sale">
												<P>Sale!</P>
											</div>
										</div>
										<div class="caption">
											<h4>LIVING ROOM</h4>
											<h2>Modern Sofa</h2>
											<p><span><del>2487 RS</del></span> 1250 RS</p>
											<!-- <p class="related-add-cart"><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p> -->
										</div>
									</div>
								</div>
							<!--/ End Shop Item Five -->
							
							<!-- Shop Item Six -->
								<div class="col-md-2 col-sm-4 col-xs-6">
									<div class="thumbnail">
										<div class="shop-item-figure">
											<img class="img-bottom-border" src="assets/images/shop/shop-item-2.jpg" alt="">
											<div class="shop-item-figcaption">
												<div class="star-image">
													<ul>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
														<li><i class="fa fa-star-half-empty"></i></li>
													</ul>
												</div>
												<div class="shop-item-link">
													<ul>
														<!-- <li><a class="link-one" href="#">Add to wishlist</a></li>
														<li><a class="link-two" href="#">View Details</a></li> -->
													</ul>
												</div>
											</div>
											
										</div>
										<div class="caption">
											<h4>BEDROOM</h4>
											<h2>NIGHT LAMP</h2>
											<h5>89 RS</h5>
											<!-- <p class="related-add-cart"><a href="#" class="btn btn-default" role="button">ADD TO CART</a></p> -->
										</div>
									</div>
								</div>
							<!--/ End Shop Item Six -->
						</div>
					<!--/ End Shop Item First Row -->	
				</div>
			</section>
		<!--/ End Related Product Section -->
		
<?php include 'footer.php';?>
		
		
    	<!-- Theme Panel Switcher End -->	
		

		<!-- ============ Js Files ============ -->

	    <!-- Placed at the end of the document so the pages load faster -->
		
		<!-- main js -->
			<script src="assets/js/jquery-1.11.2.min.js"></script>
				
			<script src="assets/js/bootstrap.min.js"></script>	
			<script src="assets/js/jquery.sticky.js"></script>	
			
			<script src="assets/js/jquery.cubeportfolio.min.js"></script>	
			<script src="assets/js/portfolio-custom.js"></script>	
			<script src="assets/js/slick.min.js"></script>
			<script src="assets/js/modernizr.custom.js"></script>
			<script src="assets/js/jquery.magnific-popup.min.js"></script>
			<script src="assets/js/jquery.touchSwipe.min.js"></script>
			<script src="assets/js/jquery.liquid-slider.js"></script>
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script> 
			<script src="assets/js/gmap3.min.js"></script>	
			<script src="assets/js/ionrangeslider.js"></script>
			<script src="assets/js/classie.js"></script>
			<script src="assets/js/cloud-zoom.js"></script>
			<script src="assets/js/thumbelina.js"></script>
			<script src="assets/js/wow.min.js"></script>
		       
		<!-- Custom Script -->		
			<script src="assets/js/main.js"></script>
		<!-- Theme Panel Style Switcher -->
			<script src="assets/js/theme_panel.js"></script>		
		<!-- Item Image Zoom Custom -->			
			<script type = "text/javascript">
				CloudZoom.quickStart();
				
				// Initialize the slider.
				jQuery(function($){
					$('#slider1').Thumbelina({
						$bwdBut:$('#slider1 .left'), 
						$fwdBut:$('#slider1 .right')
					});
				});
             </script>
		
	</body>

<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-shop-detail.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:46:40 GMT -->
</html>
