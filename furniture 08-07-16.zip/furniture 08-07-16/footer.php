<!-- Footer Top Start -->
				<!-- Footer Top Start -->
			<section id="corporate-footer-top">
				<div class="container">
					<div class="row">
						<div class="col-sm-4">
						<div class="footer-top-back">
							<div class="cp-footer-top-left">
								<a class="wow fadeInDown" data-wow-delay=".0s" href="corporate-home.html"><img src="assets/images/logo-white.png" alt=""></a>
								
								
								<p class="wow fadeInDown" data-wow-delay=".1s"><strong><a href="tel:+4105778763452">+(91)- 9154288965</a></strong></p>
								<p class="wow fadeInDown" data-wow-delay=".2s"><a href="mailto:info@ricochet.com">info@woodenfurniture.com</a></p>
								<p class="wow fadeInDown" data-wow-delay=".3s">Padma Nagar, Chintal, Bajpayee Nagar, Quthbullapur, Hyderabad, Telangana 500054.</p>
							</div>
						</div>	
						</div>
						<div class="col-sm-4">
							<div class="cp-footer-top-middle">
								<div class="cp-footer-head">
									<h3>Quick Links</h3>
								</div>
								
								<div class="middle-left-cp">
									<ul>
										<li class="wow fadeInRight" data-wow-delay=".0s"><a href="about.php"><i class="fa fa-angle-right"></i>About Us</a></li>
										<li class="wow fadeInRight" data-wow-delay=".1s"><a href="services.php"><i class="fa fa-angle-right"></i>Our Services</a></li>
										<li class="wow fadeInRight" data-wow-delay=".2s"><a href="shopdetail.php"><i class="fa fa-angle-right"></i>Shop</a></li>
										<li class="wow fadeInRight" data-wow-delay=".3s"><a href="portfolo.php"><i class="fa fa-angle-right"></i>Portfolio</a></li>
										<li class="wow fadeInRight" data-wow-delay=".4s"><a href="conact.php"><i class="fa fa-angle-right"></i>Contact</a></li>
									</ul>
								</div>

								<div class="middle-right-cp">
									<ul>
								
										<!-- <li class="wow fadeInRight" data-wow-delay=".0s"><a href="#"><i class="fa fa-angle-right"></i>Buyer Support</a></li>
										<li class="wow fadeInRight" data-wow-delay=".1s"><a href="#"><i class="fa fa-angle-right"></i>Legal Information</a></li>
										<li class="wow fadeInRight" data-wow-delay=".2s"><a href="#"><i class="fa fa-angle-right"></i>Privacy Policy</a></li>
										<li class="wow fadeInRight" data-wow-delay=".3s"><a href="#"><i class="fa fa-angle-right"></i>Payment Options</a></li>
										<li class="wow fadeInRight" data-wow-delay=".4s"><a href="#"><i class="fa fa-angle-right"></i>Partners & Suppliers</a></li> -->
									</ul>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="cp-footer-top-right">
								<div class="cp-footer-head">
									<h3>SOCIAL</h3>
								</div>
								<div class="cp-footer-social">
									<ul>
										<li class="wow fadeInDown" data-wow-delay=".0s"><a href="https://www.facebook.com/mahesh.wooden"><i class="fa fa-facebook"></i></a></li>
										<!-- <li class="wow fadeInDown" data-wow-delay=".1s"><a href="#"><i class="fa fa-dribbble"></i></a></li> -->
										<li class="wow fadeInDown" data-wow-delay=".2s"><a href="https://twitter.com/woodenfurnitur3"><i class="fa fa-twitter"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".2s"><a href="https://plus.google.com/collections?hl=en"><i class="fa fa-google-plus"></i></a></li>
										<!-- <li class="wow fadeInDown" data-wow-delay=".3s"><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li class="wow fadeInDown" data-wow-delay=".4s"><a href="#"><i class="fa fa-skype"></i></a></li> -->
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Footer Top -->

		
		<!-- Footer Start -->
			<section id="corporate-footer">
				<div class="container">
					<div class="row">
						<div class="col-sm-6 corporate-footer-left">
							<p>copy &copy 2016 Mahesh Wooden Furniture All Rights Reserved.</p>
						</div>
						
						<div class="col-sm-6 corporate-footer-right">
							Website Design by <a href="http://www.aniinfosoft.com"><b>Aniinfosoft Inc.</b>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Footer -->
		
		<!-- Theme Panel Switcher Start -->
	        <section id="theme-panel" class="panel-close">
	            <!-- <a class="panel-btn"><i class="fa fa-spinner icon-spin"></i></a> -->
	            <!-- <div class="theme-panel-title">
	                <h4>Style Switcher</h4>
	            </div>
	            <div class="colors-container">
	                <p class="amount-1" style="line-height:0;">10 Color Skins</p>
					<a title="beige" class="color-switch beige"></a>
	                <a title="red" class="color-switch red"></a>
					<a title="blue-2" class="color-switch blue-2"></a>
	                <a title="pink" class="color-switch pink"></a>
	                <a title="blue" class="color-switch blue"></a>
	                <a title="purple" class="color-switch purple"></a>
	                <a title="green" class="color-switch green"></a>
	                <a title="yellow" class="color-switch yellow"></a>
	                <a title="orange" class="color-switch orange"></a>
					<a title="midnight" class="color-switch midnight"></a>
	            </div> -->
	            <div class="colors-container">
	            	<p class="about-colors">
					There are unlimited posibilities to make your own color style. We have included 10 color css in this template. Thanks for using our themplate.
					</p>
				</div>
	        </section>
    	<!-- Theme Panel Switcher End -->	
		

		<!-- ============ Js Files ============ -->

	    <!-- Placed at the end of the document so the pages load faster -->
		
		<!-- main js -->
			<script src="assets/js/jquery-1.11.2.min.js"></script>
				
			<script src="assets/js/bootstrap.min.js"></script>	
			<script src="assets/js/jquery.sticky.js"></script>	
			
			<script src="assets/js/jquery.cubeportfolio.min.js"></script>	
			<script src="assets/js/portfolio-custom.js"></script>	
			<script src="assets/js/slick.min.js"></script>
			<script src="assets/js/modernizr.custom.js"></script>
			<script src="assets/js/jquery.magnific-popup.min.js"></script>
			<script src="assets/js/jquery.touchSwipe.min.js"></script>
			<script src="assets/js/jquery.liquid-slider.js"></script>
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script> 
			<script src="assets/js/gmap3.min.js"></script>
			<script src="assets/js/ionrangeslider.js"></script>
			<script src="assets/js/classie.js"></script>
			<script src="assets/js/wow.min.js"></script>
			
		       
		<!-- Custom Script -->		
			<script src="assets/js/main.js"></script>
		<!-- Theme Panel Style Switcher -->
			<script src="assets/js/theme_panel.js"></script>		
		
	</body>

<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-portfolio.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:45:40 GMT -->
</html>
