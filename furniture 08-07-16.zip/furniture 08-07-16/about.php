<?php include 'header.php';?>
		
		<!-- Page title -->
			<section class="page-title-wrap">
				<div class="page-title-img default-pagetitle-bg">
					<div class="container">
						<div class="row">
							<div class="cp-page-title-wrap">
								<div class="header-color-back">
									<div class="header-main-content">
										<h1  style="font-family:Times New Roman;"><span>About us</span></h1>
										<p  style="font-family:Times New Roman;">We are Mahesh Wooden Company. </p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Page title -->
		
		<!-- Main Content -->
			<section id="our-services">
				<div class="container">
					<div class="row service-row">
						<div class="col-sm-8">
							<div class="service-header">
								<h2>About us</h2>
								
								<div class="custom-border">
									<div class="custom-border-1"></div>
								</div>
								
								<p  style="font-family:Times New Roman;text-align:justify;">
									With over a decade of expertise in making furniture, Mahesh Wood Furniture has helped numerous customers in making their homes more aesthetic and beautiful. Our designs are not just desirable but have an international flavour. The furniture pieces are beautiful to behold with unique colours & design combinations, and utility driven shapes to fit within traditional & modern houses. Our products are known for undisputed durability and quality. And it gets better, they come at extremely delightful prices.




								</p>
								
								<p  style="font-family:Times New Roman;text-align:justify;">
									We take complete responsibility of the products we deliver to you. Thus we give 1-year warranty on our products. So shop without any doubt. Feel free to visit our nearest store for a closer look.
								</p>
								
								<p  style="font-family:Times New Roman;text-align:justify;">
									Before you shop for home furniture designs, the first step is to picture the fully furnished rooms in your mind. What do you want each space to be used for? Will it be a private space, for family, or for entertaining? Secondly, consider the layout of each space, including the position of doors and windows, to understand how many and how big your furniture pieces can be, while still leaving enough room for people to walk around unobstructed.
								</p>
							</div>
							 
							
						</div>
						
						<div class="col-sm-4">
							<div class="service-right-image">
								<img src="assets/images/cp-about-1.jpg" alt="">
								<img src="assets/images/cp-about-2.jpg" alt="">
							</div>
						</div>
						
					</div>
				</div>
			</section>
		<!--/ End Main Content -->
		
		<!-- Corporate Team Section -->
			<section id="cp-team">
				<div class="container">
					<div class="row cp-team-row">
						<div class="col-sm-3">
							<div class="cp-team-header">
								<h2>our team</h2>
								
								<div class="custom-border">
									<div class="custom-border-1"></div>
								</div>
							</div>
							<div class="tab-vertical">
								<ul class="nav nav-tabs">
									<li class="active wow fadeInUp" data-wow-delay=".0s"><a class="tab-back-red" href="#directors" data-toggle="tab">Directors</a></li>
									<li class="wow fadeInUp" data-wow-delay=".3s"><a class="tab-back-red" href="#partners" data-toggle="tab">Partners</a></li>
									<li class="wow fadeInUp" data-wow-delay=".5s"><a class="tab-back-red" href="#staff" data-toggle="tab">Staff</a></li>
								</ul>
							</div>
						</div>
						<div class="col-sm-9">
							<div class="tab-vertical">
								
								<!-- Tab panes -->
								<div class="tab-content">
									<!-- First Tab -->
										<div class="tab-pane fade in active" id="directors">
										<!-- Team Members -->
											<div class="row">
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-1.jpg" alt="">
														<div class="member-detail-content">
															<h2>Maria Peterson</h2>
															<p>Interior Design Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-1">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-2.jpg" alt="">
														<div class="member-detail-content">
															<h2>Mark Twist</h2>
															<p>Interior Design Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-2">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-3.jpg" alt="">
														<div class="member-detail-content">
															<h2>Alicia Stark</h2>
															<p>ARCHITECTURE Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-3">view profile</a>
														</div>
													</div>
												</div>
											</div>
											
											<div class="row team-tab-content">
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-4.jpg" alt="">
														<div class="member-detail-content">
															<h2>Oliver Mathews</h2>
															<p>Interior PLANNING Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-4">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-5.jpg" alt="">
														<div class="member-detail-content">
															<h2>Carla Mayer</h2>
															<p>HR DIRECTOR</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-5">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-6.jpg" alt="">
														<div class="member-detail-content">
															<h2>Jonathan Brew</h2>
															<p>EXTERIOR DESIGN DIRECTOR</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-6">view profile</a>
														</div>
													</div>
												</div>
											</div>
										<!--/ End Team Members -->
										</div>
									<!--/ End First Tab -->
									
									<!-- Second Tab -->
										<div class="tab-pane fade custom-tab" id="partners">
											<!-- Team Members -->

											<div class="row">
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-4.jpg" alt="">
														<div class="member-detail-content">
															<h2>Oliver Mathews</h2>
															<p>Interior PLANNING Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-4">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-5.jpg" alt="">
														<div class="member-detail-content">
															<h2>Carla Mayer</h2>
															<p>HR DIRECTOR</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-5">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-6.jpg" alt="">
														<div class="member-detail-content">
															<h2>Jonathan Brew</h2>
															<p>EXTERIOR DESIGN DIRECTOR</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-6">view profile</a>
														</div>
													</div>
												</div>
											</div>
											<div class="row team-tab-content">
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-1.jpg" alt="">
														<div class="member-detail-content">
															<h2>Maria Peterson</h2>
															<p>Interior Design Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-1">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-2.jpg" alt="">
														<div class="member-detail-content">
															<h2>Mark Twist</h2>
															<p>Interior Design Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-2">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-3.jpg" alt="">
														<div class="member-detail-content">
															<h2>Alicia Stark</h2>
															<p>ARCHITECTURE Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-3">view profile</a>
														</div>
													</div>
												</div>
											</div>
											
											
										<!--/ End Team Members -->
										</div>
									<!--/ End Second Tab -->
									
									<!-- Third Tab -->
										<div class="tab-pane fade custom-tab" id="staff">
											<!-- Team Members -->
											<div class="row">
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-1.jpg" alt="">
														<div class="member-detail-content">
															<h2>Maria Peterson</h2>
															<p>Interior Design Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-1">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-2.jpg" alt="">
														<div class="member-detail-content">
															<h2>Mark Twist</h2>
															<p>Interior Design Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-2">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-3.jpg" alt="">
														<div class="member-detail-content">
															<h2>Alicia Stark</h2>
															<p>ARCHITECTURE Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-3">view profile</a>
														</div>
													</div>
												</div>
											</div>
											
											<div class="row team-tab-content">
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-4.jpg" alt="">
														<div class="member-detail-content">
															<h2>Oliver Mathews</h2>
															<p>Interior PLANNING Director</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-4">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-5.jpg" alt="">
														<div class="member-detail-content">
															<h2>Carla Mayer</h2>
															<p>HR DIRECTOR</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-5">view profile</a>
														</div>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="member-content-1">
														<img class="img-responsive" src="assets/images/cp-team-6.jpg" alt="">
														<div class="member-detail-content">
															<h2>Jonathan Brew</h2>
															<p>EXTERIOR DESIGN DIRECTOR</p>
															<a class="popup-with-zoom-anim" href="#small-dialog-6">view profile</a>
														</div>
													</div>
												</div>
											</div>
										<!--/ End Team Members -->
										</div>
									<!-- End Third Tab -->

								</div>

								<!-- member Description 1 -->
									<!-- <div id="small-dialog-1" class="zoom-anim-dialog mfp-hide">
										<h1>Maria Peterson</h1>
										<h3>Interior Design Director</h3>
										<p>
										Welcome to <span>Ricochet</span>, amazing interior design template. It's 
										time to stand out from the crowd and offer your clients
										unique and amazing experience. Ricochet comes in two
										versions: clean corporate site and modern, unique layout
										which you are seeing right now. Choose the one you like
										more, you won't be disapointed,.
										</p>
										<p>
										This is example of a about page. When you click on that little dot a lightbox shows up.
										You can arrange dots to be anywhere on your photo. Also there's another about us pageoption, 
										which is a bit more simple. Don't forget to check it out. We have prepared couple of layouts 
										options for you, so you could make trully different websites and provide unique user experience 
										to every client that visits your page. Hope you like it! If you have any questions head over to 
										our support forum or leave a comment on template's comment form. We would be happy to hear some 
										feedback from you. Stay tuned on www.pixel-industry.com for more cool stuff.
										</p>
									</div>
								 -->
								<!-- member Description 2 -->
									<!-- <div id="small-dialog-2" class="zoom-anim-dialog mfp-hide popup-back">
										<h1>Mark Twist</h1>
										<h3>Interior Design Director</h3>
										<p>
										Welcome to <span>Ricochet</span>, amazing interior design template. It's 
										time to stand out from the crowd and offer your clients
										unique and amazing experience. Ricochet comes in two
										versions: clean corporate site and modern, unique layout
										which you are seeing right now. Choose the one you like
										more, you won't be disapointed,.
										</p>
										<p>
										This is example of a about page. When you click on that little dot a lightbox shows up.
										You can arrange dots to be anywhere on your photo. Also there's another about us pageoption, 
										which is a bit more simple. Don't forget to check it out. We have prepared couple of layouts 
										options for you, so you could make trully different websites and provide unique user experience 
										to every client that visits your page. Hope you like it! If you have any questions head over to 
										our support forum or leave a comment on template's comment form. We would be happy to hear some 
										feedback from you. Stay tuned on www.pixel-industry.com for more cool stuff.
										</p>
									</div>
								 -->
								<!-- member Description 3 -->
									<!-- <div id="small-dialog-3" class="zoom-anim-dialog mfp-hide popup-back">
										<h1>Alicia Stark</h1>
										<h3>Interior Design Director</h3>
										<p>
										Welcome to <span>Ricochet</span>, amazing interior design template. It's 
										time to stand out from the crowd and offer your clients
										unique and amazing experience. Ricochet comes in two
										versions: clean corporate site and modern, unique layout
										which you are seeing right now. Choose the one you like
										more, you won't be disapointed,.
										</p>
										<p>
										This is example of a about page. When you click on that little dot a lightbox shows up.
										You can arrange dots to be anywhere on your photo. Also there's another about us pageoption, 
										which is a bit more simple. Don't forget to check it out. We have prepared couple of layouts 
										options for you, so you could make trully different websites and provide unique user experience 
										to every client that visits your page. Hope you like it! If you have any questions head over to 
										our support forum or leave a comment on template's comment form. We would be happy to hear some 
										feedback from you. Stay tuned on www.pixel-industry.com for more cool stuff.
										</p>
									</div>
								 -->
								<!-- member Description 4 -->
									<!-- <div id="small-dialog-4" class="zoom-anim-dialog mfp-hide popup-back">
										<h1>Oliver Mathews</h1>
										<h3>Interior Design Director</h3>
										<p>
										Welcome to <span>Ricochet</span>, amazing interior design template. It's 
										time to stand out from the crowd and offer your clients
										unique and amazing experience. Ricochet comes in two
										versions: clean corporate site and modern, unique layout
										which you are seeing right now. Choose the one you like
										more, you won't be disapointed,.
										</p>
										<p>This is example of a about page. When you click on that little dot a lightbox shows up.
										You can arrange dots to be anywhere on your photo. Also there's another about us pageoption, 
										which is a bit more simple. Don't forget to check it out. We have prepared couple of layouts 
										options for you, so you could make trully different websites and provide unique user experience 
										to every client that visits your page. Hope you like it! If you have any questions head over to 
										our support forum or leave a comment on template's comment form. We would be happy to hear some 
										feedback from you. Stay tuned on www.pixel-industry.com for more cool stuff.
										</p>
									</div> -->

								<!-- member Description 5 -->
									<!-- <div id="small-dialog-5" class="zoom-anim-dialog mfp-hide popup-back">
										<h1>Carla Mayer</h1>
										<h3>HR DIRECTOR</h3>
										<p>
										Welcome to <span>Ricochet</span>, amazing interior design template. It's 
										time to stand out from the crowd and offer your clients
										unique and amazing experience. Ricochet comes in two
										versions: clean corporate site and modern, unique layout
										which you are seeing right now. Choose the one you like
										more, you won't be disapointed,.
										</p>
										<p>This is example of a about page. When you click on that little dot a lightbox shows up.
										You can arrange dots to be anywhere on your photo. Also there's another about us pageoption, 
										which is a bit more simple. Don't forget to check it out. We have prepared couple of layouts 
										options for you, so you could make trully different websites and provide unique user experience 
										to every client that visits your page. Hope you like it! If you have any questions head over to 
										our support forum or leave a comment on template's comment form. We would be happy to hear some 
										feedback from you. Stay tuned on www.pixel-industry.com for more cool stuff.
										</p>
									</div> -->

								<!-- member Description 6 -->
									<!-- <div id="small-dialog-6" class="zoom-anim-dialog mfp-hide popup-back">
										<h1>Jonathan Brew</h1>
										<h3>EXTERIOR DESIGN DIRECTOR</h3>
										<p>Welcome to <span>Ricochet</span>, amazing interior design template. It's 
										time to stand out from the crowd and offer your clients
										unique and amazing experience. Ricochet comes in two
										versions: clean corporate site and modern, unique layout
										which you are seeing right now. Choose the one you like
										more, you won't be disapointed.</p>
										<p>This is example of a about page. When you click on that little dot a lightbox shows up.
										You can arrange dots to be anywhere on your photo. Also there's another about us pageoption, 
										which is a bit more simple. Don't forget to check it out. We have prepared couple of layouts 
										options for you, so you could make trully different websites and provide unique user experience 
										to every client that visits your page. Hope you like it! If you have any questions head over to 
										our support forum or leave a comment on template's comment form. We would be happy to hear some 
										feedback from you. Stay tuned on www.pixel-industry.com for more cool stuff.</p>
									</div> -->
								
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Corporate Team Section -->
		
		<!-- Corporate About Service Section -->
			<section id="corporate-service">
				<div class="corporate-service-back">
					<div class="container">
						<div class="row corporate-service-row">
							<div class="col-sm-12">
								<div class="cp-page-header">
									<h2>Our Services</h2>
									<p>WHAT CAN WE DO FOR YOU</p>
									<img src="assets/images/header-bottom.png" alt="">
								</div>
							</div>
						</div>
					<!-- First Row -->
						<div class="row">
						<!-- Item One -->
							<div class="col-sm-4">
								<div class="corporate-service-content wow fadeInLeft">
									<div class="corporate-icon">
										<div class="corporate-circle">
											<div class="corporate-icon-back"></div>
										</div>
									</div>
									<div class="corporate-content">
										<h3><a href="#">Planning</a></h3>
										<p  style="font-family:Times New Roman;">
											Mahesh Wooden Furniture is modern, clean and beautiful interior design
											template with unique touches that will stand out from the
											crows.
										</p>
									</div>
								</div>
							</div>
						<!--/ End Item One -->
						
						<!-- Item Two -->
							<div class="col-sm-4">
								<div class="corporate-service-content wow fadeInDown">
									<div class="corporate-icon">
										<div class="corporate-circle">
											<div class="corporate-icon-back-1"></div>
										</div>
									</div>
									<div class="corporate-content">
										<h3><a href="#">Interior Design</a></h3>
										<p  style="font-family:Times New Roman;">
											
											Mahesh Wooden Furniture comes in two versions, simple corporate and
											modern more custom solution. Choose the one that fits
											your needs.
										</p>
									</div>
								</div>
							</div>
						<!--/ End Item Two -->
						
						<!-- Item Three -->
							<div class="col-sm-4">
								<div class="corporate-service-content wow fadeInRight">
									<div class="corporate-icon">
										<div class="corporate-circle">
											<div class="corporate-icon-back-2"></div>
										</div>
									</div>
									<div class="corporate-content">
										<h3><a href="#">Exterior Design</a></h3>
										<p  style="font-family:Times New Roman;">
											We have prepeared quite a couple of interior design icons
											in svg format to create trully unique user experience. Use
											them as SVG or font.
										</p>
									</div>
								</div>
							</div>
						<!--/ End Item Three -->
						</div>
					<!--/ End First Row -->
					
					<!-- Second Row -->
						<div class="row corporate-service-row2">
						<!-- Item One -->
							<div class="col-sm-4">
								<div class="corporate-service-content wow fadeInLeft">
									<div class="corporate-icon">
										<div class="corporate-circle">
											<div class="corporate-icon-back"></div>
										</div>
									</div>
									<div class="corporate-content">
										<h3><a href="#">3D Interior Visualization</a></h3>
										<p  style="font-family:Times New Roman;">
											
											Mahesh Wooden Furniture comes with shop layout too. As there are interior
											design companies that offer custom made furniture we
											tought you might need it.
										</p>
									</div>
								</div>
							</div>
						<!--/ End Item One -->
						
						<!-- Item Two -->
							<div class="col-sm-4">
								<div class="corporate-service-content wow fadeInUp">
									<div class="corporate-icon">
										<div class="corporate-circle">
											<div class="corporate-icon-back-1"></div>
										</div>
									</div>
									<div class="corporate-content">
										<h3><a href="#">3D Exterior Visualization</a></h3>
										<p  style="font-family:Times New Roman;">
											
											Mahesh Wooden Furniture is fully responsive and retina ready template so it
											will look amazing on all devices and high pixel density ratio
											screens.
										</p>
									</div>
								</div>
							</div>
						<!--/ End Item Two -->
						
						<!-- Item Three -->
							<div class="col-sm-4">
								<div class="corporate-service-content wow fadeInRight">
									<div class="corporate-icon">
										<div class="corporate-circle">
											<div class="corporate-icon-back-2"></div>
										</div>
									</div>
									<div class="corporate-content">
										<h3><a href="#">Furniture Supplier</a></h3>
										<p  style="font-family:Times New Roman;">
											
											Mahesh Wooden Furniture comes with clean commented code and highly
											detailed documentation to make your customization and
											work easy as never before.
										</p>
									</div>
								</div>
							</div>
						<!--/ End Item Three -->
						</div>
					<!--/ End Second Row -->
					
					</div>
				</div>
			</section>
		<!--/ End Corporate About Service Section -->
		
		<!-- Hire Us Section -->
			<section id="hire">
				<div class="hire-back">
					<div class="container">
						<div class="row">
								<div class="hire-slide">
							
									<div>
										<div class="col-sm-12">
											<div class="hire-content">
												<h2  style="font-family:Times New Roman;">
													"Our mission is to deliver high quality Furniture design concept that meets the wishes adn dreams of our
													clients and put that design into practice to make amazing and warm place for everyday life."
												</h2>
												
												<div class="hire-button">
													<a href="#">HIRE US</a> 
												</div>  
											</div>
										</div>
									</div>
									<div>
										<div class="col-sm-12">
											<div class="hire-content">
												<h2  style="font-family:Times New Roman;">
													"We Are Going To Provide A Better World To Live By Saving Natural Resources Like TREES".
												</h2>
												
												<div class="hire-button">
													<a href="#">HIRE US</a> 
												</div>  
											</div>
										</div>
									</div>
									<div>
										<div class="col-sm-12">
											<div class="hire-content">
												<h2  style="font-family:Times New Roman;">
													"Our mission is to deliver high quality interior and exterior design concept that meets the wishes adn dreams of our
													clients and put that design into practice to make amazing and warm place for everyday life.
												</h2>
												
												<div class="hire-button">
													<a href="#">HIRE US</a> 
												</div>  
											</div>
										</div>
									</div>
							
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Hire Us Section -->
		
		<!-- Partners Section -->
			<section id="partner-slide">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<div class="cp-page-header">
								<h2>Partners</h2>
								<p>Materials & Furniture Supplier Partners</p>
								<img src="assets/images/header-bottom.png" alt="">
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-sm-12">
							<div class="partner-logo">
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-1.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-2.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-3.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-4.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-1.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-2.png" alt=""></a>
								</div>
								<div>
									<a href="#" target="_blank"><img src="assets/images/partner-3.png" alt=""></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Partners Section -->
		
<?php include 'footer.php';?>
		
		
    	<!-- Theme Panel Switcher End -->	
		

		<!-- ============ Js Files ============ -->

	    <!-- Placed at the end of the document so the pages load faster -->
		
		<!-- main js -->
			<script src="assets/js/jquery-1.11.2.min.js"></script>
				
			<script src="assets/js/bootstrap.min.js"></script>	
			<script src="assets/js/jquery.sticky.js"></script>	
			
			<script src="assets/js/slider/jquery.themepunch.tools.min.js"></script>	
			<script src="assets/js/slider/jquery.themepunch.revolution.min.js"></script>	
			<script src="assets/js/slider/portfolio-single-custom.js"></script>	
			
			<script src="assets/js/jquery.cubeportfolio.min.js"></script>	
			<script src="assets/js/portfolio-custom.js"></script>	
			<script src="assets/js/slick.min.js"></script>
			<script src="assets/js/modernizr.custom.js"></script>
			<script src="assets/js/jquery.magnific-popup.min.js"></script>
			<script src="assets/js/jquery.touchSwipe.min.js"></script>
			<script src="assets/js/jquery.liquid-slider.js"></script>
			<script src="assets/js/jquery.backstretch.min.js"></script>
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script> 
			<script src="assets/js/gmap3.min.js"></script>
			<script src="assets/js/ionrangeslider.js"></script>
			<script src="assets/js/classie.js"></script>
			<script src="assets/js/wow.min.js"></script>
			
		       
		<!-- Custom Script -->		
			<script src="assets/js/main.js"></script>
		<!-- Theme Panel Style Switcher -->
			<script src="assets/js/theme_panel.js"></script>		
		
	</body>

<!-- Mirrored from ricochet.mkscoder.com/demo/animated/corporate-about-us.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Jul 2016 08:45:40 GMT -->
</html>
