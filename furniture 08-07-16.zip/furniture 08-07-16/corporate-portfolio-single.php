<?php include 'header.php';?>
		<!-- End Navigation Section -->
		
		<!-- Page title -->
			<section class="page-title-wrap">
				<div class="page-title-img portfolio-pagetitle-bg">
					<div class="container">
						<div class="row">
							<div class="cp-page-title-wrap">
								<div class="header-color-back">
									<div class="header-main-content">
										<h1><span>Portfolio Single</span></h1>
										<p>We are Ricochet. Interior Design Company.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Page title -->
		
		<!-- Main Content -->
			<section id="cp-portfolio-single" class="custom-80">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<div class="tp-banner-container">
								<div class="tp-banner" >
									<ul>	<!-- SLIDE  -->

				
										<!-- SLIDE  -->
										<li data-transition="slidevertical" data-slotamount="1" data-masterspeed="1000" data-thumb="assets/images/revolution/portfolio-single/portfolio-single-back.jpg"  data-saveperformance="off"  data-title="Slide">
											<!-- MAIN IMAGE -->
											<img src="assets/images/revolution/portfolio-single/portfolio-single-back.jpg"  alt="fullslide6"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
											
											<!-- LAYER NR. 1 -->
											<div class="tp-caption  customin fadeout tp-resizeme"
												data-x="center" data-hoffset="0"
												data-y="center" data-voffset="0"
												data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
												data-speed="500"
												data-start="2000"
												data-easing="Power4.easeOut"
												data-splitin="none"
												data-splitout="none"
												data-elementdelay="0.1"
												data-endelementdelay="0.1"
												data-endspeed="500"

												style="z-index: 2; max-width: auto; max-height: auto; white-space: nowrap;">
												<img src="assets/images/revolution/portfolio-single/1.png" alt="">

											</div>
											<!-- LAYER NR. 1 -->
											

											<!-- LAYER NR. 2 -->
											<div class="tp-caption bignumbers_white lfb ltt tp-resizeme"
												data-x="center" data-hoffset="-210"
												data-y="center" data-voffset="0"
												data-speed="800"
												data-start="2200"
												data-easing="Power4.easeOut"
												data-splitin="none"
												data-splitout="none"
												data-elementdelay="0.01"
												data-endelementdelay="0.1"
												data-endspeed="500"
												data-endeasing="Power4.easeIn"
												style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
												<img src="assets/images/revolution/portfolio-single/2.jpg" alt="">

											</div>
											<!-- LAYER NR. 2 -->
											
											<!-- LAYER NR. 3 -->
											<div class="tp-caption modern_medium_fat customin stt tp-resizeme"
												data-x="center" data-hoffset="25"
												data-y="center" data-voffset="-145"
												data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
												data-speed="1000"
												data-start="2300"
												data-easing="Power4.easeOut"
												data-splitin="none"
												data-splitout="none"
												data-elementdelay="0.1"
												data-endelementdelay="0.1"
												data-endspeed="500"
												data-endeasing="Power4.easeInOut"
									
												style="z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;">Industrial lamp
											</div>
											<!-- LAYER NR. 3 -->
											
											<!-- LAYER NR. 4 -->
											<div class="tp-caption small_text lfb ltt tp-resizeme"
												data-x="center" data-hoffset="133"
												data-y="center" data-voffset="-40"
												data-speed="600"
												data-start="2500"
												data-easing="Power4.easeOut"
												data-splitin="none"
												data-splitout="none"
												data-elementdelay="0.01"
												data-endelementdelay="0.1"
												data-endspeed="500"
												data-endeasing="Power4.easeIn"
												style="font-size:14px; z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;">
												Welcome to Ricochet, amazing interior design template. It's<br/> 
												time to stand out from the crowd and offer your clients<br/>
												unique and amazing experience. Ricochet comes in two<br/> 
												versions: clean corporate site and modern, unique layout<br/>
												which you are seeing right now. Choose the one you like<br/>
												more, you won't be disapointed,.
											</div>
											<!-- LAYER NR. 4 -->
											
										</li>
				
										<!-- SLIDE  -->
										<li data-transition="slidevertical" data-slotamount="1" data-masterspeed="1000" data-thumb="assets/images/revolution/portfolio-single/portfolio-single-back.jpg"  data-saveperformance="off"  data-title="Slide">
											<!-- MAIN IMAGE -->
											<img src="assets/images/revolution/portfolio-single/portfolio-single-back.jpg"  alt="fullslide8"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
											
											<!-- LAYER NR. 1 -->
											<div class="tp-caption  customin fadeout tp-resizeme"
												data-x="center" data-hoffset="0"
												data-y="center" data-voffset="0"
												data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
												data-speed="500"
												data-start="2000"
												data-easing="Power4.easeOut"
												data-splitin="none"
												data-splitout="none"
												data-elementdelay="0.1"
												data-endelementdelay="0.1"
												data-endspeed="500"

												style="z-index: 2; max-width: auto; max-height: auto; white-space: nowrap;">
												<img src="assets/images/revolution/portfolio-single/1.png" alt="">

											</div>
											<!-- LAYER NR. 1 -->
											

											<!-- LAYER NR. 2 -->
											<div class="tp-caption bignumbers_white lfb ltt tp-resizeme"
												data-x="center" data-hoffset="-210"
												data-y="center" data-voffset="0"
												data-speed="800"
												data-start="2200"
												data-easing="Power4.easeOut"
												data-splitin="none"
												data-splitout="none"
												data-elementdelay="0.01"
												data-endelementdelay="0.1"
												data-endspeed="500"
												data-endeasing="Power4.easeIn"
												style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
												<img src="assets/images/revolution/portfolio-single/2.jpg" alt="">

											</div>
											<!-- LAYER NR. 2 -->
											
											<!-- LAYER NR. 3 -->
											<div class="tp-caption modern_medium_fat customin stt tp-resizeme"
												data-x="center" data-hoffset="25"
												data-y="center" data-voffset="-145"
												data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
												data-speed="1000"
												data-start="2300"
												data-easing="Power4.easeOut"
												data-splitin="none"
												data-splitout="none"
												data-elementdelay="0.1"
												data-endelementdelay="0.1"
												data-endspeed="500"
												data-endeasing="Power4.easeInOut"
									
												style="z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;">Industrial lamp
											</div>
											<!-- LAYER NR. 3 -->
											
											<!-- LAYER NR. 4 -->
											<div class="tp-caption small_text lfb ltt tp-resizeme"
												data-x="center" data-hoffset="133"
												data-y="center" data-voffset="-40"
												data-speed="600"
												data-start="2500"
												data-easing="Power4.easeOut"
												data-splitin="none"
												data-splitout="none"
												data-elementdelay="0.01"
												data-endelementdelay="0.1"
												data-endspeed="500"
												data-endeasing="Power4.easeIn"
												style="font-size:14px; z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;">
												Welcome to Ricochet, amazing interior design template. It's<br/> 
												time to stand out from the crowd and offer your clients<br/>
												unique and amazing experience. Ricochet comes in two<br/> 
												versions: clean corporate site and modern, unique layout<br/>
												which you are seeing right now. Choose the one you like<br/>
												more, you won't be disapointed,.
											</div>
											<!-- LAYER NR. 4 -->
											
										</li>
									</ul>		
									<div class="tp-bannertimer"></div>	
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Main Content -->
		
		<!-- Details -->
			<section id="toggle-detail-1">
				<div class="container">
					<div class="row custom-50">
						<div class="col-sm-4">
							<div class="project-info">
								<h2>PROJECT INFO</h2>
								
								<h5 class="wow fadeInRight" data-wow-duration="2s" data-wow-delay=".1s"><span>Client:</span>Tara & Mark Reid</h5>
								<h5 class="wow fadeInRight" data-wow-duration="2s" data-wow-delay=".2s"><span>Date:</span>January 15, 2015</h5>
								<h5 class="wow fadeInRight" data-wow-duration="2s" data-wow-delay=".3s"><span>Category:</span>Interior Design</h5>
								
							</div>
							
							<div class="project-quote-1 wow fadeInUp">
								<div class="project-white-1">
									<div class="quote-icon">
										<span>“</span>
									</div>
									<h2>TARA & MARK REID</h2>
									
									<p class="custom-30">
									Cras a lectus neque. Mauris volutpat magna
									nunc, quis pellentesque orci aliquam non.
									Aliquam id mattis metus. 
									</p>
								</div>
							</div>
						</div>
						
						<div class="col-sm-8">
							<div class="project-info">
								
								<h3>Modern Living Room</h3>
								
								<p>
								Donec turpis lorem, elementum ullamcorper libero cursus, porta consequat lacus. Sed volut pat porta enim, sit amet viverra magna
								gravida eu. Donec ac urna elit. Sed tempus sit amet risus ut venenatis. In enim risus, imperdiet vel lectus ac, imperdiet feugiat orci.
								Donec aliquet elit id nunc tempor faucibus. Suspendisse in pharetra dui. Ut quis arcu volutpat, ullamcorper leo eget, convallis
								tortor. Cras at dolor in elit consectetur rhoncus. Curabitur lectus libero, dic tum sit amet aliquet in, volutpat sit amet turpis. Etiam
								libero lacus, consequat eu aliquam at, aliquet at diam. Integer aliquam semper eros, et varius sem maximus condimentum. Ut
								libe roorci, rutrum vel ipsum vitae, gravida maximus nisi. Vivamus dictum dolor quis felis volutpat, a imperdiet tortor pulvinar.
								</p>
								
								<p>
								Maecenas at odio mattis, porttitor augue a, pulvinar risus. Pellentesque habitant morbi tristi que senectus et netus et malesuada
								fames ac turpis egestas. Mauris dictum pretium ipsum. Aliquam a ultricies metus. Proin imperdiet porttitor mi, ut bibendum justo
								tempor in. Mauris lacinia ex eu est sollicitudin porta. Donec consequat consequat imperdiet. Curabitur elemen tum suscipit lacus,
								non tincidunt metus. Maecenas vitae neque facilisis, egestas dui sit amet, vulputate erat. Maecenas a justo eleifend, tempus justo
								eu, blandit nisl. Fusce semper ipsum sed sem viverra egestas. Nunc in aliquet urna, et tincidunt odio. Nunc tincidunt ipsum sed
								convallis sollicitudin. In luctus, turpis a egestas fermentum, erat dolor rutrum nibh, et ullamcorper ante nisl a neque.
								</p>
							</div>
						</div>
					</div>
				</div>
			</section>
		<!--/ End Details -->
		
		<?php include 'footer.php';?>