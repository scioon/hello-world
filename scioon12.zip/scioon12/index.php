<!DOCTYPE html>
<html lang="en">
<head>
<title> Digital Marketing Company in Hyderabad-SCIOON</title>
<meta name="description" content="Scioon is a top digital marketing company in India.digital marketing  offers SEO,social media marketing,web services.">
<link rel="canonical" href="http://scioondigital.com/" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<meta name="google-site-verification" content="Zy-f0ABLgqJcMLQBafBd7sP6vpyDSy16MCWuTxUoKf0" />
<meta name="author" content="Harika">
<meta property="og:type" content="website" />
<meta property="og:site_name" content="Scioon | Digital Marketing Company in Hyderabad" />
<meta property="og:title" content="Digital Marketing Company in Hyderabad - Scioon" />
<meta property="og:url" content="https://www.scioondigital.com/" />
<meta property="og:locale" content="en_US" />
<meta property="og:image" content="https://www.scioondigital.com/images/footer.png" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <script type="text/javascript">
//<![CDATA[
try{if (!window.CloudFlare) {var CloudFlare=[{verbose:0,p:0,byc:0,owlid:"cf",bag2:1,mirage2:0,oracle:0,paths:{cloudflare:"/cdn-cgi/nexp/dok3v=1613a3a185/"},atok:"2b1076578b1dd0cb10ef8c87ae34fb9b",petok:"864f07fc3ee52a47d0eefa5589b0ab447361da26-1481850239-3600",zone:"web3canvas.com",rocket:"0",apps:{"abetterbrowser":{"ie":"7","opera":null,"chrome":null,"safari":null,"firefox":null},"ga_key":{"ua":"UA-38030533-1","ga_bs":"2"}}}];!function(a,b){a=document.createElement("script"),b=document.getElementsByTagName("script")[0],a.async=!0,a.src="../../../ajax.cloudflare.com/cdn-cgi/nexp/dok3v%3df2befc48d1/cloudflare.min.js",b.parentNode.insertBefore(a,b)}()}}catch(e){};
//]]>
</script>
<link rel="icon" type="image/png" href="images/favic.png" width="16" height="16">
 <link href="css/bootstrap.min.css" rel="stylesheet">
 <link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.min.css">
 <link rel="stylesheet" href="css/flexslider.css">
 <link rel="stylesheet" href="css/owl.carousel.min.css"><link rel="stylesheet" href="css/owl.theme.min.css">
 <link href="css/style.css" rel="stylesheet">
<script type="text/javascript">
/* <![CDATA[ */
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-38030533-1']);
_gaq.push(['_trackPageview']);
(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
(function(b){(function(a){"__CF"in b&&"DJS"in b.__CF?b.__CF.DJS.push(a):"addEventListener"in b?b.addEventListener("load",a,!1):b.attachEvent("onload",a)})(function(){"FB"in b&&"Event"in FB&&"subscribe"in FB.Event&&(FB.Event.subscribe("edge.create",function(a){_gaq.push(["_trackSocial","facebook","like",a])}),FB.Event.subscribe("edge.remove",function(a){_gaq.push(["_trackSocial","facebook","unlike",a])}),FB.Event.subscribe("message.send",function(a){_gaq.push(["_trackSocial","facebook","send",a])}));"twttr"in b&&"events"in twttr&&"bind"in twttr.events&&twttr.events.bind("tweet",function(a){if(a){var b;if(a.target&&a.target.nodeName=="IFRAME")a:{if(a=a.target.src){a=a.split("#")[0].match(/[^?=&]+=([^&]*)?/g);b=0;for(var c;c=a[b];++b)if(c.indexOf("url")===0){b=unescape(c.split("=")[1]);break a}}b=void 0}_gaq.push(["_trackSocial","twitter","tweet",b])}})})})(window);
/* ]]> */
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-89189067-1', 'auto');
  ga('send', 'pageview');

</script>
<style>
.social a:hover
{
transform: rotate(360deg);
}
</style>
</head>
<body class="homepage">
 <div class="loader-wrapper">
<div class="sk-cube-grid">
<div class="sk-cube sk-cube1"></div>
<div class="sk-cube sk-cube2"></div>
<div class="sk-cube sk-cube3"></div>
<div class="sk-cube sk-cube4"></div>
<div class="sk-cube sk-cube5"></div>
<div class="sk-cube sk-cube6"></div>
<div class="sk-cube sk-cube7"></div>
<div class="sk-cube sk-cube8"></div>
<div class="sk-cube sk-cube9"></div>
</div>
</div>
 <div class="wrapper">
 <header>
<div class="header-area">
 <div class="row logo-top-info" style="background-color:#f77515;">
<div class="container">
<div class="col-md-3 logo">
<br/>
 <img src="images/footer.png">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
<span class="sr-only"> Main Menu </span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>
<div class="col-md-9 col-sm-6 top-info-social">
<div class="pull-right">
<div class="top-info">
<div class="call">
<h3 style="color:white;text-align:center;"> <i class="fa fa-phone" aria-hidden="true"></i> </h3>
<p> xyz </p>
</div>
<div class="email">
<h3 style="color:white;text-align:center;"> <i class="fa fa-envelope" aria-hidden="true"></i> </h3>
<p>info@scioondigital.com </p>
</div>
</div>
<div class="social">
<ul class="social-icons">

<li><a href="https://www.facebook.com/scioondigital"><i class="fa fa-facebook" aria-hidden="true" ></i></a></li>
<li><a href="https://www.twitter.com/scioondigital"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
<li><a href=""><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
<li><a href="https://www.pinterest.com/scioondigital"><i class="fa fa-pinterest " aria-hidden="true"></i></a></li>
<li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
<li><a href="https://plus.google.com/b/101090402747578684960/"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
 <nav id="navbar" class="collapse navbar-collapse main-menu">
<div class="container">
<ul class="main-menu">
<li class="active"> <a href="index.php"> Digital marketing </a></li>
<li> <a href="about.php"> Scioon</a></li>
<li class="dropdown"><a href="#" data-toggle="dropdown"> Services
<i class="fa fa-chevron-down dropdown-toggle"> </i> </a>
<ul>
<li class="dropdown1"> <a href="webdesign.php"> Web Designing </a> </li>
<li class="dropdown1"> <a href="webdevelopment.php"> Web Development </a> </li>
<li class="dropdown1"> <a href="seo.php"> SEO</a> </li>
<li class="dropdown1"> <a href="webmaintainence.php"> Web Maintainence </a> </li>
<li class="dropdown1"> <a href="ecommerce.php"> Ecommerce </a> </li>
<li class="dropdown1"> <a href="contentwriting.php">Content Writing</a> </li>
</ul>
</li>
<li><a href="portfolio.php"> Portfolio</a> </li>
<li class="dropdown"> <a href="#" data-toggle="dropdown">Advertising
<i class="fa fa-chevron-down dropdown-toggle"> </i> </a>
<ul>
<li class="dropdown1"> <a href="smm.php"> SMM</a> </li>
<li class="dropdown1"> <a href="email.php"> Email marketing </a> </li>
<li class="dropdown1"> <a href="youtube.php"> Youtube Ads </a> </li>
<li class="dropdown1"> <a href="smo.php"> SMO </a> </li>
<li class="dropdown1"> <a href="webanalytics.php"> Web Analytics </a> </li>
</ul>
</li>
 <li><a href="https://scioon.blogspot.in/" target="_bank">Blog </a> </li> 
<li><a href="contact.php"> CONTACT US</a> </li>
</ul>
</div>
</nav>
</div>
</header>
 <head>
 <script>
function validateForm() {
    var x = document.forms["myForm"]["firstname"].value;
    if (x == "") {
        alert("Name must be filled out");
        return false;
    }
}
</script>
 </head>
<main class="main">
 <section class="home-slider">
<div class="flexslider">
<ul class="slides">
<li class="has-overlay"> 
<img src="images/slider3.jpg" alt="digital marketing company in hyderabad"/>
<div class="slider-content">
<div class="container">
<br/><br/>
<div class="container">
<h1 style="color:white;font-size: 50px;font-family: "Raleway","Helvetica Neue",Helvetica,Arial,sans-serif;font-weight: 400;"><span style="color:#f77515;">Digital</span> Marketing Company </h1>
  <form class="form-inline" action="mail.php">
    <div class="form-group">
      <label class="sr-only" for="email">Name:</label>
      <input type="text" class="form-control" id="name" name="name" placeholder="Enter name" required>
    </div>
    <div class="form-group">
      <label class="sr-only" for="pwd">Contact:</label>
      <input type="password" class="form-control" name="contact" id="contact" placeholder="Enter contact" required>
    </div>
    <button type="submit" class="btn btn-default" style="background-color:#f77515;">Submit</button>
  </form>
</div>
</div>
</div>
</li>
<div class="slider-content text-center">
<div class="container">
</div>
</div>
</li>
<div class="slider-content text-center">
<div class="container">
</div>
</div>
</li>
</ul>
</div>
</section>
<section class="home-company">
<div class="container">
<div class="row company">
<div class="col-md-6 col-sm-3">
<div class="company-details">
<h2 class="company-title color-title" style="color:#f77515"> WHY DIGITAL MARKETING?</h2>
<p style="text-align:justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Digital marketing is a new era of advertising. It’s a meaningful movement between people and brands via digital media. Digital marketing is pervasive that customer has access to info anytime any place they required it. It is no wonder then that enterprises are looking for a way to build their long-term productive relationship with their consumers to succeed in the digital marketplace. Digital marketing also examine business statistics like who is your ideal customer? Where they located? How much time they spent on your site? By the targeted keywords. A comprehensive digital marketing solution that helps engage with the consumers influence their opinions to provide relevant feedback reaches various demographics. <br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SCIOON can assist  you and your business to choose digital advertising and internet marketing that will get your ideas, products, services to a massive ever-expanding market give you that elusive competitive edge that will keep you ahead in the market. Let us know how digital marketing differs from traditional marketing? The standard marketing concerned businesses to advertise their products or services on Newspapers, radio and TV, billboards, and in many other similar ways where the Internet or social media websites were not employed for advertising. Whereas digital marketing making completely through online channels.<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Digital marketing provides SEO, social media marketing, content marketing, web services, email marketing.Social Media Marketing is to generate website traffic and allure new customers through facebook, twitter etc.Search engine optimization (SEO) involves achieving the highest position entered by search engine users.Email marketing is used to attract the new customer and it is also be used to maintain a relationship between entrepreneur and customer.It is like sending a direct invitation to the customer. Web Analytics is the scaling, gathering, analysis and reporting of Internet data for the purposes of optimizing Web usage.Content marketing is associated with covering a group of ways, techniques, and techniques to fulfill business and client goals by exploitation the foremost relevant content to serve, attract, convert, retain, and have interaction customers.
 </p>
</div>
</div>
<div class="col-md-7 col-sm-12" style="margin-top:-3cm;">
<div class="company-image">
<div class="img-left hover-effect">
</div>
<img src="images/digitalmarketing.png" alt="Digital marketing agency in hyderabad"/>
<img src="images/digitalservices.png" alt="Digital marketing firm in hyderabad"/>
</div>
</div>
</div>
</div>
</section>
</section>
<section class="home-services-other" style="background-color:#f7f7f7;">
<div class="container">
<div class="section-title text-center">
<h2 class="title-services-other title-2" style="color:#f77515">SERVICES</h2>
<h2 class="subtitle-services-other subtitle-2" >Scioon a digital marketing company which introduces you to the world.</h2>
<div class="spacer-50"> </div>
</div>
<div class="row services-other">
<div class="col-sm-4">
<div class="img-box">
<img src="images/search.png" alt="seo best digital marketing firm in hyderabad"/>
</div>
<div class="services-info">
<h3 class="services-title-one subtitle"><a href="seo.php">SEO</a></h3>
<p>SEO is the way toward influencing the permeability of a site.</p>
</div>
</div>
<div class="col-sm-4">
<div class="img-box">
<img src="images/social.png" alt="top digital marketing company in hyderabad"/>
</div>
<div class="services-info">
<h3 class="services-title-one subtitle"><a href="smm.php">SMM</a></h3>
<p>SMM </a>is a type of Internet promoting that uses person to person communication.</p>
</div>
</div>
<div class="col-sm-4">
<div class="img-box">
<img src="images/analytics.png" alt="digital marketing services in hyderabad"/>
</div>
<div class="services-info">
<h3 class="services-title-one subtitle"><a href="webanalytics.php">Web Analytics</a></h3>
<p>Web Analytics</a> is the estimation and reporting of web information.</p>
</div>
</div>
<div class="clearfix spacer-70"></div>
<div class="col-sm-4">
<div class="img-box">
<img src="images/emailmarketing.png" alt="leading digital marketing company in hyderabad,India"/>
</div>
<div class="services-info">
<h3 class="services-title-one subtitle"><a href="email.php">Email Marketing</a></h3>
<p>Email marketing</a> used to send mail to a group of people, using email.</p>
</div>
</div>
<div class="col-sm-4">
<div class="img-box">
<img src="images/websitemain.png" alt="one of the best digital marketing company in hyderabad"/>
</div>
<div class="services-info">
<h3 class="services-title-one subtitle"><a href="#">Web Maintainence</a></h3>
<p>Web maintainence used to redesign your site.</p>
</div>
</div>
<div class="col-sm-4">
<div class="img-box">
<img src="images/YouTube.png" alt="list of digital marketing companies in hyderabad"/>
</div>
<div class="services-info">
<h3 class="services-title-one subtitle"><a href="youtube.php">Youtube Ad</a></h3>
<p>Youtube provides our latest updates and videos and etc information.</p>
</div>
</div>
<div class="clearfix spacer-70"></div>
<div class="col-sm-4">
<div class="img-box">
<img src="images/webdesigning.png" alt="best digital marketing agency in hyderabad"/></div>
<div class="services-info">
<h3 class="services-title-one subtitle"><a href="webdesign.php">web designing</a></h3>
<p>web Designing is to design a website innovative way.</p>
</div>
</div>
<div class="col-sm-4">
<div class="img-box">
<img src="images/contentwriting.png" alt="premium digital marketing company"/></div>
<div class="services-info">
<h3 class="services-title-one subtitle"><a href="contentwriting.php">Content Writing</a></h3>
<p>Original content with 0% plagiarism 100% Unique content.</p>
</div>
</div>
<div class="col-sm-4">
<div class="img-box">
<img src="images/webdevelop.png" alt="premium digital marketing agency in hyderabad"/></div>
<div class="services-info">
<h3 class="services-title-one subtitle"><a href="webdevelopment.php">Web Development</a></h3>
<p>Which includes design development and e-commerce.</p>
</div>
</div>
</div>
</div>
</section>
<section class="home-testimonials" style="background: url(images/testimonial.jpg)";>
<div class="container">
<div class="section-title text-center">
<div class="spacer-50"> </div>
</div>
<div class="row">
<div class="col-md-4" >
<blockquote >SCIOON has been exceptionally responsive and accessible to answer my inquiries. They proposed forceful yet practical objectives for Smith Publicity and a genuine diagram of expected quantifiable outcomes. To date, they've been perfect and have conveyed what they said about digital marketing.</blockquote>
<p class="client-name" style="text-align:center;color:white;">Aravind</p>
</div>
<div class="col-md-4">
<blockquote>We're truly satisfied with the digital marketing services from Scioon, the group give a remarkable level of advanced learning close by handy hands-on everyday support. We've rolled out some noteworthy improvements and seen some critical execution enhancements in a short space of time. </blockquote>
<p class="client-name" style="text-align:center;color:white;">Ramesh</p>
</div>
<div class="col-md-4">
<blockquote>After only three months together we gained more ground than our past office had in 10 months. This development in  digital marketing execution after such a brief period has far surpassed our desires. It appears to be uncommon that an organization can offer such a decent administration and terms in the meantime.</blockquote>
<p class="client-name" style="text-align:center;color:white;">Aruna</p>
</div>
</div>
</div>
</section>
<section class="home-partners">
<div class="container">
<div class="section-title text-center">
<h2 class="subtitle-testimonials title-2"> OUR PARTNERS </h2>
<div class="spacer-20"> </div>
</div>
<div class="row partners">
<div class="logo-slides slides owl-carousel">
<div class="item">
<div class="partner-images">
<img src="images/scioonpartner1.png" alt="top digital marketing companies in hyderabad,india">
</div>
</div>
<div class="item">
<div class="partner-images">
<img src="images/scioonpartner2.png" alt="digital marketing solution provider in hyderabad ">
</div>
</div>
<div class="item">
<div class="partner-images">
<img src="images/scioonpartner3.jpeg" alt="best digital marketing company in hyderabad,digital marketing agency in india">
</div>
</div>
<div class="item">
<div class="partner-images">
<img src="images/scioonpartner4.jpg" alt="digital marketing services hyderabad india">
</div>
</div>
<div class="item">
<div class="partner-images">
<img src="images/scioonpartner1.png" alt="hyderabad based digital marketing company in india">
</div>
</div>
<div class="item">
<div class="partner-images">
<img src="images/scioonpartner2.png" alt="hyderabad based digital marketing agency">
</div>
</div>
<div class="item">
<div class="partner-images">
<img src="images/scioonpartner3.jpeg" alt="digital marketing agency,company">
</div>
</div>
<div class="item">
<div class="partner-images">
<img src="images/scioonpartner4.jpg" alt="best digital marketing">
</div>
</div>
</div>
</div>
</div>
</section>
</main>
 <footer>
<div class="footer">
<div class="container">
 
<div class="row pre-footer">
<div class="col-md-4">
<div class="contact-box" style="background-color:#f48127">
<i class="fa fa-map-marker" aria-hidden="true"></i>
<div class="contact-details">
<h4 class="pre-footer-title">HEAD OFFICE</h4>
<p>Near Apex Hospital
<br> Medipally, Hyderabad </p>
</div>
</div>
</div>
<div class="col-md-4">
<div class="contact-box"  style="background-color:#f58c3a">
<i class="fa fa-phone" aria-hidden="true"></i>
<div class="contact-details">
<h4 class="pre-footer-title">CALL US</h4>
<p>SUPPORT: xyz
<br> OFFICE: xyz</p>
</div>
</div>
</div>
<div class="col-md-4">
<div class="contact-box" style="background-color:#f6974d">
<i class="fa fa-envelope" aria-hidden="true"></i>
<div class="contact-details">
<h4 class="pre-footer-title">EMAIL US</h4>
<p>info@scioondigital.com </p>
<p>hrscioondigital@gmail.com </p>
</div>
</div>
</div>
</div>
<div class="row widgets">
<div class="col-md-4 col-sm-6">
<div class="about-txt widget">
<img src="images/footer.png" alt="digital marketing" />
<p style="text-align:justify;">The initial step to growing a brand online is to drive qualified prompts to your site or portable application. Having an easy to use experience is an imperative part of any fruitful business technique, however producing applicable movement is fundamental to having a solid change rate. As a full-benefit advanced organization, we give a vital way to deal with driving qualified activity. </p>
<div class="widgets-social">
<a href="https://www.facebook.com/scioondigital" style="background-color:#f77515"> <i class="fa fa-facebook" aria-hidden="true"></i> </a>
<a href="https://www.twitter.com/scioondigital" style="background-color:#f77515"> <i class="fa fa-twitter" aria-hidden="true"></i></a>
<a href="" style="background-color:#f77515" > <i class="fa fa-linkedin" aria-hidden="true"></i></a>
<a href="https://www.pinterest.com/scioondigital/" style="background-color:#f77515"> <i class="fa fa-pinterest" aria-hidden="true"></i></a>
<a href="#" style="background-color:#f77515"> <i class="fa fa-youtube" aria-hidden="true"></i></a>
<a href="https://plus.google.com/b/101090402747578684960/" style="background-color:#f77515"> <i class="fa fa-google-plus" aria-hidden="true"></i></a>
</div>
</div>
</div>
<div class="col-md-2 col-sm-6">
<div class="quick-links widget">
<h2 class="widget-title">QUICK LINKS</h2>
<ul>
<li> <a href="seo.php"> SEO</a> </li>
<li> <a href="smm.php"> SMM </a> </li>
<li> <a href="smo.php"> SMO </a> </li>
<li> <a href="youtube.php"> Youtube Ad </a> </li>
<li> <a href="webanalytics.php"> Web analytics </a> </li>
</ul>
</div>
</div>
<div class="spacer-50 visible-sm"></div>
<div class="col-md-3 col-sm-6">
<div class="our-services widget">
<h2 class="widget-title">OUR SERVICES</h2>
<ul>
<li> <a href="webdesign.php">Web designing </a> </li>
<li> <a href="webdevelopment.php"> Web development </a> </li>
<li> <a href="webmaintainence.php"> Web maintainence</a> </li>
<li> <a href="ecommerce.php">E-commercee   </a> </li>
<li> <a href="contentwriting.php">Content writing </a> </li>
</ul>
</div>
</div>
<div class="col-md-3 col-sm-6">
<div class="newsletter widget">
<h2 class="widget-title">Newsletter</h2>
<form action="#" id="subscribeform" method="post">
<div class="form-group">
<input type="email" id="email" name="email" placeholder="Enter your email" class="form-control" title="Please enter your email" data-msg-email="Please enter a valid email">
</div>
<button type="submit" class="btn btn-block" id="js-subscribe-btn"> Subscribe Now! </button>
<div id="js-subscribe-result" data-success-msg="Done. Subscribed" data-error-msg="Oops. Error!"></div>
</form>
</div>
</div>
</div>
</div>
</div>
<div class="copyright">
<div class="container">
<div class="row copyright-bar">
<div class="col-md-6">
<p>Copyright &#169  2016 <a href="#"><b>Scioon</b></a>All rights reserved.</p>
</div>
<div class="col-md-6 text-right">
<p> <a href="#"> Terms of use</a> <a href="#">Privacy Policy</a> <span> | </span> Made with <i class="fa fa-heart" aria-hidden="true"></i> by Harika </p>
</div>
</div>
</div>
</div>
</footer>
<a href="#0" class="cd-top"> Top </a>
</div>

<script type="application/ld+json">


{
  "@context" : "http://schema.org",
  "@type" : "Organization",
  "name" : "Scioon- Digital Marketing Company",
  "url" : "https://www.scioondigital.com",
  "logo": "https://www.scioondigital.com/images/footer.png",
  "sameAs" : [
    "https://www.facebook.com/scioon",
    "https://www.twitter.com/scioon",
    "https://www.linkedin.com/company/scioon",
    "https://www.instagram.com/scioon",
    "https://plus.google.com/+scioon"
  ],
  "contactPoint" : [{
    "@type" : "ContactPoint",
    "telephone" : "+91-xyz",
    "contactType" : "customer service"
  }]
}

</script>
<script type="application/ld+json">

{
  "@context" : "http://schema.org",
  "@type" : "WebSite",
  "name" : "Scioon - Digital Marketing Company",
  "alternateName" : "Scioon",
  "url" : "https://www.scioondigital.com",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://www.scioondigital.com/blog/?s={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.flexslider-min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/waypoints.min.js"></script>
<script src="js/jquery.counterup.min.js"></script>
<script src="js/back-to-top.js"></script>
<script src="js/validate.js"></script>
<script src="js/subscribe.js"></script>
<script src="js/main.js"></script>
 </body>
</html>
