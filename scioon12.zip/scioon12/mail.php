<?php
$firstname = $_REQUEST['name'];
$contact = $_REQUEST['contact'];
$to = "info@scioondigital.com";
$subject = "Enquiry";

$body = " FirstName: $firstname\n\n Contact:$contact";

mail($to, $subject, $body);
 
// redirect to confirmation
header('Location: confirmation.php');

?>