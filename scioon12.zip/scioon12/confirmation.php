<!DOCTYPE html>
<html>
 <head>
<meta charset="utf-8">
<title>Great Success!</title>
<meta content="php, contact, form, thinking" name="keywords">
<meta content="Great success!" name="description">
 <style>
html { 
  background: url(images/background.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
p {
font-family: Cambria, Cochin, serif;
text-align:center;
font-size:20px;
}
 
h1 {
font-family: "Trebuchet MS", Arial, sans-serif;
font-size: xx-large;
color: #3399FF;
text-align:center;

}
body {

}
</style>
 </head>
 <body>
<meta http-equiv="refresh" content="6;url=http://scioondigital.com">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<br/><br/><br/><br/><br/><br/>
<img src="images/favic.png" width="40" height="40">
<h1>Thank You!</h1>
<p>For Contacting Us
<p color="white">We've received your query, and we will get back to you with in 24 working hours.</a></p>
<p color="white">please wait for 5 seconds it will automatically redirect to home page.</p>
</body>
 </html>