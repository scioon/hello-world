<?php
$firstname = $_REQUEST['firstname'];
$lastname = $_REQUEST['lastname'];
$email = $_REQUEST['email'];
$phone= $_REQUEST['phone'];
$comment = $_REQUEST['comment'];
$to = "info@scioondigital.com";
$subject = "Enquiry";

$body = " FirstName: $firstname\n\n LastName:$lastname\n\n  E-Mail: $email\n\n phone:$phone\n\n Message:$comment";

mail($to, $subject, $body);
 
// redirect to confirmation
header('Location: confirmation.php');

?>